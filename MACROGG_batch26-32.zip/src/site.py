"""
網站層 — 共用版面、導覽列與頁面外殼。

一個頁面 = site.page(標題, 目前分頁, 內容 HTML)
各模組（勞動／通膨／FOMC／情境）只負責產生內容，不碰版面。

版面採「手機優先」：基本樣式寫給窄螢幕，再用 min-width 查詢加寬。
"""

from __future__ import annotations

import re
import html
import datetime as dt

from . import clock

# 站名與標語。站名進每一頁的 <title> 後綴與首頁大標；
# 標語只出現在首頁大標下方一行（小副標）。
SITE_NAME = "MACRO GG"
TAGLINE = "明天過後，帶你看總經"

# 站點網域：換自訂網域時改這裡（英文版按鈕的翻譯代理連結會跟著變）。
SITE_HOST = "macrogg.netlify.app"
# Google 翻譯代理的子網域規則：原網域的「-」寫成「--」、「.」寫成「-」。
_TR_HOST = SITE_HOST.replace("-", "--").replace(".", "-") + ".translate.goog"


def _lang_btn(active: str) -> str:
    """
    右上角的小小 EN 鈕：**直接**同分頁跳 Google 翻譯代理版（翻譯完的
    頁面上方有 Google 自帶的「顯示原文」列，切回不用我們做）。
    代理需要 Google 伺服器抓得到頁面——robots.txt 已配合放寬
    （run.py），頁面上的 noindex meta 保留、照樣不進搜尋索引。
    """
    url = (f"https://{_TR_HOST}{active}"
           "?_x_tr_sl=zh-TW&_x_tr_tl=en&_x_tr_hl=en")
    return (f'<a class="lang-btn" translate="no" href="{url}" '
            'rel="noopener" title="English">EN</a>')

# 導覽列定義：(路徑, 名稱, 是否已完成)
NAV = [
    ("/", "總覽", True),
    ("/ask/", "偷懶", True),
    ("/labor/", "就業", True),
    ("/inflation/", "通膨", True),
    ("/fomc/", "聯準會", True),
    ("/rates/", "長端與債務", True),
    ("/scenario/", "情境合成", True),
    ("/archive/", "存檔", True),
]

# 窄於這個寬度時，標示 data-m-collapse 的區塊預設收合
MOBILE_BREAKPOINT = 760



def esc(s) -> str:
    return html.escape(str(s), quote=True)


CSS = """
*{box-sizing:border-box}
/* 單一淺色主題。圖表繪製表面固定為 --surface-1（卡片），配色依此驗證。
   變數也掛在 :root：品牌頁首與置頂主選單在 .viz-root 外面，不掛的話
   --muted／--border 在那裡全是空值（EN 鈕的框線就是這樣消失的）。 */
:root,.viz-root{
  color-scheme:light;
  --page:#eeede9; --surface-1:#fcfcfb; --surface-2:#f3f3f0;
  --text-primary:#0b0b0b; --text-secondary:#45443f; --muted:#5f5e59;
  --grid:#e3e2db; --baseline:#c3c2b7; --border:rgba(11,11,11,0.13);
  /* 文字用的藍與橘要壓深一點：#2a78d6 在卡片底色上只有 3.97:1，
     而「展開…」這種連結、燈號狀態字全都用它。圖表線條另外留一組亮色，
     線條屬於圖形元素，門檻是 3:1，不必跟著壓深。 */
  --series-1:#1f5fae; --series-2:#a94420;
  --line-1:#2a78d6; --line-2:#eb6834;
  --pos:#2a78d6; --neg:#e34948; --muted-bar:#b8b7af;
  /* --warning 從 #936400 再壓深一級：它在白底上是 5.17，剛好過關，
     但疊在有色底（例如 .k-surp 的紅色淡底）上只剩 4.39，掉到 AA 以下。
     文字色要能在**任何**卡片底色上都成立，不能只看白底。 */
  --good:#077c07; --warning:#7a5100; --serious:#93401f; --critical:#b82828;
  --tint-dov:rgba(42,120,214,.11); --tint-haw:rgba(180,85,43,.12);
  --shadow:0 1px 2px rgba(11,11,11,.05),0 1px 8px rgba(11,11,11,.04);
  --bg:#fff; --faint:#a3a29c; --brand-ink:#12233B;
  --y2:#9aa6b8; --y10:#4f6383; --y30:#12233B;
}

html{-webkit-text-size-adjust:100%}
/* 中文字型（如 Noto Sans CJK）只有 400/500/700 等實體字重。
   若指定 650 這類非標準值，瀏覽器會改用「合成粗體」——筆畫被撐寬但
   前進距離不變，中文就會疊在一起。因此全站只用標準字重，
   並額外加一點字距作為保險。 */
h1,h2,h3,.v-main,.f-head,.m-name,.l-top,.k-label,.gloss dt,
.verdict .v-main,strong,b{letter-spacing:.035em}
body{margin:0;background:var(--bg);
  /* CJK 家族一定要點名，而且要用含 "CJK" 的完整家族名。
     只寫 system-ui / sans-serif 時，瀏覽器逐字回退找到的是 Regular 字面，
     粗體只好用「合成粗體」——筆畫塗寬但前進距離不變，中文就疊在一起。
     點名 "Noto Sans CJK TC" 之後會取到真正的 Bold 字面。
     順序：iOS/macOS 走 PingFang，Windows 走微軟正黑，Android/Linux 走 Noto。 */
  font-family:"Montserrat",system-ui,-apple-system,"Segoe UI Variable","Segoe UI",
    "PingFang TC","PingFang SC","Hiragino Sans CNS","Microsoft JhengHei",
    "Noto Sans CJK TC","Noto Sans CJK SC","Noto Sans TC",sans-serif;
  color:var(--text-primary);-webkit-font-smoothing:antialiased;
  font-size:15px;line-height:1.6}
/* 手機首屏很貴：到第一個結論有 43% 是導覽與免責。這裡省下來的每一 px
   都直接換成內容。桌機不受影響（下面的 760px 斷點會蓋掉）。 */
.viz-root{max-width:1120px;margin:0 auto;padding:12px 14px 60px}
@media(min-width:760px){.viz-root{padding:22px 20px 70px}}

/* ---------- 頁首 ---------- */
h1{font-size:21px;margin:0;font-weight:700;line-height:1.35}
@media(min-width:760px){h1{font-size:23px}}
/* ---------- 右上角的 EN 鈕（原生 details 小浮層）----------
   桌機手機都收在頁首右上；手機把觸控目標拉到 44px（稽核下限）。 */
.top{position:relative;padding-right:52px}
.lang-btn{position:absolute;top:0;right:0;display:inline-flex;
  align-items:center;justify-content:center;padding:3px 10px;
  font-size:11.5px;font-weight:700;letter-spacing:.06em;
  color:var(--muted);border:1px solid var(--border);border-radius:4px;
  text-decoration:none}
.lang-btn:hover{color:var(--text-primary);border-color:var(--text-primary)}
@media(max-width:759px){
  .lang-btn{min-height:44px;box-sizing:border-box}}
/* 標題兼「回首頁」。不加底線也不變色——它首先是標題，其次才是連結；
   染成連結色會讓每一頁的第一個視覺焦點變成一條藍字。 */
/* 觸控高度：h1 本身只有 28px。上下各給 6px 的 padding 撐到 40px，
   再用負 margin 抵掉視覺上的位移——這裡可以用負 margin，是因為它上下
   都沒有相鄰的可點元素（上面是頁面邊緣，下面是 .sub 純文字）。
   .f-more 就不行，它上下都貼著別的 summary。 */
.h1-home{color:inherit;text-decoration:none;display:inline-block;
  padding:6px 0;margin:-6px 0}
.h1-home:hover{color:var(--series-1)}
/* 首頁站名下的一句標語。比 .sub 醒目一階（它是品牌的一部分，不是
   中繼資料），但遠小於 h1——「MACRO GG」是大標、這句是小副標。 */
.tagline{color:var(--text-secondary);font-size:14px;font-weight:600;
  margin-top:3px;line-height:1.55}
.sub{color:var(--muted);font-size:12.5px;margin-top:5px;line-height:1.55}


/* ---------- 導覽列：手機上單行可左右滑 ---------- */
/* ---------- 品牌頁首與主選單（2026-10 改版）----------
   · 頁首：白底全寬，LOGO（向量檔）＋三地最後更新時間＋EN。照常捲走。
   · 主選單：接在頁首下方的全寬白條，**永遠置頂**。底邊是「地平線」，
     目前分頁的正下方升起一顆日出橘的半圓太陽，換頁時從上一頁滑過來。
     頁首捲走後細條左側淡入 GG 標記（回首頁）。
   · 日出橘只用在品牌元素（LOGO、太陽），不用在數據——紅綠藍已經有意思。 */
@font-face{font-family:"Montserrat";font-style:normal;font-weight:400 800;font-display:swap;
  src:url(/brand/montserrat-latin.woff2) format("woff2");
  unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,
    U+0304,U+0308,U+0329,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD}
:root{--brand-navy:#12233B;--brand-orange:#E67143;--navh:52px}
.brandwrap{background:var(--bg);border-bottom:1px solid rgba(18,35,59,.07)}
.brandbar{max-width:1120px;margin:0 auto;padding:16px 20px 18px;display:flex;
  align-items:center;gap:18px;box-sizing:border-box}
.brand{display:block;line-height:0;flex:none}
.brand img{display:block;max-width:none}
.brand .logo-full{height:62px;width:auto}
.brand .logo-compact{display:none;height:30px;width:auto}
.upd{margin-left:auto;display:grid;grid-template-columns:auto repeat(3,auto);
  align-items:end;column-gap:22px}
.upd-k{font-size:11.5px;color:var(--muted);letter-spacing:.04em;padding-bottom:3px}
.upd-d{display:none}
.upd-c{display:grid;line-height:1.15}
.upd-c span{font-size:11.5px;color:var(--muted)}
.upd-c b{font-weight:700;font-size:19px;color:var(--brand-ink);
  font-variant-numeric:tabular-nums;letter-spacing:.01em}
.upd-c i{font-style:normal;font-size:11px;color:#8a8983;font-variant-numeric:tabular-nums}
.brandbar .lang-btn{position:static;align-self:flex-start;margin-left:6px;
  border-color:rgba(18,35,59,.25);color:var(--brand-ink)}
.sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;
  clip:rect(0,0,0,0);white-space:nowrap;border:0}
.bnav{position:sticky;top:0;z-index:20;background:var(--bg);
  border-bottom:1px solid rgba(18,35,59,.16);transition:box-shadow .2s ease}
.bnav.stuck{box-shadow:0 8px 14px -12px rgba(18,35,59,.35)}
.bnav-in{position:relative;max-width:1120px;margin:0 auto;padding:0 20px;display:flex;
  align-items:stretch;height:var(--navh);box-sizing:border-box}
.bnav-mark{display:flex;align-items:center;flex:none;width:0;opacity:0;overflow:hidden;
  transition:width .22s ease,opacity .22s ease,margin .22s ease}
.bnav-mark img{height:24px;width:auto;display:block;max-width:none}
.bnav.stuck .bnav-mark{width:56px;opacity:1;margin-right:10px}
.bnav-tabs{position:relative;flex:1;min-width:0;overflow-x:auto;overflow-y:hidden;
  -webkit-overflow-scrolling:touch;scrollbar-width:none}
.bnav-tabs::-webkit-scrollbar{display:none}
.bnav-track{position:relative;display:flex;height:100%;width:max-content}
.bnav-track a{display:flex;align-items:center;padding:0 16px;font-size:14.5px;
  letter-spacing:.02em;color:var(--muted);text-decoration:none;white-space:nowrap}
.bnav-track a:first-child{padding-left:2px}
.bnav-track a:hover{color:var(--brand-ink)}
.bnav-track a.on{color:var(--brand-ink);font-weight:700}
.bnav-track a.soon{color:var(--baseline)}
.bnav-sun{position:absolute;bottom:0;left:-40px;width:20px;height:10px;margin-left:-10px;
  border-radius:20px 20px 0 0;background:var(--brand-orange);pointer-events:none;
  transition:left .32s cubic-bezier(.3,.7,.2,1)}
.bnav-glow{position:absolute;bottom:-1px;left:-200px;height:2px;width:240px;margin-left:-120px;
  pointer-events:none;background:linear-gradient(90deg,transparent,rgba(230,113,67,.75),transparent);
  transition:left .32s cubic-bezier(.3,.7,.2,1)}
@media(prefers-reduced-motion:reduce){.bnav-sun,.bnav-glow,.bnav-mark{transition:none}}
.bnav-fade{position:absolute;top:0;bottom:1px;width:30px;pointer-events:none;opacity:0;
  transition:opacity .15s}
.bnav-fade.l{left:0;background:linear-gradient(90deg,#fff 30%,transparent)}
.bnav-fade.r{right:0;background:linear-gradient(270deg,#fff 30%,transparent)}
.bnav.fl .bnav-fade.l,.bnav.fr .bnav-fade.r{opacity:1}
.pagehead{margin:4px 0 2px}
.pagehead h1{color:var(--brand-ink)}
@media(max-width:759px){
  :root{--navh:46px}
  .brandbar{padding:12px 14px;flex-wrap:wrap;row-gap:10px;column-gap:8px}
  .brand .logo-full{display:none}
  .brand .logo-compact{display:block}
  .brandbar .theme-btn{margin-left:auto;width:44px;height:44px;align-self:center}
  .brandbar .lang-btn{margin-left:0;min-width:44px;align-self:center}
  .upd{order:3;width:100%;margin-left:0;grid-template-columns:auto 1fr 1fr 1fr;
    column-gap:8px;align-items:baseline;border-top:1px dashed rgba(18,35,59,.15);padding-top:7px}
  .upd-k{padding:0;font-size:11px}
  .upd-d{display:inline;font-size:11px;color:#8a8983;margin-left:4px}
  .upd-c{display:block;white-space:nowrap}
  .upd-c span{font-size:11px;margin-right:4px}
  .upd-c b{font-size:14.5px}
  .upd-c i{display:none}
  .bnav-in{padding:0 0 0 14px}
  .bnav-track a{padding:0 12px;font-size:14px}
  .bnav-track a:last-child{padding-right:18px}
  .bnav.stuck .bnav-mark{width:44px;margin-right:4px}
  .bnav-mark img{height:20px}
}

/* 兩種 banner 共用外觀，但行為不同：
   · div.banner   資料停止更新的警告——**要處理**的事，一律展開
   · details.banner 離線示範的免責——每頁一字不差，收成一行
   免責在 390px 下展開是 134px，佔 16% 的首屏，而且讀者第二頁就不會再讀它，
   卻照樣把第一張卡推到摺線以下（rates 頁只露出 7px）。 */
.banner{background:var(--surface-1);border:1px solid var(--warning);
  border-left-width:3px;border-radius:10px;padding:11px 14px;margin:12px 0 0;
  font-size:13px;color:var(--text-secondary);line-height:1.7}
.banner b{color:var(--warning)}
details.banner{padding:0}
details.banner>summary{padding:11px 34px 11px 14px;font-size:13px;
  color:var(--text-secondary);line-height:1.6;position:relative;
  list-style:none;font-weight:400}
details.banner>summary::-webkit-details-marker{display:none}
/* 卡片級收合統一用右側 ▾/▴（跟 .sect 同一家族），不再自畫旋轉箭頭 */
details.banner>summary::after{content:"▾";position:absolute;right:15px;
  top:50%;transform:translateY(-50%);font-size:11px;color:var(--muted)}
details.banner[open]>summary::after{content:"▴"}
.banner-body{padding:0 14px 12px;font-size:13px;line-height:1.7;
  color:var(--text-secondary)}

/* ---------- 版面網格 ---------- */
.grid{display:grid;gap:13px;margin-top:13px;grid-template-columns:1fr}
/* 網格項目預設 min-width:auto，裡面只要有一個不能再窄的東西（寬表格、
   長串數字），整欄就會被撐開，連帶把整頁推得比視窗寬。歸零之後，
   撐不下的內容由它自己的捲動容器處理，版面不受影響。 */
.grid>*{min-width:0}
@media(min-width:760px){
  .grid{gap:14px;margin-top:14px}
  /* 並排卡各自貼頂：兩張卡內容量不同時，不再互相拉成等高、
     讓短的那張底部拖一段空白（跟 KPI 內層卡同一個道理）。 */
  .g2{grid-template-columns:repeat(2,1fr);align-items:start}
  .g4{grid-template-columns:repeat(2,1fr)}
  /* 模組卡有五張。四欄會排成 4+1，最後一張孤零零的；三欄的 3+2 比較穩。 */
  .g5{grid-template-columns:repeat(2,1fr)}
}
@media(min-width:1040px){
  .g4{grid-template-columns:repeat(4,1fr)}
  .g5{grid-template-columns:repeat(3,1fr)}
}
@media(min-width:1320px){.g5{grid-template-columns:repeat(5,1fr)}}

.card{background:var(--surface-1);border:1px solid var(--border);
  border-radius:13px;padding:17px 16px;box-shadow:var(--shadow);min-width:0}
@media(min-width:760px){.card{padding:18px 20px}}
.card h2{font-size:17px;margin:0 0 5px;font-weight:700;line-height:1.5}
.card h3{font-size:15px;margin:22px 0 4px;font-weight:700}
.card .hint{font-size:13px;color:var(--muted);margin:0 0 15px;line-height:1.65}
.card .src{font-size:12px;color:var(--muted);margin-top:15px;padding-top:11px;
  border-top:1px solid var(--border);line-height:1.6}

/* ---------- 可收合的卡區 ----------
   每一頁只有最上方的結論卡與緊接著的第一張內容卡是常開的，其餘預設收合。
   理由是每個人要看的那一塊不一樣：看勞動的人不需要每次都捲過行業分解，
   看行業分解的人也不需要每次先讀完修正追蹤。收合之後整頁變成一張
   可以一眼掃完的清單。

   關鍵在 .sect-sum：收合的標題列一定要帶一句結論，否則讀者得逐一點開
   才知道哪張有事——那比不收合還糟。 */
.sect{padding:0}                       /* 內距移到 summary 與 sect-body */
.sect>summary{list-style:none;cursor:pointer;padding:15px 16px;
  display:grid;grid-template-columns:1fr auto;align-items:baseline;
  gap:2px 12px;border-radius:13px}
@media(min-width:760px){.sect>summary{padding:16px 20px}}
.sect>summary::-webkit-details-marker{display:none}
.sect>summary::after{content:"▾";grid-column:2;grid-row:1;
  font-size:12px;color:var(--muted)}
.sect[open]>summary::after{content:"▴"}
.sect>summary:hover{background:var(--surface-2)}
.sect>summary:focus-visible{outline:2px solid var(--series-1);outline-offset:-2px}
/* 標題要壓回一般文字色。通用的 summary{color:var(--series-1)} 會被繼承下來，
   於是收合清單上每一列變成「**藍色 17px 粗體的標籤**（每期都一樣的字）
   ＋ 灰色 12.5px 的數值（本期新的東西）」——層級剛好反過來，
   視線先被七八個藍色標題抓住，真正的本期數字反而要停下來對焦。
   而且藍色＝連結是既有的心理模型，讀者會不確定點下去是展開還是換頁。 */
.sect>summary h2{margin:0;grid-column:1;grid-row:1;color:var(--text-primary)}
/* 摘要句：收合時是「要不要點開」的唯一依據；展開後內容自己會講，藏起來。
   顏色提到 --text-secondary：它是這一列上唯一會變的東西，
   壓成 --muted 的話比旁邊的固定標籤還不顯眼。 */
/* font-weight 一定要寫死：summary 是 600，不覆寫的話摘要會繼承成粗體，
   一整列變成「粗體標題 ＋ 粗體摘要」，兩者又打平了。 */
.sect-sum{grid-column:1;grid-row:2;font-size:12.5px;font-weight:400;
  color:var(--text-secondary);
  line-height:1.6;padding-right:4px;
  /* 中文預設可以在**任意兩個字之間**斷行，於是收合清單上出現
     「利升⏎息」「長端承壓最⏎重」這種第二行只有一個字的斷法——
     而這一列的用途就是掃視，掃視靠的是在一行內抓完整詞組。
     keep-all 只允許在空白與標點處斷；真的塞不下時再由
     overflow-wrap 放行，避免撐破卡片。 */
  word-break:keep-all;overflow-wrap:break-word}
.sect[open] .sect-sum{display:none}
.sect-body{padding:0 16px 17px}
@media(min-width:760px){.sect-body{padding:0 20px 18px}}
.sect-body>:first-child{margin-top:2px}

/* 「關鍵數字」那一區是四張 KPI 卡包在一張卡裡。卡中卡會有兩層底色與
   兩層陰影，看起來像出錯——內層改成只用分隔線區隔。 */
.grid.inner{margin-top:2px;gap:0}
.grid.inner>.card{background:transparent;border:none;box-shadow:none;
  border-radius:0;padding:15px 0;border-bottom:1px solid var(--grid)}
.grid.inner>.card:last-child{border-bottom:none;padding-bottom:2px}
.grid.inner>.card:first-child{padding-top:4px}
@media(min-width:760px){
  .grid.inner{gap:0 22px}
  /* 桌機並排時：
     ① padding 統一——first/last-child 的手機特例（4px／2px）在四欄
        並排下會讓第一張標題高 15px、第四張的收合列低 21px（實測）。
     ② 卡片各自貼頂（align-items:start）＝展開「近 5 期」時只有那張卡
        往下長，其他三張不動；先前整列被拉成等高，沒開的卡的置底
        收合列會掉到被撐高的列底，跟內容之間空一大段。
     ③ 底線拿掉——欄與欄之間有間距就夠，橫線在四欄下反而像表格框。 */
  .grid.inner{align-items:start}
  .grid.inner>.card{padding:6px 0 10px;border-bottom:none}
  .grid.inner>.card:first-child{padding-top:6px}
  .grid.inner>.card:last-child{padding-bottom:10px}
}

/* 展開全部／收合全部。收合狀態下瀏覽器的 Ctrl+F 找不到內文
   （hidden-until-found 支援度還不齊），所以這一列不是方便，是補償。 */
.sect-tools{display:flex;gap:8px;margin:12px 0 0}
.sect-tools button{font:inherit;font-size:12.5px;font-weight:600;cursor:pointer;
  color:var(--text-secondary);background:var(--surface-1);
  border:1px solid var(--border);border-radius:8px;padding:11px 13px}
.sect-tools button:hover{border-color:var(--text-secondary);
  color:var(--text-primary)}
.sect-tools button:focus-visible{outline:2px solid var(--series-1);
  outline-offset:2px}

/* 置頂的主選單（＋章節列）會蓋住跳轉目標的上緣，讓出空間 */
[id],.sect{scroll-margin-top:calc(var(--navh) + 58px)}
/* 錨點跳過來的那一區給一個外框，否則展開之後看不出跳到哪一張 */
.sect:target>summary{box-shadow:0 0 0 2px var(--series-1) inset}

/* 列印／存成 PDF 時全部展開。JS 另有 beforeprint 保險——
   新版 Chrome 用 content-visibility 實作收合，純 CSS 不一定壓得過。 */
@media print{
  .sect-tools,.bnav,.anav,.lang-btn{display:none}
  .sect>summary::after,.sect-sum{display:none}
  details>*:not(summary){display:block!important}
}

/* ---------- 結論卡 ---------- */
.verdict{background:var(--surface-1);border:1px solid var(--border);
  border-radius:13px;padding:19px 17px;box-shadow:var(--shadow);margin-top:13px;
  border-left:4px solid var(--muted)}
@media(min-width:760px){.verdict{padding:24px 24px}}
.verdict.dovish{border-left-color:var(--series-1)}
.verdict.hawkish{border-left-color:var(--serious)}
.verdict.balanced{border-left-color:var(--muted)}
/* 情境頁的傾向可能是 neutral（反應函數把方向改寫成中性時），
   沒有這條規則那張卡就只剩預設灰邊，看起來像漏了樣式 */
.verdict.neutral{border-left-color:var(--muted)}
.v-eyebrow{font-size:12.5px;color:var(--muted)}
/* 結論卡的字必須大於任何單一 KPI 數字。手機上原本是結論 26px、
   KPI 32px，等於在版面上宣告「單一數字比整體結論重要」——
   讀者的視線會先落在某個指標上，再回頭找結論。 */
.v-main{font-size:29px;font-weight:700;margin-top:9px;line-height:1.4}
@media(min-width:760px){.v-main{font-size:34px}}
/* 360px 上「停滯性通膨：通膨優先」這種長情境名，最後一個字會單獨掉到
   第二行。中文沒有連字號可斷，只能把字級縮一級——孤字比小一點的字礙眼。 */
@media(max-width:400px){.v-main{font-size:26px;letter-spacing:.02em}}
.v-why{font-size:14.5px;color:var(--text-secondary);margin-top:12px;line-height:1.85}
.v-count{font-size:12.5px;color:var(--muted);margin-top:15px;padding-top:13px;
  border-top:1px solid var(--border);line-height:1.75}
/* 結論卡底部通往情境頁的出口。做成一整塊可點的區域而不是一行文字連結：
   它是首頁唯一通往「該怎麼擺部位」的路，而讀者剛看完同一段結論，
   一條灰色小字連結不足以說服他「後面還有沒看過的東西」。
   副標明講後面有什麼是首頁沒有的。 */

/* ---------- KPI ---------- */
.kpi .k-label{font-size:13px;color:var(--text-secondary);font-weight:600}
.kpi .k-value{font-size:26px;font-weight:700;line-height:1.2;margin-top:5px}
@media(min-width:760px){.kpi .k-value{font-size:30px}}
/* ≤400px 時 .v-main 會降到 26px。KPI 數字、分數軸、結論值列若也留在
   26px，一頁上就有四種同字級同字重的東西完全平手——沒有主從等於沒有層級，
   讀者不知道該先看哪個。手機上把這三個降一級，讓結論那一句穩穩壓過去。 */
@media(max-width:400px){.kpi .k-value{font-size:24px}}
/* 英文為主、中文降成副標：對照 BLS 新聞稿與英文報導時，中文譯名對不起來。 */
.kpi .k-label-zh{font-size:12px;color:var(--muted);margin-top:2px;font-weight:500}
.kpi .k-sub{font-size:12.5px;color:var(--muted);margin-top:6px}
/* chips 列：水準／變化標籤與徽章（動能、修正、成因）合成**同一種樣式**。
   先前 k-lean、k-flag、意外行各一種視覺，每張卡都要重新學一次
   「哪行是重點」；統一之後掃一列就知道方向。水準與變化仍各一顆——
   同一張卡可以「仍高於目標」又「本期在降」，兩件事都成立，
   擠成一個標籤只會互相矛盾。 */
.kpi .k-chips{display:flex;flex-wrap:wrap;gap:6px;margin-top:9px}
.kpi .k-chip{font-size:11.5px;font-weight:600;padding:3px 8px;border-radius:6px;
  background:var(--surface-2);color:var(--text-secondary)}
.kpi .k-chip.hawkish,.kpi .k-chip.neg{color:var(--critical)}
.kpi .k-chip.dovish,.kpi .k-chip.pos{color:var(--good)}
.kpi .k-chip.watch{color:var(--warning)}
.kpi .k-plain{font-size:13.5px;color:var(--text-primary);margin-top:11px;
  line-height:1.75;background:var(--surface-2);border-radius:9px;padding:10px 12px}
/* 收合層：近 5 期走勢、比較行、（非發布日的）預期比較。
   跟「依據」同視覺，要驗算才點。summary 上下 12px 把觸控高撐過 40px。 */
.kpi .k-more{margin:2px 0 0;border:0;background:transparent}
.kpi .k-more>summary{cursor:pointer;list-style:none;font-size:12.5px;
  font-weight:500;color:var(--muted);padding:12px 0}
.kpi .k-more>summary:hover{color:var(--series-1)}
.kpi .k-more>summary::-webkit-details-marker{display:none}
.kpi .k-more>summary{padding-left:15px;text-indent:-15px}
.kpi .k-more>summary::before{content:"▸";display:inline-block;width:15px;
  text-indent:0}
.kpi .k-more[open]>summary::before{content:"▾"}
.kpi .k-more-body{padding-bottom:8px}
.kpi .k-more-body .k-sub{margin-top:2px}
/* 卡片直向 flex。手機（堆疊）收合列跟著內容走即可；
   桌機的對齊改用「各層固定最小高度」（見下方 @media 區塊），
   不再用「拉成同高＋收合列釘底」——那一套在展開任何一張的
   「近 5 期」時，會把沒開的卡的收合列釘到被撐高的列底，
   跟內容之間空出一大段（使用者實測回報的「展開方式怪異」）。 */
.kpi{display:flex;flex-direction:column}
@media(min-width:760px){
  /* 各層保留固定空間：標題（含期別章，至多兩行）、chips（至多兩列）、
     白話句（至多三行）。四張卡的每一層落在同一條水平線，
     「近 5 期」列收合時自然對齊，不必靠等高硬拉。 */
  .kpi .k-label{min-height:46px}
  .kpi .k-chips{min-height:56px;align-content:flex-start}
  .kpi .k-plain{min-height:92px}   /* 三行白話句的高度；兩行的卡框內留白 */
}
.spark{margin-top:11px;display:block;width:100%;height:64px}

/* ---------- 數字組（改用網格，手機兩欄對齊） ---------- */
.stat-row{display:grid;grid-template-columns:repeat(2,1fr);gap:16px 14px;
  margin-bottom:4px}
@media(min-width:760px){
  .stat-row{grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:18px}
}
.stat .s-label{font-size:12.5px;color:var(--muted);line-height:1.45}
/* 數值＋單位不能從中間斷開。「-0.10 個百分點」折成兩行時，
   讀者要多花一拍才確定那個單位屬於上面那個數字。 */
.stat .s-value{font-size:20px;font-weight:700;margin-top:4px;
  font-variant-numeric:tabular-nums;line-height:1.3;white-space:nowrap}
@media(max-width:420px){.stat .s-value{font-size:18px}}
/* 標籤長度不一時，數值會各自對到不同的基線。給標籤兩行的高度，
   同一列的數字才會落在同一條水平線上。
   只在 ≥760px 生效：那裡欄位是 auto-fit、每欄可能窄到讓長標籤折行，
   所以需要預留。手機固定兩欄、每欄約 160px，多數標籤本來就是一行，
   硬撐兩行等於每個 .stat 白白多出 18px——全站數十個 stat 累積起來
   接近一個螢幕高度的空白，而它換來的對齊在手機上根本用不到。 */
@media(min-width:760px){.stat .s-label{min-height:2.9em}}
.stat .s-note{font-size:12.5px;color:var(--text-secondary);margin-top:4px;
  line-height:1.55}

/* ---------- 表格 ---------- */
table{width:100%;border-collapse:collapse;font-size:13.5px;
  font-variant-numeric:tabular-nums}
/* 上下 11px：表格裡的儲存格常常放連結（原文申報、EDGAR 頁面），
   相鄰兩列的連結之間必須留得下手指。9px 時量到只剩 5.3px 的間距，
   低於 tools/audit_layout.py 的 8px 門檻。 */
th,td{text-align:right;padding:11px 5px;border-bottom:1px solid var(--grid)}
th:first-child,td:first-child{text-align:left}
th{color:var(--muted);font-weight:500;font-size:12px}
/* 最後一列多留一點下緣：那一列的儲存格常常是連結，而表格後面緊接著的
   往往是另一個可點的 summary。少了這幾 px，兩個觸控目標會靠到 8px 以內
   （tools/audit_layout.py 的門檻）。 */
tbody tr:last-child td{border-bottom:none;padding-bottom:15px}
td.pos{color:var(--good)} td.neg{color:var(--critical)}
td.muted-cell{color:var(--muted)}
.revtab td:first-child{font-variant-numeric:normal}
/* 儲存格裡的外部連結（EDGAR 申報書、聲明原文）只有 14–15px 高，
   在手機上幾乎按不到。用 inline-block 加上下內距把觸控區撐到 40px，
   再用等量的負 margin 抵銷，視覺上仍然只是一段文字。 */
td a[target="_blank"],.src a[target="_blank"]{
  display:inline-block;padding:12px 8px;margin:-12px -8px}
/* 欄位多的表格（例如科技巨頭那張六欄表）在 390px 上會把儲存格擠成
   一個字一行。包一層可橫向捲動的容器，寧可讓它滑，也不要把數字折斷。 */
/* 下緣留白：表格最後一列的儲存格常常放連結，而後面緊接著的往往是
   另一個可點的 summary。不留的話兩個觸控目標會靠到 7px 以內。 */
.tscroll{overflow-x:auto;-webkit-overflow-scrolling:touch;scrollbar-width:thin;
  margin-bottom:6px}
/* 橫捲表格的邊緣漸層：跟主選單同一套「還有更多」提示。
   .tscroll／.heatwrap 由 JS 包一層 .twrap，漸層畫在不捲動的外框上——
   熱力圖與寬表格在手機上被裁切時，先前沒有任何「還可以左右滑」的跡象，
   看起來像表格只有那幾欄。 */
.twrap{position:relative}
.twrap::before,.twrap::after{content:"";position:absolute;top:0;bottom:0;
  width:26px;pointer-events:none;opacity:0;transition:opacity .15s ease;z-index:1}
.twrap::before{left:0;background:linear-gradient(90deg,var(--surface-1),transparent)}
.twrap::after{right:0;background:linear-gradient(270deg,var(--surface-1),transparent)}
.twrap.fl::before{opacity:1}
.twrap.fr::after{opacity:1}
@media(prefers-reduced-motion:reduce){.twrap::before,.twrap::after{transition:none}}
/* 寫死 min-width 會讓明明放得下的表格也被迫捲動。改成「內容多寬就多寬，
   至少填滿容器」：塞得下就不捲，塞不下才捲。 */
.tscroll>table{width:max-content;min-width:100%}
/* 會捲的表格把左右內距收窄一點，多爭取的空間常常剛好夠讓它不用捲 */
@media(max-width:520px){.tscroll th,.tscroll td{padding:11px 4px;font-size:13px}}

/* ---------- 發散長條（行業增減）---------- */
.dbars{display:flex;flex-direction:column;gap:3px;margin-top:4px}
.drow{display:grid;grid-template-columns:96px 1fr 76px;align-items:center;
  gap:8px;padding:4px 0;border-radius:6px}
@media(min-width:760px){.drow{grid-template-columns:150px 1fr 92px;gap:12px}}
/* 窄螢幕：名稱＋數值同一行（左右對齊）、長條整寬第二行。
   先前名稱獨立一行、下一行「長條＋數值」——長條從中央零軸浮在半空、
   數值在另一個角落，名稱／色條／數字三層錯位。 */
@media(max-width:520px){
  .drow{grid-template-columns:minmax(0,1fr) auto;row-gap:5px;padding:8px 0}
  .dlabel{grid-column:1;grid-row:1}
  .dval{grid-column:2;grid-row:1}
  .dtrack{grid-column:1 / -1;grid-row:2}
}
.drow:hover{background:var(--surface-2)}
.dlabel{font-size:12.5px;color:var(--text-secondary);line-height:1.35}
@media(min-width:760px){.dlabel{font-size:13.5px}}
/* 異常標示：列上只放一個 ▲ 小標記（整句理由掛在長條旁會把圖擠亂），
   完整理由集中在圖下方的 .dfoot 註腳——手機沒有 hover 也讀得到。 */
.dtag{display:inline-block;font-size:10px;font-weight:700;color:var(--warning);
  margin-left:5px;vertical-align:1px}
.dfoot{margin-top:10px;padding-top:8px;border-top:1px dashed var(--grid)}
.dfoot-line{font-size:11.5px;line-height:1.7;color:var(--text-secondary);
  margin:3px 0}
.dfoot-line b{font-weight:600}
.dfoot-mark{color:var(--warning);font-size:10px;font-weight:700;margin-right:5px}
.dnote{display:block;font-size:11.5px;color:var(--muted)}
.dtrack{position:relative;height:15px}
.dzero{position:absolute;left:50%;top:-1px;bottom:-1px;width:1px;
  background:var(--baseline)}
.dfill{position:absolute;top:0;bottom:0;border-radius:3px;min-width:2px}
.dfill.pos{background:var(--pos)} .dfill.neg{background:var(--neg)}
.dfill.muted{background:var(--muted-bar)}
.dval{font-size:12.5px;text-align:right;font-variant-numeric:tabular-nums;
  color:var(--text-secondary)}
@media(min-width:760px){.dval{font-size:13.5px}}
.dval.pos{color:var(--good)} .dval.neg{color:var(--critical)}
.dlegend{display:flex;flex-wrap:wrap;gap:12px;margin-top:12px;padding-top:11px;
  border-top:1px solid var(--grid);font-size:12px;color:var(--muted)}
.dlegend span{display:flex;align-items:center;gap:5px}
.dlegend i{width:10px;height:10px;border-radius:2px;display:inline-block}

/* ---------- 紅綠燈 ---------- */
/* 手機兩欄時每張卡不再被拉高到同列最高——說明文字長度差很多，
   齊高會讓短的那張有三到四成是空白，八張燈累積起來是一整個螢幕。
   ≥1040px 四欄時仍然齊高：那裡卡片小、齊高才看得出是一組。 */
.lights{display:grid;grid-template-columns:repeat(2,1fr);gap:9px;
  align-items:start}
@media(max-width:430px){.light{min-height:148px}}
@media(min-width:1040px){.lights{grid-template-columns:repeat(4,1fr);
  align-items:stretch}}
.light{background:var(--surface-2);border-radius:10px;padding:12px 12px;
  border:1px solid var(--border);display:flex;flex-direction:column}
.light .l-top{display:flex;align-items:center;gap:6px;font-size:12.5px;
  color:var(--text-secondary);font-weight:600;line-height:1.35}
.light .l-icon{font-size:10px;flex-shrink:0}
.light.good .l-icon,.light.good .l-state{color:var(--good)}
.light.warning .l-icon,.light.warning .l-state{color:var(--warning)}
.light.critical .l-icon,.light.critical .l-state{color:var(--critical)}
.light.unknown .l-icon,.light.unknown .l-state{color:var(--muted)}
/* 數值與單位不能斷開：「4.3 個百分點」折成兩行時，
   讀者要多花一拍才能確定那個單位屬於上面那個數字。
   手機兩欄只有約 160px 寬，22px 的字放不下較長的值，所以一併縮一級。 */
.light .l-value{font-size:22px;font-weight:700;margin-top:8px;
  font-variant-numeric:tabular-nums;line-height:1.2;white-space:nowrap}
@media(max-width:420px){.light .l-value{font-size:19px}}
.light .l-state{font-size:12px;margin-top:5px;font-weight:700}
.light .l-desc{font-size:12px;color:var(--muted);margin-top:7px;line-height:1.55;
  margin-bottom:0}

/* 失業缺口 u − u*：水準的位置，跟上面那段「變化的成因」是兩件事，
   所以用一條分隔線隔開，而不是再開一張卡。 */
/* margin-bottom：這一塊底下緊接著「失業結構」的展開列，
   兩個觸控盒之間要留得出間距（版面稽核的下限是 8px）。 */
.ugap{margin-top:16px;margin-bottom:8px;padding-top:13px;
  border-top:1px solid var(--border)}
.ug-top{display:flex;align-items:baseline;gap:9px;flex-wrap:wrap}
.ug-label{font-size:12.5px;color:var(--text-secondary);font-weight:600}
.ug-val{font-size:19px;font-weight:700;font-variant-numeric:tabular-nums;
  white-space:nowrap}
.ug-state{font-size:11px;font-weight:700;padding:1px 7px;border-radius:5px;
  background:var(--surface-2);color:var(--text-secondary)}
.ug-note{font-size:12.5px;color:var(--muted);line-height:1.75;margin-top:6px}

/* 失業結構：五個類別各一列。名稱、橫條、數值三欄，
   說明另起一行——手機上四欄並排會把每一欄擠成兩個字一行。 */
.ustruct{margin-top:12px}
.ustr-list{margin-top:12px;display:flex;flex-direction:column;gap:13px}
.ustr{display:grid;grid-template-columns:1fr auto;gap:3px 10px;
  align-items:center}
.us-name{font-size:13px;font-weight:600}
.us-bar{grid-column:1/-1;height:7px;background:var(--surface-2);
  border-radius:4px;overflow:hidden;order:3}
.us-bar i{display:block;height:100%;border-radius:4px;background:var(--muted-bar)}
.ustr.bad .us-bar i{background:var(--neg)}
.ustr.good .us-bar i{background:var(--pos)}
.us-val{font-size:14px;font-weight:700;font-variant-numeric:tabular-nums;
  white-space:nowrap;text-align:right}
.us-share{font-size:11.5px;font-weight:500;color:var(--muted);margin-left:6px}
.us-yoy{grid-column:1/-1;order:4;font-size:12px;color:var(--text-secondary);
  font-variant-numeric:tabular-nums}
.us-note{grid-column:1/-1;order:5;font-size:12px;color:var(--muted);
  line-height:1.6}

/* ---------- 訊號 ---------- */
.flag{display:flex;gap:10px;padding:16px 0;border-bottom:1px solid var(--grid)}
.flag:first-of-type{padding-top:2px}
.flag:last-child{border-bottom:none;padding-bottom:2px}
.flag .f-icon{font-size:10px;margin-top:6px;flex-shrink:0}
/* 行業別貢獻：兩組各一張長條 */
.att-grp{margin-top:16px}
.att-ghead{font-size:12.5px;font-weight:700;color:var(--text-secondary);
  padding-bottom:6px;border-bottom:1px solid var(--grid);margin-bottom:6px}
/* 本期關鍵訊號：最上面的一句總結＋分層小標 */
.sig-sum{margin:12px 0 4px;padding:11px 13px;border-radius:9px;
  background:var(--surface-2);font-size:13.5px;line-height:1.7}
.sig-sum b{display:block;font-size:14.5px;margin-bottom:2px}
.sig-sum span{color:var(--text-secondary)}
.sig-rest{margin-top:16px}
.pce-method{margin-top:14px}
.sig-rest>summary{font-weight:700}
.sig-tier{margin:16px 0 2px;font-size:11.5px;font-weight:700;letter-spacing:.06em;
  color:var(--muted)}
.sig-tier span{font-weight:500;letter-spacing:0}
.flag.alert .f-icon{color:var(--critical)}
.flag.watch .f-icon{color:var(--warning)}
.flag.info .f-icon{color:var(--muted)}
.flag .f-head{font-size:15.5px;font-weight:700;line-height:1.6}
.flag .f-detail{font-size:14px;color:var(--text-secondary);margin-top:7px;
  line-height:1.85}
.flag .f-tag{font-size:11.5px;color:var(--muted);border:1px solid var(--border);
  border-radius:5px;padding:1px 6px;margin-left:6px;white-space:nowrap;
  font-weight:500;vertical-align:2px}
.impact{display:inline-block;font-size:12.5px;font-weight:700;border-radius:7px;
  padding:5px 10px;margin-top:10px;line-height:1.5}
/* 帶底色的小標籤要另外壓深：在自己的淡底上，一般文字色只有 4.3–4.4:1 */
.impact.dovish{background:var(--tint-dov);color:#1d579e}
.impact.hawkish{background:var(--tint-haw);color:#8d3b1b}
.impact.neutral{background:var(--surface-2);color:var(--muted)}

/* 說明收合起來之後，「依據」這個開關要小、要低調——
   它是次要動作，不能跟訊號標題搶注意力。 */
/* margin-bottom 是觸控間距用的：這種展開列的下一個元素常常也是可點的
   （另一個展開列、表格裡的外部連結）。展開之後內容的最後一行離下一個
   觸控目標只有兩三 px 時，點錯的代價是收合掉一整張卡。 */
/* padding-top 而不是 margin-top：summary 是 .f-more 的第一個子元素，
   給它 margin 會跟父層的 margin **合併**（margin collapsing），實際只多出
   兩者的差額。要真的把觸控框推開必須用 padding——它不合併。
   前一個區塊常常是另一張表，最後一列的儲存格多半是連結。 */
.f-more{margin-top:4px;margin-bottom:8px;border-top:none;padding-top:6px}
/* 這一塊底下緊接著另一個展開列（失業結構），兩個觸控盒之間要留得出間距 */
/* 觸控目標至少 44px 高（WCAG 2.5.8 / Apple HIG）。字體維持 12.5px，
   靠上下 padding 把可點區域撐到 44px，並用負的 margin 抵銷多出來的
   視覺留白——看起來還是一個小開關，手指卻按得到。
   全站有十個這種開關，每一個都太小的話，收合設計本身就失效了。 */
/* 「依據」這種行內展開列。padding 撐高是為了觸控目標（13+13+16≈42px），
   但先前配 margin:-7px 0 去抵銷視覺高度——結果觸控盒比看起來的大 7px，
   兩個「看起來隔了 14px」的元素實際只差 0.9px。實測在勞動頁點最後一條訊號的
   「依據」，很容易變成收合掉整張卡（下一張卡的 summary 就在 0.9px 外），
   畫面瞬間跳掉一大段而讀者不知道發生什麼事。
   負 margin 只留上方（那一側沒有相鄰的可點元素），下方改用正常間距。 */
.f-more>summary{font-size:12.5px;font-weight:500;color:var(--muted);
  padding:13px 0 11px;margin:0;list-style:none}
.f-more>summary:hover{color:var(--series-1)}
/* 展開列的統一記號：前置 ▸（展開時 ▾）、主色。使用者的原話是
   「展開的視覺很不明確」——收合列先前只是一行灰字，跟普通註記
   長得一樣。記號放前面比尾巴的小箭頭醒目，且全站同一套。 */
.f-more>summary::-webkit-details-marker,
details[data-m-collapse]>summary::-webkit-details-marker{display:none}
.f-more>summary::after,details[data-m-collapse]>summary::after{content:""}
/* 懸掛縮排：▸ 佔固定 17px，折行後的第二行對齊記號之後的文字。
   沒有這個的話，寫在收合列上的長結論折行時第二行會頂到最左，
   看起來像一段內文而不是可點的列。 */
.f-more>summary,details[data-m-collapse]>summary{
  padding-left:17px;text-indent:-17px}
.f-more>summary::before,details[data-m-collapse]>summary::before{
  content:"▸";display:inline-block;width:17px;margin-right:0;text-indent:0;
  font-size:10px;color:var(--series-1)}
.f-more[open]>summary::before,details[data-m-collapse][open]>summary::before{
  content:"▾"}
details[data-m-collapse]>summary{list-style:none}
.f-more .f-detail{margin-top:2px}

/* ---------- 分數條 ---------- */
.score-bar{height:9px;background:var(--surface-2);border-radius:5px;
  position:relative;margin:15px 0 8px}
.score-bar i{position:absolute;top:0;bottom:0;border-radius:5px}
.score-mid{position:absolute;top:-3px;bottom:-3px;width:1px;
  background:var(--baseline);left:50%}

/* 分數軸：結論卡裡放 compact 版，明細卡裡放完整版，同一套樣式 */
.sax{margin-top:16px;padding-top:15px;border-top:1px solid var(--border)}
.sax.compact{margin-top:14px;padding-top:13px}
.sax-head{display:flex;align-items:baseline;gap:8px;flex-wrap:wrap}
.sax-label{font-size:12.5px;color:var(--muted)}
.sax-val{font-size:26px;font-weight:700;font-variant-numeric:tabular-nums;
  line-height:1.1}
@media(max-width:400px){.sax-val{font-size:24px}}
.sax.compact .sax-val{font-size:22px}
.sax-delta{font-size:12.5px;color:var(--text-secondary)}
.sax-scale{display:flex;justify-content:space-between;font-size:11.5px;
  color:var(--muted)}

/* KPI 卡裡的「vs 預期」一行 */
.k-surp{margin-top:9px;padding:7px 10px;border-radius:8px;font-size:12.5px;
  line-height:1.7;background:var(--surface-2);color:var(--text-secondary)}
.k-surp.beat{background:rgba(7,124,7,.09)}
.k-surp.miss{background:rgba(194,47,47,.09)}
.k-surp .ks-sep{margin:0 6px;color:var(--muted)}
.k-surp .ks-diff{font-weight:700;color:var(--text-primary)}
.k-surp .ks-verdict{display:inline-block;margin-left:7px;font-weight:700}
.k-surp.beat .ks-verdict{color:#036b03}
.k-surp.miss .ks-verdict{color:#ad2929}
.k-surp .ks-z{display:block;font-size:11.5px;color:var(--muted);margin-top:1px}
.k-surp .ks-star{color:var(--warning);font-weight:700}
.k-surp .su{font-size:11px;color:var(--muted);margin-left:1px}
.kpi-foot{font-size:12px;color:var(--muted);line-height:1.7;margin-top:10px;
  padding:0 2px}
.kpi-foot.warn{background:var(--surface-1);border:1px solid var(--border);
  border-left:3px solid var(--warning);border-radius:9px;padding:11px 13px}
.kpi-foot b{color:var(--text-primary)}

/* 失業率變動分解：結論在上、拆解在下，兩項相加等於總變動 */
.dsum{padding-bottom:14px;border-bottom:1px solid var(--grid)}
.dsum-main{font-size:22px;font-weight:700;line-height:1.35}
.dsum-sub{font-size:13px;color:var(--text-secondary);margin-top:5px}
/* 失業率變動分解（2026-10 改版）：上月→本月、一條零軸上的推高／壓低、合計 */
.ub-head{display:flex;align-items:baseline;flex-wrap:wrap;gap:4px 10px;
  margin:4px 0 2px;font-variant-numeric:tabular-nums}
.ub-from{font-size:20px;font-weight:600;color:var(--muted)}
.ub-arrow{font-size:18px;color:var(--muted)}
.ub-head b{font-size:30px;font-weight:800;color:var(--text-primary)}
.ub-d{font-size:14px;font-weight:700;color:var(--text-secondary)}
.ub-tag{font-size:11px;font-weight:600;color:var(--muted);border:1px solid var(--border);
  border-radius:5px;padding:2px 7px}
.ubridge{margin-top:16px}
.ub-axis{display:flex;justify-content:space-between;font-size:11px;
  color:var(--muted);padding:0 0 6px;margin-left:calc(38% + 12px);margin-right:62px}
.ub-row{display:grid;grid-template-columns:38% 1fr 50px;gap:12px;align-items:center;
  padding:9px 0;border-top:1px solid var(--grid)}
.ub-row.total{border-top:1.5px solid var(--text-secondary)}
.ub-name{font-size:13.5px;font-weight:600;color:var(--text-primary);line-height:1.45}
.ub-name span{display:block;font-size:11.5px;font-weight:400;color:var(--muted)}
.ub-bar{position:relative;height:18px}
.ub-zero{position:absolute;left:50%;top:-4px;bottom:-4px;width:1px;background:var(--baseline)}
.ub-bar i{position:absolute;top:0;bottom:0;border-radius:3px;min-width:2px}
.ub-bar i.up{background:var(--serious)}
.ub-bar i.dn{background:var(--series-1)}
.ub-bar i.tot{background:var(--text-secondary)}
.ub-val{font-size:15px;font-weight:700;text-align:right;font-variant-numeric:tabular-nums}
.ub-row.total .ub-val{font-size:16px}
.ub-note{font-size:11.5px;color:var(--muted);margin-top:6px;text-align:right}
@media(max-width:759px){
  .ub-axis{margin-left:0;margin-right:58px}
  .ub-row{grid-template-columns:1fr 50px;row-gap:6px}
  .ub-name{grid-column:1 / -1}
  .ub-bar{grid-column:1}
  .ub-val{grid-column:2}
}
.ub-bar i.rvdn{background:var(--neg)}
.ub-bar i.rvup{background:var(--pos)}
.ub-val.rv-none{font-size:12px;font-weight:500;color:var(--muted)}
.ubridge.rv .ub-row{padding:7px 0;grid-template-columns:38% 1fr 84px}
.ubridge.rv .ub-axis{margin-right:96px}
.ub-val{white-space:nowrap}
@media(max-width:759px){
  .ubridge.rv .ub-row{grid-template-columns:1fr 84px}
  .ubridge.rv .ub-axis{margin-right:92px}
}
.dcomp{margin-top:14px}
.dc-cap{font-size:12px;font-weight:600;color:var(--text-secondary);
  margin-top:2px}
/* 動能階梯：每個指數一列「12 → 6 → 3 個月年化」。
   取代先前的六格 stat——手機兩欄折行會把 CPI 與 PCE 混在同一列。 */
.ladder{margin-top:14px}
.ld-row{display:flex;align-items:baseline;gap:9px;padding:8px 0;
  border-bottom:1px solid var(--grid);font-variant-numeric:tabular-nums}
.ld-row:last-of-type{border-bottom:0}
.ld-k{min-width:34px;font-size:12.5px;color:var(--muted);font-weight:600}
.ld-v{font-size:16.5px;font-weight:700;color:var(--text-secondary)}
.ld-a{color:var(--muted);font-size:11px}
.ld-v.last{font-size:19px;color:var(--text-primary)}
.ld-v.last.accel{color:var(--serious)}
.ld-v.last.decel{color:var(--series-1)}
.ld-cap{font-size:11.5px;color:var(--muted);margin-top:7px;line-height:1.6}
/* 320px 級的窄機：字級不縮的話最右的 3 個月年化會被裁到卡片外——
   偏偏那是字級最大、最重要的一個數字。 */
@media(max-width:374px){
  .ld-row{gap:5px}
  .ld-k{min-width:26px;font-size:11.5px}
  .ld-v{font-size:14px}
  .ld-v.last{font-size:16px}
  .ld-a{font-size:10px}
}

.dc-row{display:grid;grid-template-columns:minmax(0,1.4fr) 1fr 74px;
  align-items:center;gap:9px;margin-top:10px}
@media(min-width:760px){.dc-row{gap:12px}}
/* 手機：名稱＋數字同一行（左右對齊）、長條整寬第二行。
   先前三欄硬擠 390px：名稱把「55.5 萬人」折成兩行、長條從畫面中央
   浮在半空、數字靠最右——三個元素各在各的位置。 */
@media(max-width:759px){
  .dc-row{grid-template-columns:minmax(0,1fr) auto;row-gap:7px}
  .dc-name{grid-column:1;grid-row:1}
  .dc-val{grid-column:2;grid-row:1}
  .dc-bar{grid-column:1 / -1;grid-row:2}
}
.dc-name{font-size:12.5px;color:var(--text-secondary);line-height:1.5}
.dc-val span{display:block;font-size:10.5px;font-weight:500;
  color:var(--muted)}
.dc-bar{position:relative;height:15px}
.dc-zero{position:absolute;left:50%;top:-1px;bottom:-1px;width:1px;
  background:var(--baseline)}
/* 這兩條刻意用中性色。整張卡的重點就是「正負不等於好壞」——
   勞動力效果是負的（壓低失業率），但成因是有人放棄找工作，那不是好消息。
   上成紅綠會把讀者導向完全相反的結論，方向由左右與文字說明表示。 */
.dc-bar i{position:absolute;top:0;bottom:0;border-radius:3px;min-width:2px;
  background:var(--muted-bar)}
.dc-val{font-size:14.5px;font-weight:700;text-align:right;
  font-variant-numeric:tabular-nums}
.dc-note{font-size:11.5px;color:var(--muted);line-height:1.6;
  margin:3px 0 0 0;padding-left:2px}
@media(min-width:760px){.dc-note{padding-left:108px}}
.dc-total{margin-top:13px;padding-top:11px;border-top:1px solid var(--grid);
  font-size:13px;font-weight:700;text-align:right;
  font-variant-numeric:tabular-nums}
/* 近似誤差：只有大到看得出來時才印，所以要低調——它是說明，不是警告 */
.dc-resid{font-size:11.5px;font-weight:400;color:var(--muted);white-space:nowrap}
/* 統計顯著性的但書。只有在變動小到不可分辨於零時才出現——
   放在加總那一行的正下方，因為它修飾的是那個數字，不是整張卡。 */
.dc-signif{margin-top:7px;font-size:11.5px;line-height:1.6;text-align:right;
  color:var(--warning)}

/* 一行橫排的輔助數值列（聯準會頁 2026-10 起不再使用，樣式保留） */
.tone-row{display:grid;grid-template-columns:auto auto 1fr;align-items:baseline;
  gap:6px 10px;margin-top:12px;padding:12px 14px;border-radius:10px;
  background:var(--surface-2)}
.tone-label{font-size:12.5px;color:var(--text-secondary);font-weight:600}
.tone-val{font-size:19px;font-weight:700;font-variant-numeric:tabular-nums}
.tone-row.hawkish .tone-val{color:var(--serious)}
.tone-row.dovish .tone-val{color:var(--series-1)}
.tone-row.neutral .tone-val{color:var(--muted)}
.tone-delta{font-size:12.5px;color:var(--muted);font-variant-numeric:tabular-nums;
  white-space:nowrap}
/* 三欄（標籤｜分數｜較上次）在 360px 只剩約 32px 給第三欄，
   「較上次 −0.12」會折成三行、每行兩三個字。窄螢幕改成兩欄，
   把變化量放到自己的一整行。 */
@media(max-width:520px){
  .tone-row{grid-template-columns:auto 1fr}
  .tone-delta{grid-column:1 / -1;margin-top:1px}
}
.tone-note{grid-column:1 / -1;font-size:12px;color:var(--muted);line-height:1.7}
.tone-flag{display:inline-block;margin-left:6px;font-size:10.5px;font-weight:700;
  color:var(--warning);border:1px solid var(--warning);border-radius:4px;
  padding:0 4px;vertical-align:1px}
/* 不可靠時把數字本身也調成灰的——它還在，但不該吸引視線 */
.tone-row.stale .tone-val{color:var(--muted)}

/* 離目標軸：跟分數軸共用外框，但刻度上有一個固定的錨點（2% 目標），
   填色是從目標畫到目前值——長度就是差距，方向就是高於還是低於。 */
.tgt-bar{height:9px;background:var(--surface-2);border-radius:5px;
  position:relative;margin:15px 0 8px}
.tgt-bar i{position:absolute;top:0;bottom:0;border-radius:5px}
.tgt-mark{position:absolute;top:-4px;bottom:-4px;width:2px;
  background:var(--text-primary);border-radius:1px;z-index:2}
.tgt-dot{position:absolute;top:50%;width:13px;height:13px;border-radius:50%;
  transform:translate(-50%,-50%);box-shadow:0 0 0 2px var(--surface-1);z-index:3}

/* 但書：掛在結論框裡面、縮排一階，明確是「對上面那句話的但書」，
   不是平行的第二個結論。兩個等重的警示框並排時讀者不知道該信哪個。 */
.caveat{margin-top:12px;padding:10px 12px;border-left:2px solid var(--warning);
  background:var(--surface-2);border-radius:0 8px 8px 0;
  font-size:13px;line-height:1.8;color:var(--text-secondary)}
.caveat b{color:var(--warning)}

/* 文字欄位靠右讀起來很彆扭。這個類別讓最後一欄（說明）改回靠左。 */
.lefty td:last-child,.lefty th:last-child{text-align:left}

/* 結論值列（原為損益兩平卡，該卡已移除；能源影響等處仍沿用此版式）：
   結論要比輸入值大 */
.bkgap{display:flex;align-items:baseline;gap:9px;flex-wrap:wrap;
  margin-top:14px;padding-top:13px;border-top:1px solid var(--grid)}
.bk-label{font-size:12.5px;color:var(--muted)}
.bk-val{font-size:26px;font-weight:700;font-variant-numeric:tabular-nums;
  line-height:1.1}
@media(max-width:400px){.bk-val{font-size:24px}}
.bk-verdict{font-size:13.5px;font-weight:700}

/* ---------- 首頁 ---------- */
/* .hero / .h-verdict 一族已隨首頁改版移除，樣式一併刪除 */

/* 三個政策模組的方向一致度：首頁獨有的資訊——分頁只能講自己那一塊，
   只有總覽能回答「三個觀點彼此同意嗎」。長端另外一格、不進票數，
   因為它回答的是曲線形狀而不是政策方向（見 README「長端供給壓力不進九宮格」）。 */
.cons{margin-top:15px;padding-top:14px;border-top:1px solid var(--border)}
.cons-row{display:grid;grid-template-columns:repeat(2,1fr);gap:8px}
@media(min-width:560px){.cons-row{grid-template-columns:repeat(3,1fr)}}
.cons-i{background:var(--surface-2);border-radius:9px;padding:9px 10px}
.cons-i.aside{background:transparent;border:1px dashed var(--border)}
.cons-aside{margin-top:9px}
.cons-aside .cons-row{grid-template-columns:1fr}
@media(min-width:560px){.cons-aside .cons-row{grid-template-columns:1fr}}
.cons-k{display:block;font-size:11.5px;color:var(--muted)}
.cons-v{display:block;font-size:14px;font-weight:700;margin-top:3px}
.cons-v.hawkish{color:var(--serious)} .cons-v.dovish{color:var(--series-1)}
.cons-v.neutral{color:var(--text-secondary)}
.cons-note{font-size:13px;color:var(--text-secondary);line-height:1.8;
  margin-top:11px}

/* 倒數：三個並排，日期與可信度說明在下方 */
.cds{display:grid;gap:9px;margin-top:10px}
@media(min-width:560px){.cds{grid-template-columns:repeat(3,1fr)}}
.cd{background:var(--surface-2);border-radius:9px;padding:11px 12px}
.cd-k{font-size:12px;color:var(--muted)}
.cd-d{font-size:19px;font-weight:700;margin-top:3px;
  font-variant-numeric:tabular-nums}
.cd-n{font-size:11.5px;color:var(--muted);margin-top:3px;line-height:1.6}

/* 接下來要盯什麼：門檻與距離 */
.wt{background:var(--surface-2);border-radius:9px;padding:11px 12px;
  margin-bottom:9px}
.wt-k{font-size:12.5px;color:var(--text-secondary);font-weight:600}
.wt-v{font-size:19px;font-weight:700;margin-top:3px;
  font-variant-numeric:tabular-nums}
.wt-n{font-size:11.5px;color:var(--muted);margin-top:3px;line-height:1.6}

/* 模組卡的方向章 */
.m-dir{display:inline-block;margin-left:9px;font-size:11.5px;font-weight:700;
  padding:2px 7px;border-radius:6px;vertical-align:3px;background:var(--surface-2)}
.m-dir.hawkish{color:#8d3b1b;background:var(--tint-haw)}
.m-dir.dovish{color:#1d579e;background:var(--tint-dov)}
.m-dir.neutral{color:var(--muted)}

.modcard{display:block;text-decoration:none;color:inherit;
  background:var(--surface-1);border:1px solid var(--border);border-radius:13px;
  padding:16px;box-shadow:var(--shadow);transition:border-color .12s}
.modcard:hover{border-color:var(--text-secondary)}
.modcard.pending{opacity:.6}
.modcard .m-top{display:flex;justify-content:space-between;align-items:baseline;gap:8px}
.modcard .m-name{font-size:14.5px;font-weight:700}
.modcard .m-when{font-size:11.5px;color:var(--muted);white-space:nowrap}
.modcard .m-value{font-size:27px;font-weight:700;margin-top:9px;line-height:1.2}
/* 結論卡的字必須大於任何單一數字（見 .v-main 的說明）。.v-main 在 ≤400px
   會降到 26px，這裡沒有跟著降的話首頁最大的字會變成四張模組卡的數字——
   等於在版面上宣告「單一數字比整體結論重要」。剛好 400px 以下就是
   iPhone 的標準寬度，所以這個破口只在最常見的手機上出現。 */
@media(max-width:400px){.modcard .m-value{font-size:23px}}
/* 13px 時「期限溢酬 +0.78%」剛好多 5px 塞不下，數字會單獨掉到第二行，
   整張卡多一行、同列的另一張卡連結就對不齊了。 */
.modcard .m-note{font-size:12.5px;color:var(--text-secondary);margin-top:7px;
  line-height:1.7}
.modcard .m-more{font-size:12.5px;color:var(--muted);margin-top:12px}

.soonbox{background:var(--surface-1);border:1px solid var(--border);
  border-radius:13px;padding:34px 20px;text-align:center;box-shadow:var(--shadow);
  margin-top:13px}
.soonbox h3{font-size:16px;margin:0 0 10px}
.soonbox p{font-size:14px;color:var(--text-secondary);margin:0 auto;max-width:520px;
  line-height:1.85}

.archive-list{list-style:none;padding:0;margin:0}
.archive-list li{border-bottom:1px solid var(--grid)}
.archive-list li:last-child{border-bottom:none}
/* 兩列之間先前只隔 1.0px（就是那條 border）——點錯月份的機率很高。
   分隔線留著，但兩個觸控盒之間要有肉眼看得出來的間距。 */
.archive-list li{padding:5px 0}
.archive-list a{display:flex;justify-content:space-between;gap:12px;
  padding:13px 8px;border-radius:8px;
  text-decoration:none;color:var(--text-primary);font-size:14px}
.archive-list a:hover{background:var(--surface-2)}
.archive-list a:hover{color:var(--series-1)}
.archive-list .a-meta{color:var(--muted);font-size:12.5px}

/* ---------- 名詞解釋 ---------- */
.teach-more{font-size:13px;margin:8px 0 0}
.teach-more a{color:var(--brand-orange);font-weight:700;text-decoration:none}
.gloss,.poslist{margin:6px 0 0}
.gloss dt,.poslist dt{font-weight:700;font-size:13.5px;margin-top:13px}
.gloss dt:first-child,.poslist dt:first-child{margin-top:0}
.gloss dd,.poslist dd{margin:3px 0 0;color:var(--text-secondary);font-size:13px;line-height:1.75}
@media(min-width:760px){
  .gloss{display:grid;grid-template-columns:130px 1fr;gap:11px 18px}
  .gloss dt{margin-top:0} .gloss dd{margin-top:0}
}

/* ---------- 折疊 ---------- */
details{margin-top:14px;border-top:1px solid var(--grid);padding-top:12px}
details[open]{padding-bottom:2px}
/* 展開列是全站最常點的東西，高度要撐到 44px 才好按 */
summary{font-size:13.5px;color:var(--series-1);cursor:pointer;font-weight:600;
  list-style:none;padding:12px 0}
summary::-webkit-details-marker{display:none}
/* 全域的「結尾 ▾/▴」規則已刪除：它跟各收合家族自己的記號疊在一起，
   開啟狀態時（details[open] 權重較高）還會蓋過抑制規則，造成
   「▾ 標題 ▴」頭尾雙箭頭。現在每一種收合都有自己的記號：
   卡片級 .sect＝右上 ▾/▴、卡內 .f-more／data-m-collapse／.k-more／
   .l-more＝開頭 ▸/▾、teach＝？圓章、首頁模組＝＋/－。
   （目前全站的收合元素都有自己的類別，所以不需要全域後備。） */
details.plain{border-top:none;padding-top:0}

/* ---------- 換頁動線 ---------- */
/* MPA 換頁改成交叉淡入（View Transitions）：支援的瀏覽器不再白屏閃一下。
   使用者關掉動態效果時停用。 */
@view-transition{navigation:auto}
@media(prefers-reduced-motion:reduce){
  ::view-transition-group(*),::view-transition-old(*),
  ::view-transition-new(*){animation:none!important}}
/* 頁尾的上一頁／下一頁 */
.pagenav{display:flex;justify-content:space-between;gap:10px;margin-top:22px}
.pagenav a{display:flex;flex-direction:column;gap:3px;padding:13px 16px;
  min-width:130px;max-width:48%;border:1px solid var(--border);border-radius:11px;
  background:var(--surface-1);text-decoration:none;font-size:11.5px;
  color:var(--muted)}
.pagenav a b{font-size:14px;color:var(--text-primary)}
.pagenav a:hover{background:var(--surface-2)}
.pagenav .pn-next{margin-left:auto;text-align:right;align-items:flex-end}

.empty{font-size:13px;color:var(--muted);padding:22px 0;text-align:center}
/* 不斷行的小工具。日期預設會在連字號處斷成「2026-⏎07-29」，
   那看起來像兩個殘缺的數字。 */
.nb{white-space:nowrap}

#tip{position:fixed;pointer-events:none;background:var(--surface-2);
  border:1px solid var(--border);border-radius:8px;padding:7px 11px;font-size:13px;
  color:var(--text-primary);opacity:0;transition:opacity .1s;z-index:99;
  /* 這個 30% 黑的陰影是深色模式時代留下的，在淺色底上會糊成一團灰塊 */
  box-shadow:0 4px 14px rgba(15,23,42,.13);white-space:nowrap}
@media(hover:none){#tip{display:none}}

footer{margin-top:26px;font-size:12.5px;color:var(--muted);line-height:1.8}

/* ---------- 聲明配對比對 ---------- */
.drow2{border:1px solid var(--border);border-radius:10px;padding:11px 13px;
  margin-bottom:9px;background:var(--surface-1)}
.drow2 .dlabel2{font-size:11.5px;font-weight:700;color:var(--muted);
  letter-spacing:.05em;margin-bottom:7px}
.drow2 .dold,.drow2 .dnew{font-size:13.5px;line-height:1.85;padding:7px 10px;
  border-radius:7px}
.drow2 .dold{background:var(--surface-2);color:var(--muted);margin-bottom:6px}
.drow2 .dnew{background:var(--tint-dov)}
.drow2 .darrow{font-size:11px;color:var(--muted);margin:2px 0 4px}
.drow2.added{border-left:3px solid var(--series-1)}
.drow2.removed{border-left:3px solid var(--muted)}
.drow2.changed{border-left:3px solid var(--serious)}
mark.mo{background:rgba(180,85,43,.18);color:#8d4220;
  text-decoration:line-through;text-decoration-thickness:1px;
  border-radius:3px;padding:0 2px}
mark.mn{background:rgba(42,120,214,.22);color:var(--text-primary);
  font-weight:600;border-radius:3px;padding:0 2px}
.dsame{font-size:12.5px;color:var(--muted);line-height:1.8;padding:5px 12px}
/* 記者會依主題抽出的原句 */
.pline{font-size:13.5px;line-height:1.85;color:var(--text-secondary);
  background:var(--surface-2);border-radius:8px;padding:10px 12px;margin-bottom:7px}

/* ---------- 雙分數並列 ---------- */
.dual{display:grid;grid-template-columns:1fr;gap:11px}
@media(min-width:600px){.dual{grid-template-columns:1fr 1fr}}
.dbox{background:var(--surface-2);border-radius:10px;padding:14px 14px;
  border:1px solid var(--border)}
.dbox.primary{border-color:var(--text-primary);border-width:1.5px}
.dbox .dtitle{font-size:12.5px;color:var(--text-secondary);font-weight:600}
/* 大數字不超過 .v-main：結論文字永遠比數字醒目。 */
.dbox .dscore{font-size:25px;font-weight:700;margin-top:7px;line-height:1.15;
  font-variant-numeric:tabular-nums}
@media(max-width:400px){.dbox .dscore{font-size:23px}}
.dbox .dlab{font-size:12.5px;font-weight:700;margin-top:5px}
.dbox .dnote{font-size:12px;color:var(--muted);margin-top:7px;line-height:1.6}
.dbox.hawkish .dlab{color:var(--serious)}
.dbox.dovish .dlab{color:var(--series-1)}
.dbox.neutral .dlab{color:var(--muted)}
/* 整塊套 opacity 會連內文一起壓暗——量到只剩 2.4:1，遠低於 4.5。
   改成只把數字與標籤調淡，說明文字維持原本的對比。 */
.dbox.stale{background:var(--surface-2);border-style:dashed}
/* 不用 opacity 壓字（會直接壓垮對比），改用虛線框＋底色表示「這一格別當真」 */
.dbox.stale .dscore{color:var(--text-secondary)}

.warnbox{background:var(--surface-1);border:1px solid var(--warning);
  border-left-width:3px;border-radius:10px;padding:13px 15px;margin-top:14px;
  font-size:13px;line-height:1.8;color:var(--text-secondary)}
.warnbox b{color:var(--warning)}

/* ---------- 投票 ---------- */
.votes{display:flex;flex-wrap:wrap;gap:7px;margin-top:10px}
.vchip{font-size:12px;border-radius:7px;padding:5px 10px;border:1px solid var(--border);
  background:var(--surface-2);color:var(--text-secondary)}
.vchip.hike{border-color:var(--serious);color:var(--serious);font-weight:600}
.vchip.cut{border-color:var(--series-1);color:var(--series-1);font-weight:600}

/* ---------- 措辭熱力圖 ---------- */
.heatwrap{overflow-x:auto;-webkit-overflow-scrolling:touch;margin-top:4px}
/* 全站 table{width:100%} 會把這張表撐到卡片寬，多出來的空間全被
   自動版面塞進第一欄——標籤因此跟自己那一列的格子隔了七百多 px，
   看起來像各自獨立的兩塊。改成內容寬即可，太寬時由 .heatwrap 捲動。 */
.heat{border-collapse:separate;border-spacing:3px;font-size:12px;
  width:max-content;min-width:0;max-width:100%}
.heat th{font-weight:500;color:var(--muted);font-size:11.5px;padding:2px 4px;
  white-space:nowrap;text-align:center;border:none}
.heat th.rowhead{text-align:left;position:sticky;left:0;background:var(--surface-1);
  padding-right:9px;min-width:132px;z-index:1}
.heat td{width:30px;height:26px;text-align:center;border-radius:5px;border:none;
  font-variant-numeric:tabular-nums;padding:0}
.heat td.h0{background:var(--surface-2);color:var(--muted)}
.heat td.h1{background:rgba(42,120,214,.28);color:var(--text-primary)}
/* 55% 藍上放白字只有 2.16:1，遠低於 WCAG 的 4.5。中間色階改用深色字，
   最深的那一階把底色加深到 95% 才撐得起白字。 */
.heat td.h2{background:rgba(42,120,214,.5);color:var(--text-primary)}
.heat td.h3{background:rgba(28,86,158,.97);color:#fff}

/* ---------- 體制頁籤（純 CSS，不依賴 JS）----------
   三張九宮格各一個 radio。選中的那個把對應的 .rpanel 顯示出來。
   用 :checked 加 ~ 相鄰選擇器，沒有 JS 也能切；鍵盤操作由 radio 原生支援。 */
.rtabs{margin-top:4px}
.rtab-in{position:absolute;opacity:0;pointer-events:none;width:0;height:0}
/* 頁籤是這一頁唯一的互動元件，觸控目標要有 44px（先前是 40.8px）。 */
.rtab{display:inline-block;font-size:13px;font-weight:600;cursor:pointer;
  padding:11px 14px;border-radius:9px;border:1px solid var(--border);
  background:var(--surface-1);color:var(--text-secondary);
  margin:0 6px 10px 0;white-space:nowrap}
.rtab:hover{border-color:var(--text-secondary);color:var(--text-primary)}
.rtab-in:checked + .rtab{background:var(--text-primary);color:var(--surface-1);
  border-color:var(--text-primary)}
/* 鍵盤 focus 要看得見——radio 本身是隱藏的，所以把外框畫在 label 上 */
.rtab-in:focus-visible + .rtab{outline:2px solid var(--series-1);outline-offset:2px}
.rt-now{display:inline-block;margin-left:6px;font-size:10.5px;font-weight:700;
  padding:0 5px;border-radius:4px;background:var(--surface-2);
  color:var(--text-secondary)}
.rtab-in:checked + .rtab .rt-now{background:rgba(255,255,255,.22);color:#fff}
.rpanels{position:relative}
.rpanel{display:none}
/* 第 n 個 radio 選中 → 顯示第 n 個 panel */
.rtabs > .rtab-in:nth-of-type(1):checked ~ .rpanels > .rpanel:nth-child(1),
.rtabs > .rtab-in:nth-of-type(2):checked ~ .rpanels > .rpanel:nth-child(2),
.rtabs > .rtab-in:nth-of-type(3):checked ~ .rpanels > .rpanel:nth-child(3){display:block}
.rt-hypo{font-size:12.5px;line-height:1.75;color:var(--text-secondary);
  background:var(--surface-2);border-left:2px solid var(--warning);
  border-radius:0 8px 8px 0;padding:9px 12px;margin:0 0 12px}

/* 目前這一格在三種體制下分別是什麼（在「重心怎麼判定」收合內） */
.rcmp{display:grid;grid-template-columns:76px 1fr auto;align-items:center;
  gap:10px;padding:8px 10px;border-radius:8px}
.rcmp.on{background:var(--surface-2)}
.rcmp-k{font-size:12.5px;color:var(--muted)}
.rcmp-v{font-size:14px;font-weight:700}
.rcmp-v.hawkish{color:var(--serious)} .rcmp-v.dovish{color:var(--series-1)}
.rcmp-v.neutral{color:var(--text-secondary)}
.rcmp-l{font-size:12px;color:var(--muted);white-space:nowrap}
.cflag{color:var(--warning);font-weight:700}

/* ---------- 情境九宮格 ---------- */
.sgrid{display:grid;grid-template-columns:auto repeat(3,1fr);gap:5px;margin-top:4px;
  font-size:12px}
.sgrid .axis{color:var(--muted);font-size:12px;display:flex;align-items:center;
  justify-content:center;padding:4px 3px;text-align:center}
.sgrid .axis.row{writing-mode:horizontal-tb;min-width:40px}
/* 格子裡只有格名（＋徽章與 ◆）：說明全部收在卡尾「九格各代表什麼」。
   高度以內容為準——九格等高靠 grid 的隱性拉伸，不用 min-height 硬撐。 */
.scell{background:var(--surface-2);border:1px solid transparent;border-radius:9px;
  padding:10px 8px;min-height:0;display:flex;flex-direction:column;
  justify-content:center;align-items:flex-start}
.scell .sname{font-size:12.5px;font-weight:700;line-height:1.4}
/* 複合情境名的限定語（「：通膨優先」）：小一級、獨立一行。
   主情境與「哪一邊優先」是兩層資訊，同一級字時會被讀成一個長字串。 */
.scell .sn-qual{display:block;font-size:11px;font-weight:600;
  color:var(--text-secondary);line-height:1.35;margin-top:1px}
.scell.on .sn-qual{color:inherit}
@media(min-width:760px){.scell{padding:14px 11px}
  .scell .sname{font-size:13.5px}}
/* 會隨體制改變的三格：右上角一個小記號。
   其餘六格不管誰優先都一樣，讀者不必為它們擔心重心翻轉。 */
.scell.conflict{position:relative}
.scell.conflict::after{content:"◆";position:absolute;top:5px;right:6px;
  font-size:9px;color:var(--warning)}
.scell.on{border-color:var(--text-primary);background:var(--surface-1);
  box-shadow:0 0 0 2px var(--text-primary) inset}
.scell.on .sname{color:var(--text-primary)}
.scell.hawkish .sname{color:var(--serious)}
.scell.dovish .sname{color:var(--series-1)}
.scell.neutral .sname{color:var(--text-secondary)}
.sbadge{display:inline-block;font-size:11px;font-weight:700;margin-top:6px;
  padding:1px 6px;border-radius:5px;background:var(--text-primary);color:var(--surface-1)}
/* 手機：「目前位置」四個字自己佔一整行，會把所在的那一列撐到其他列的
   兩倍半高——而那一列本來就因為情境名較長而偏高，兩件事疊起來整張
   格子看起來是歪的。窄螢幕改成不畫這行字：格子已經有反白底 ＋ 粗框
   ＋ 內陰影三重標示，徽章只是把同一件事再說一次。
   圖說那一行會告訴讀者「反白粗框那一格是目前位置」，語意不會遺失。 */
@media(max-width:759px){.scell .sbadge{display:none}}
/* 圖說裡的小圖例：把樣式做得跟格子一樣，讀者不必猜「反白粗框」長怎樣。
   inline-block ＋ nowrap 是必要的：純 inline 元素折到下一行時，
   內陰影會在斷點處各畫半個框，看起來像兩個壞掉的方塊。 */
.lg-on{display:inline-block;white-space:nowrap;
  background:var(--surface-1);color:var(--text-primary);font-weight:700;
  box-shadow:0 0 0 2px var(--text-primary) inset;border-radius:5px;
  padding:1px 5px}
/* .sbadge.alt 已刪除：那是舊的「結論已依重心修正」徽章，
   三張格子之後沒有任何頁面再產生它。 */

/* ---------- 觸發條件 ---------- */
.trig{display:grid;grid-template-columns:1fr auto;gap:6px 12px;font-size:13px;
  padding:11px 0;border-bottom:1px solid var(--grid);align-items:baseline}
.trig:last-child{border-bottom:none}
.trig .tname{font-weight:600}
.trig .tnow{font-size:12px;color:var(--muted);grid-column:1/-1;margin-top:-4px}
.trig .tdist{font-variant-numeric:tabular-nums;color:var(--text-secondary);
  white-space:nowrap}
.trig.met .tdist{color:var(--critical);font-weight:700}
/* 資料時效條：把「財報已出未入表」「近期發債」這類狀態合併成短列。
   先前是三四個 warnbox 疊在一起，單卡常駐 845 字——每個框單獨都有理由，
   疊起來就是一堵牆。 */
.tlines{margin-top:14px;border:1px solid var(--border);border-radius:10px;
  padding:4px 12px 8px}
.tlines-k{font-size:11.5px;font-weight:700;color:var(--muted);
  letter-spacing:.05em;margin:8px 0 2px}
.tline{margin:0;border:none;border-top:1px solid var(--grid);border-radius:0;
  padding:0}
.tline:first-of-type{border-top:none}
.tline>summary{padding:9px 0;margin:4px 0;font-size:13px;color:var(--text-primary)}
/* 稽核量的是元素盒之間的距離：相鄰的可點元素要留 8px 以上，
   padding 只放大目標、不拉開距離，所以間隔要用 margin 給。 */
/* 表格列裡的連結沿用全站的負 margin 觸控放大（td a 那條規則），
   這裡**不要**再動 td 內距——縮小內距會讓原本「觸控區彼此重疊、
   稽核視為同一組」的連結變成相距 0.2px 的兩個目標。
   要給的是表格與下一個 summary 之間的距離。 */
.tline .tscroll{margin-bottom:12px}
.tline .f-detail{padding-bottom:8px}
/* 四步計算卡：每步一行、行末是結果。取代散在四處的計算說明。 */
.steps{margin:14px 0 2px;border:1px solid var(--border);border-radius:10px;
  overflow:hidden}
.step{display:grid;grid-template-columns:92px 1fr auto;gap:8px;align-items:baseline;
  padding:10px 13px;border-top:1px solid var(--grid);font-size:13.5px}
.step:first-child{border-top:none}
.step-k{font-weight:700;color:var(--text-secondary);font-size:12.5px;white-space:nowrap}
.step-t{color:var(--text-primary);line-height:1.6}
.step-r{font-weight:700;white-space:nowrap}
@media(max-width:520px){.step{grid-template-columns:78px 1fr}
  .step-r{grid-column:2;justify-self:end}}
.trig .tadj{font-size:10.5px;font-weight:700;color:var(--series-1);
  border:1px solid var(--series-1);border-radius:5px;padding:1px 5px;
  margin-left:7px;vertical-align:1px}
/* 動能指向：當期數據正朝這條門檻走——「可能下一格」從這些條裡挑。 */
.trig .tdir{font-size:10.5px;font-weight:700;color:var(--good);
  border:1px solid var(--good);border-radius:5px;padding:1px 5px;
  margin-left:6px;vertical-align:1px;white-space:nowrap}
.trig .tbind{font-size:10.5px;font-weight:700;color:var(--warning);
  border:1px solid var(--warning);border-radius:4px;padding:0 5px;margin-left:6px;
  vertical-align:1px;white-space:nowrap}

/* ---------- 折線圖（刻度用 HTML，避免文字被等比縮小） ---------- */
/* 參考線只畫「資料實際的最高／最低值」，各附數值標籤——
   之前的背景中線落在留白後區間的 50%，不對應任何數值，已移除。 */
/* 右邊留 5px：最新值的圓點是 8px、以最後一點為圓心，
   在時間序列的右端會有一半（4px）超出繪圖區。留白比裁掉好，
   裁掉會讓最新的那一點看起來比實際低。 */
.lwrap{margin-top:6px;padding-right:5px}
.lplot{position:relative;border-left:1px solid var(--grid);
  border-bottom:1px solid var(--grid)}
/* 高度由每張圖自己用 style 指定（charts.line_chart 的 height 參數）。
   這裡寫死 150px 會讓要求 120px 的圖被拉高——SVG 是 preserveAspectRatio="none"，
   拉高不會留白，而是把整條線縱向拉長，形狀因此失真。 */
.lchart{display:block;width:100%}
/* 最高／最低值標籤：加不透明底色，讓它壓在線上時仍讀得出來。
   純文字陰影在深色線條上仍會糊成一團。 */
.glab{position:absolute;left:4px;font-size:11.5px;color:var(--muted);
  line-height:1;font-variant-numeric:tabular-nums;pointer-events:none;
  background:var(--surface-1);padding:1px 4px;border-radius:4px;
  box-shadow:0 0 0 1px var(--surface-1)}
/* 最新值的圓點：疊在 SVG 之上，才不會被 preserveAspectRatio="none" 壓扁，
   也不會在右邊界被裁掉一半 */
.ldot{position:absolute;width:8px;height:8px;border-radius:50%;
  transform:translate(-50%,-50%);box-shadow:0 0 0 2px var(--surface-1);
  pointer-events:none}
.lmark{position:absolute;top:3px;transform:translateX(-50%);font-size:11.5px;
  color:var(--muted);white-space:nowrap;pointer-events:none;
  text-shadow:0 0 4px var(--surface-1),0 0 4px var(--surface-1)}
.lxaxis{display:flex;justify-content:space-between;flex-wrap:wrap;gap:6px;
  font-size:12px;color:var(--muted);margin-top:7px;
  font-variant-numeric:tabular-nums}
.lxaxis b{color:var(--text-primary);font-size:12.5px}

/* ---------- 本期變化摘要 ---------- */
.chg{background:var(--surface-1);border:1px solid var(--border);border-radius:13px;
  padding:17px 16px;box-shadow:var(--shadow);margin-top:13px}
@media(min-width:760px){.chg{padding:20px 22px}}
.chg .ctitle{font-size:12.5px;color:var(--muted)}
/* 零變化時的單行版本 */
.chg.quiet{display:flex;flex-wrap:wrap;gap:6px 14px;align-items:baseline;
  padding:12px 16px;font-size:13.5px}
.chg.quiet .ctitle{font-size:12px}
.chg .chead{font-size:19px;font-weight:700;margin-top:2px;line-height:1.5}
@media(min-width:760px){.chg .chead{font-size:21px}}
.chg.moved .chead{color:var(--serious)}

/* 「N 天前發布」。內容會一直留到下一次發布，讀者可能是在發布後第 10 天
   看到這張卡——不標時間的話會誤以為是今天的新聞。 */
.cage{font-size:12px;color:var(--muted);margin-top:5px}

/* 一句淨結論。七條變化平鋪而沒有加總，讀者只能自己數——而且很容易數錯，
   因為「解除一條鷹派訊號」其實是鴿派的變化。 */
.cnet{font-size:14px;line-height:1.8;margin-top:10px;padding:10px 12px;
  border-radius:9px;background:var(--surface-2)}
.cnet.dovish{background:var(--tint-dov)} .cnet.hawkish{background:var(--tint-haw)}
.cnet b{color:var(--text-primary)}

/* 訊號變化按**方向**分兩欄，不按新觸發／已解除分。
   一條已解除的鷹派訊號是鴿派的變化，照增減分組會把它跟真正的鷹派變化
   排在一起，讀者看到的方向剛好相反。 */
.ccols{display:grid;grid-template-columns:1fr;gap:11px;margin-top:13px}
@media(min-width:700px){.ccols{grid-template-columns:1fr 1fr;gap:13px}}
.ccol{border-radius:10px;padding:11px 12px;background:var(--surface-2);
  border-left:3px solid var(--border)}
.ccol.dovish{border-left-color:var(--series-1)}
.ccol.hawkish{border-left-color:var(--serious)}
.ccol-h{font-size:12.5px;font-weight:700;color:var(--text-secondary);
  margin-bottom:4px}
.ccol.dovish .ccol-h{color:var(--series-1)}
.ccol.hawkish .ccol-h{color:var(--serious)}
.ccol-n{font-weight:700;margin-left:6px;font-variant-numeric:tabular-nums}
/* ＋／− 只表示「新出現／不再成立」，刻意不上色：顏色留給方向，
   一個元件同時用顏色表達兩件事，讀者只會看到兩個互相打架的訊息。 */
.citem{display:flex;gap:7px;align-items:baseline;font-size:13.5px;
  line-height:1.65;padding:4px 0}
.citem .cmark{font-size:12px;font-weight:700;flex-shrink:0;color:var(--muted);
  font-variant-numeric:tabular-nums;width:1.1em}
.citem .ctext{flex:1;min-width:0}
.citem .cmod{font-size:11px;color:var(--muted);flex-shrink:0}
.clegend{font-size:11.5px;color:var(--muted);margin-top:9px;line-height:1.6}
.cmoves{margin-top:10px}
.cmove{display:grid;grid-template-columns:1fr auto;gap:4px 12px;font-size:13px;
  padding:8px 0;border-bottom:1px solid var(--grid);align-items:baseline}
.cmove:last-child{border-bottom:none}
.cmove .cm-val{font-variant-numeric:tabular-nums;color:var(--text-secondary)}
.cmove .cm-delta{font-weight:700;font-variant-numeric:tabular-nums}
/* 「利升息／利降息」寫成字。顏色不該是唯一的載體——對色覺障礙的讀者
   紅綠等於沒有資訊，對其他人也要先讀完下方說明才知道紅色代表什麼。 */
.cmove .cm-tag{font-size:11.5px;font-weight:600;margin-right:6px;
  padding:2px 6px;border-radius:5px;background:var(--surface-2);
  white-space:nowrap;vertical-align:1px}
/* 顏色是「這個變動對利率的意思」，不是數字漲跌 */
.cmove .cm-delta.hawkish{color:var(--serious)}
.cmove .cm-delta.dovish{color:var(--series-1)}
.cmove .cm-delta.flat{color:var(--text-secondary)}

/* ---------- 近 N 期數值列 ---------- */
/* 六格等寬。欄寬用 max-content 當下限，格子才不會被壓到互相疊字；
   單位已經抽到 .munit 只寫一次，所以六格在 390px 上也塞得下。 */
.mwrap{margin-top:10px;border-top:1px solid var(--grid);padding-top:9px}
.munit{font-size:11px;color:var(--muted);text-align:right;margin-bottom:3px}
.mseries{display:grid;grid-auto-flow:column;
  grid-auto-columns:minmax(max-content,1fr);gap:2px;
  overflow-x:auto;scrollbar-width:thin}
.mcell{text-align:center;padding:2px 2px;border-radius:5px;min-width:0}
.mcell.last{background:var(--surface-2)}
/* KPI 卡在桌機四欄下內容寬只有 218px。字級再大一點，
   最寬的那張卡（參與率 61.9%、日期帶年份）就會有一格被切掉半個字，
   而被切掉的數字會讀成另一個數字，那比字小更糟。 */
.mval{font-size:11px;font-variant-numeric:tabular-nums;color:var(--text-secondary);
  line-height:1.3;white-space:nowrap}
.mcell.last .mval{color:var(--text-primary);font-weight:700}
.mdate{font-size:10.5px;color:var(--muted);margin-top:2px;white-space:nowrap}

/* ---------- 狀態軌跡條 ---------- */
.sstrip{display:flex;gap:2px;margin-top:9px}
.sq{flex:1;height:7px;border-radius:2px;background:var(--surface-2)}
.sq.good{background:var(--good)} .sq.warning{background:var(--warning)}
.sq.critical{background:var(--critical)} .sq.unknown{background:var(--muted-bar)}
.sstrip-note{font-size:11px;color:var(--muted);margin-top:4px}

/* ---------- 資料截止日籤 ---------- */
.asof{display:inline-block;font-size:11px;color:var(--muted);
  border:1px solid var(--border);border-radius:4px;padding:0 5px;margin-left:6px;
  vertical-align:2px;font-variant-numeric:tabular-nums;white-space:nowrap}

/* ---------- 首頁的整體總述 ----------
   這是首頁上唯一要「讀」的東西（其餘都是掃的），所以字級比內文大、
   行距放寬，並限制行長：桌機的卡片寬 1080px，13px 字會排到每行 80 個中文字，
   是舒適上限的兩倍，眼睛換行時很容易回到同一行。 */
.brief{background:var(--surface-1)}
.brief-k{font-size:11.5px;font-weight:700;color:var(--muted);
  letter-spacing:.08em;margin-bottom:9px}
/* 三則 bullet 版式：模組名粗體＋豎線，行距鬆一點供掃讀 */
.brief-src{font-size:11.5px;font-weight:500;color:var(--muted);
  margin-left:10px;letter-spacing:0}
.brief-list{list-style:none;margin:10px 0 0;padding:0}
.brief-list li{font-size:14px;line-height:1.85;color:var(--text-primary);
  padding:7px 0;border-top:1px solid var(--grid)}
.brief-list li:first-child{border-top:none;padding-top:2px}
.brief-list li b{font-weight:700}
.brief-t{font-size:15px;line-height:2;margin:0;max-width:34em;
  color:var(--text-primary)}
@media(min-width:760px){.brief-t{font-size:15.5px}}
/* 重點句：整段的結論（下一步是升是降、解鎖條件），獨立一行加粗，
   掃視的人只讀這一行也帶得走東西。 */
/* 「本次更新」獨立一段：它回答的是「這一次新拿到什麼」，跟下一段的
   「整體現在是什麼狀況」不是同一個問題。多數日子這一段不存在。 */
.brief-new{margin:0 0 12px;padding:10px 12px;border-radius:9px;
  background:var(--surface-2);font-size:14.5px;line-height:1.8;
  color:var(--text-primary)}
.brief-key{font-size:15px;line-height:1.9;margin:10px 0 0;max-width:34em;
  font-weight:700;color:var(--text-primary)}
@media(min-width:760px){.brief-key{font-size:15.5px}}

/* ---------- 兩條軸的判定依據 ----------
   分兩層：**結論常駐、算式收合**。
   讀者的問題是「為什麼就業算弱」，那句話必須永遠看得到；
   只有要自己驗算的人才需要展開看權重、加總與門檻出處。

   先前整塊包在一個 .f-more 裡（12.5px 灰字），跟旁邊的圖例說明
   同字級同顏色同位置，掃過去只會被歸類成註腳——做了跟沒做一樣。 */
/* 兩條軸各自成一個框、之間留 8px：先前共用一個外框、中間只隔一條 1px 的
   分隔線，兩個展開列的觸控盒因此只差 1px（版面稽核抓到的）——
   想點「通膨」很容易點到「就業」。 */
.axg{margin-top:16px}
.ax{margin:8px 0 0;padding:0;border:1px solid var(--border);
  border-radius:10px;background:var(--surface-1)}
.ax:first-child{margin-top:0}
.ax>summary{list-style:none;cursor:pointer;padding:11px 34px 11px 13px;
  display:grid;grid-template-columns:auto auto 1fr;gap:3px 9px;
  align-items:baseline;position:relative;font-weight:400}
.ax>summary::-webkit-details-marker{display:none}
.ax>summary:hover{background:var(--surface-2)}
.ax>summary::after{content:"▾";position:absolute;right:14px;top:50%;
  transform:translateY(-50%);font-size:11px;color:var(--muted)}
.ax[open]>summary::after{content:"▴"}
.ax-k{font-size:12.5px;color:var(--muted);font-weight:600;white-space:nowrap}
.ax-v{font-size:15px;font-weight:700;color:var(--text-primary);
  white-space:nowrap}
/* 理由句在窄螢幕上換到第二行、跨滿整列：跟軸名擠同一行會只剩十幾個字寬 */
.ax-lead{font-size:12.5px;color:var(--text-secondary);line-height:1.65;
  grid-column:1/-1;word-break:keep-all;overflow-wrap:break-word}
@media(min-width:760px){
  .ax>summary{align-items:center}
  .ax-lead{grid-column:3;line-height:1.5}
}
.ax-body{padding:0 13px 13px}

/* ---------- 算式（展開後） ----------
   刻意做成算式而不是散文：讀者要能自己驗算，尤其是門檻——
   那是整頁權重最大（跨過去整張部位表就換掉）、先前卻完全沒有交代的東西。 */
.wx-h{font-size:13.5px;font-weight:700;margin-bottom:9px}
.wx-r{display:grid;grid-template-columns:1fr auto auto;gap:4px 10px;
  align-items:baseline;font-size:12.5px;color:var(--text-secondary);padding:3px 0}
.wx-k{min-width:0}
.wx-w{color:var(--muted);font-size:11.5px;font-variant-numeric:tabular-nums}
.wx-v{font-weight:700;color:var(--text-primary);font-variant-numeric:tabular-nums;
  white-space:nowrap}
.wx-sum{border-top:1px solid var(--border);margin-top:5px;padding-top:7px}
.wx-thr{margin-top:9px;font-size:13.5px;font-weight:700;
  font-variant-numeric:tabular-nums}
.wx-src{margin-top:6px;font-size:12px;color:var(--muted);line-height:1.7}
/* 「為什麼兩頁講的不一樣」——這一段是整塊的重點，要跟算式區分開 */
.wx-note{margin-top:10px;padding-top:9px;border-top:1px solid var(--border);
  font-size:12.5px;color:var(--text-secondary);line-height:1.75}

/* ---------- 頁內錨點導覽 ----------
   預設**完全不出現**（height:0）。
   卡區本來就收合，那八九條標題列自己就是目錄，而且每條都帶一句結論——
   再放一列錨點是同一件事做兩次。更糟的是舊版跟主選單長得一模一樣
   （都是 chip ＋ 淺灰底條），一個是換頁一個是換段，讀者得停一下才分得出來。
   展開之後頁面會漲到一萬多 px，那時候才真的難捲，也才滑出來。
   由 JS 在展開三個卡區時加上 .on；一旦出現就不收回——
   導覽列忽隱忽現比一直在還煩。

   分成外框（.anav，負責背景與貼頂）與內層（nav.anchors，負責橫捲）兩層：
   兩側的漸層必須畫在**背景之上、文字之上**。用 mask 做的話會把背景一起
   挖掉，變成看得到底下的內文從縫裡穿過去。 */
.anav{position:sticky;top:var(--navh);z-index:19;background:var(--bg);
  box-shadow:0 0 0 100vmax #fff;clip-path:inset(0 -100vmax -14px -100vmax);
  height:0;padding:0;opacity:0;pointer-events:none;transform:translateY(-4px);
  /* 只淡入、**不做高度動畫**：高度一次到位，JS 才能用一次 scrollBy
     精準補掉版面被推下去的距離。高度慢慢長的話得逐格補，
     那會跟讀者自己的捲動打架。 */
  transition:opacity .18s ease,transform .18s ease}
.anav.on{height:47px;padding:5px 0 6px;opacity:1;transform:none;
  pointer-events:auto;border-bottom:1px solid rgba(18,35,59,.10)}
@media(prefers-reduced-motion:reduce){.anav{transition:none}}
/* 兩側還有內容時給一層漸層。舊版在手機上把 1021px 的內容塞進 362px 的視窗，
   右邊硬切、沒有任何提示——實際上讀者只看得到前三項，
   而且會以為就只有那三項。 */
.anav::before,.anav::after{content:"";position:absolute;top:0;bottom:0;width:28px;
  pointer-events:none;opacity:0;transition:opacity .15s ease}
.anav::before{left:0;background:linear-gradient(90deg,#fff,transparent)}
.anav::after{right:0;background:linear-gradient(270deg,#fff,transparent)}
.anav.fl::before{opacity:1}
.anav.fr::after{opacity:1}
nav.anchors{display:flex;height:100%;align-items:center;
  overflow-x:auto;overflow-y:hidden;scrollbar-width:none}
nav.anchors::-webkit-scrollbar{display:none}
/* 主選單是 chip、這一列是純文字：層級靠**外觀**表達，不是靠上下位置 */
nav.anchors a{font-size:12.5px;line-height:1;color:var(--muted);
  text-decoration:none;padding:10px 0;margin-right:17px;white-space:nowrap;
  flex-shrink:0;position:relative;border-bottom:2px solid transparent}
nav.anchors a::after{content:"";position:absolute;right:-9px;top:calc(50% - 1px);
  width:2px;height:2px;border-radius:50%;background:var(--baseline)}
nav.anchors a:last-child{margin-right:0}
nav.anchors a:last-child::after{display:none}
nav.anchors a:hover{color:var(--text-primary)}
nav.anchors a.on{color:var(--brand-ink);font-weight:700;
  border-bottom-color:var(--brand-ink)}
/* 手機上把觸控高度撐到 40px（版面稽核的硬性下限）。
   桌機不需要，維持緊湊——這一列的重點就是視覺重量要低。 */
@media(max-width:430px){
  .anav.on{height:52px}
  nav.anchors a{padding:13px 0}
}
.card h2{scroll-margin-top:60px}
/* ---------- decision-first redesign ---------- */
.focus-card{position:relative;overflow:hidden;background:var(--surface-1);border-top:3px solid var(--series-1);padding:20px}
.focus-card:before{display:none}
.focus-eyebrow{font-size:11px;font-weight:800;letter-spacing:.11em;color:var(--series-1);text-transform:uppercase;margin-bottom:7px}
.focus-title{font-size:26px;line-height:1.28;margin:0;max-width:820px;letter-spacing:-.02em}
.focus-sub{color:var(--text-secondary);font-size:14px;line-height:1.65;margin:8px 0 0;max-width:880px}
.focus-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px;margin-top:18px}
@media(min-width:760px){.focus-card{padding:24px 26px}.focus-grid{grid-template-columns:repeat(4,minmax(0,1fr))}}
.focus-metric{min-width:0;padding:12px 13px;border:1px solid var(--border);border-radius:10px;background:var(--surface-1);display:flex;flex-direction:column;gap:3px}
.focus-metric>span{font-size:11.5px;color:var(--muted)}
.focus-metric>b{font-size:19px;line-height:1.25;font-variant-numeric:tabular-nums}
.focus-metric>small{font-size:11.5px;color:var(--text-secondary);line-height:1.4}
.focus-metric.hawkish{border-left:3px solid var(--critical)}
.focus-metric.dovish{border-left:3px solid var(--good)}
.focus-metric.watch{border-left:3px solid var(--warning)}
.logic-strip{display:grid;grid-template-columns:1fr;gap:8px;margin-top:14px}
@media(min-width:760px){.logic-strip{grid-template-columns:repeat(3,1fr)}}
.logic-step{padding:12px 14px;border-radius:9px;background:var(--surface-2);border:1px solid var(--border)}
.logic-step b{display:block;font-size:13px;margin-bottom:3px}
.logic-step span{font-size:12px;color:var(--muted);line-height:1.45}
.deep-dive>h2{margin-bottom:0}
.full-detail{margin-top:12px;border:1px solid var(--border);border-radius:9px}
.full-detail>summary{cursor:pointer;padding:13px 15px;font-size:13px;font-weight:700;color:var(--text-secondary)}
.full-detail-body{padding:0 10px 12px}
.full-detail-body>.grid{margin-top:10px}
.full-detail-body .card{box-shadow:none;background:var(--surface-2)}
.full-detail-body h3{font-size:15px;margin:0 0 8px}
.full-detail-body .verdict{margin-top:10px}
.data-line{display:flex;flex-wrap:wrap;gap:7px;margin-top:13px}
.data-tag[href]{min-height:40px;display:inline-flex;align-items:center;
  text-decoration:none;color:var(--series-1);font-weight:700}
.data-tag{font-size:11.5px;padding:5px 8px;border-radius:999px;background:var(--surface-2);border:1px solid var(--border);color:var(--text-secondary)}
.flow-arrow{display:none}
@media(min-width:760px){.flow-arrow{display:block;align-self:center;color:var(--muted);font-weight:800}}
.grid-flow{display:grid;grid-template-columns:1fr;gap:8px;margin-top:16px}
@media(min-width:760px){.grid-flow{grid-template-columns:1fr auto 1fr auto 1fr}}
.flow-box{padding:14px;border:1px solid var(--border);border-radius:10px;background:var(--surface-1)}
.flow-box strong{font-size:15px}
.flow-values{font-size:13px;margin-top:7px;line-height:1.6;color:var(--text-secondary)}

/* ---------- 意外值 ---------- */
.surp{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-top:4px}
@media(min-width:760px){.surp{gap:10px}}
/* 三格會被拉成同高（最高那格有徽章與註解），其餘兩格因此上半滿、
   下半空。改成垂直置中，視覺重量才平均。 */
.sbox{display:flex;flex-direction:column;justify-content:center;
  background:var(--surface-2);border-radius:9px;padding:12px 8px;
  border:1px solid var(--border);text-align:center}
@media(min-width:760px){.sbox{padding:12px 11px}}
.sbox .sl{font-size:12px;color:var(--muted)}
.sbox .sv{font-size:19px;font-weight:700;margin-top:5px;
  font-variant-numeric:tabular-nums;white-space:nowrap}
@media(min-width:760px){.sbox .sv{font-size:20px}}
.sbox .su{font-size:12px;color:var(--muted);font-weight:400;margin-left:2px}
.sbox.beat .sv{color:var(--good)} .sbox.miss .sv{color:var(--critical)}
.sbadge2{display:inline-block;font-size:11px;font-weight:700;border-radius:6px;
  padding:3px 9px;margin-top:9px}
.sbadge2.beat{background:rgba(7,124,7,.13);color:#036b03}
.sbadge2.miss{background:rgba(194,47,47,.13);color:#ad2929}
.sbadge2.inline{background:var(--surface-2);color:var(--muted)}
.sbox .szn{font-size:11px;color:var(--muted);margin-top:5px;
  font-variant-numeric:tabular-nums}
/* ---------- 總覽頁 v2：五區、單層收合 ---------- */
.home-dashboard{margin-top:14px}
.home-hero{position:relative;overflow:hidden;background:var(--surface-1);
  border:1px solid var(--border);border-top:4px solid var(--series-1);
  border-radius:16px;padding:20px 17px;box-shadow:var(--shadow)}
.home-hero.hawkish{border-top-color:var(--series-2)}
.home-hero.dovish{border-top-color:var(--series-1)}
.home-hero-top{display:flex;flex-direction:column;gap:14px}
.home-kicker,.home-zone-num{font-size:11px;font-weight:800;letter-spacing:.12em;
  text-transform:uppercase;color:var(--muted)}
.home-hero h2{font-size:29px;line-height:1.18;letter-spacing:-.025em;margin:5px 0 0}
.home-verdict{display:flex;align-items:center;justify-content:space-between;gap:12px;
  border-radius:10px;padding:10px 12px;background:var(--surface-2)}
.home-verdict span{font-size:14px;font-weight:700}
.home-verdict b{font-size:13px;color:var(--muted)}
.home-verdict.hawkish{background:var(--tint-haw)}
.home-verdict.dovish{background:var(--tint-dov)}
.home-narrative{margin-top:20px;padding-top:18px;border-top:1px solid var(--grid)}
.home-brief-label{display:flex;flex-direction:column;gap:3px;font-size:12px;
  font-weight:800;letter-spacing:.06em;color:var(--text-secondary)}
.home-brief-label span{font-size:10.5px;font-weight:500;letter-spacing:0;color:var(--muted)}
.home-brief-text{max-width:47em;font-size:15px;line-height:1.9;margin:10px 0 0;
  color:var(--text-primary)}
.home-brief-key{max-width:47em;font-size:14px;line-height:1.7;font-weight:700;
  margin:12px 0 0;padding-left:12px;border-left:3px solid var(--series-1)}
.home-brief-empty{color:var(--muted);margin:8px 0 0}
.home-brief-more{margin:6px 0 0;padding:0;border:0}
.home-brief-more>summary{display:inline-flex;min-height:42px;align-items:center;
  padding:8px 0;color:var(--series-1)}
/* 卡內收合統一「開頭 ▸/▾」家族 */
.home-brief-more>summary::before{content:"▸";margin-right:6px;font-size:10px}
.home-brief-more[open]>summary::before{content:"▾"}
.home-brief-more>summary::after{content:""}
.home-brief-more p{max-width:47em;font-size:15px;line-height:1.9;margin:2px 0 0}
.home-status-rail{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));
  margin-top:18px;border:1px solid var(--grid);border-radius:11px;overflow:hidden}
.home-status-rail>div{min-width:0;padding:10px 11px;background:var(--surface-2);
  border-right:1px solid var(--grid);border-bottom:1px solid var(--grid)}
.home-status-rail>div:nth-child(2n){border-right:0}
.home-status-rail>div:nth-last-child(-n+2){border-bottom:0}
.home-status-rail span{display:block;font-size:10.5px;color:var(--muted)}
.home-status-rail b{display:block;margin-top:2px;font-size:13.5px;white-space:nowrap}

.home-zone{margin-top:16px;padding:19px 17px;background:var(--surface-1);
  border:1px solid var(--border);border-radius:14px}
.home-zone-head{display:flex;align-items:flex-start;justify-content:space-between;gap:14px;
  margin-bottom:15px}
.home-zone-head>div{min-width:0}
.home-zone-head h2{font-size:18px;line-height:1.25;margin:3px 0 0}
.home-zone-head p{font-size:11.5px;color:var(--muted);margin:3px 0 0;text-align:right}
.home-primary-link,.home-inline-link{display:inline-flex;align-items:center;justify-content:center;
  min-height:44px;color:var(--series-1);font-size:13px;font-weight:700;text-decoration:none}
.home-primary-link{flex-shrink:0;margin-top:-6px}

/* 今日市場焦點：hero 之上的窄條。chips 一列掃完，焦點段一段就好。 */
/* 升格成強調卡：頂部主題色帶＋放大的標題（帶日期）＋與下方 hero 拉開。
   先前是一條 11px 灰標題的窄 strip，跟目前情境黏在一起、掃過去會漏看。 */
/* ⚠️ 這裡不能 overflow:hidden：「選擇」勾選面板是絕對定位浮層，
   會被整個剪掉——桌機點了看起來像沒反應（實際發生過）。
   頂部色條用 border-top 畫：3px 的 ::before 疊圓角會被垂直方向夾成
   一條兩端漸縮的怪線（也實際發生過），border-top 沿圓角自然轉彎。 */
.focus-strip{position:relative;padding:16px 18px 15px;margin-bottom:26px;
  border-top:3px solid var(--series-1)}
.fs-head{font-size:15px;font-weight:800;letter-spacing:.02em;
  color:var(--text-primary)}
.fs-date{margin-left:9px;font-size:11.5px;font-weight:500;color:var(--muted)}
/* 三地時間戳：手機縮一號字＋前綴改短版才塞得進一行（360px 實測）。
   320px 這種古董寬度仍會折行——為它再縮就小到讀不了，不遷就。 */
.ws-short{display:none}
@media(max-width:759px){
  .sub .ws{font-size:10.5px;letter-spacing:0}
  .ws-long{display:none}
  .ws-short{display:inline}}
/* ---------- 焦點條的自選 chip ----------
   目錄 14 顆全在 HTML 裡，預設組以外掛 .fs-off 隱藏；「自訂」是原生
   details 元素：桌機浮層、手機（759px 以下）改全寬面板往下推——浮層在
   手機上會超出視窗或被手指擋住。勾選列拉到 44px 以上符合觸控目標。 */
.fs-off{display:none}
.fs-when{display:block;font-size:10px;color:var(--muted);margin-top:1px;
  font-variant-numeric:tabular-nums;letter-spacing:.02em}
.fs-pick{position:relative;display:inline-block;margin-left:10px;
  font-weight:400;vertical-align:1px}
/* 熱區與外觀拆開：summary 本體是透明熱區（手機撐到 44px 過觸控稽核），
   看得見的小按鈕畫在內層 .fs-pick-btn——先前把 summary 整顆撐高，
   邊框方塊比標題還高一截，上下框線像懸浮的怪線（使用者回報過）。 */
.fs-pick>summary{cursor:pointer;list-style:none;display:inline-flex;
  align-items:center;user-select:none;padding:0;border:0;background:none}
.fs-pick>summary::-webkit-details-marker{display:none}
.fs-pick-btn{font-size:11.5px;color:var(--muted);
  border:1px solid var(--border);border-radius:4px;padding:2px 9px;
  display:inline-block;line-height:1.5}
.fs-pick[open] .fs-pick-btn{color:var(--text-primary);
  border-color:var(--text-primary)}
/* 面板改網格：桌機三欄的寬長方形、手機兩欄近正方形——14 個選項
   排成一條長列要滾很久（使用者嫌）。分隔線取消：網格下橫線會斷在
   半路，行距就是分隔。 */
/* 寬度跟著內容撐開（Windows 中文字型比較寬，固定 440px 時長標籤會撐出
   白框——使用者回報過），上限是視窗寬；真的放不下時標籤允許換行。 */
.fs-pick-panel{position:absolute;left:0;top:calc(100% + 6px);z-index:40;
  background:var(--surface-1);border:1px solid var(--border);
  border-radius:8px;padding:8px 14px 10px;width:max-content;min-width:440px;
  max-width:calc(100vw - 48px);box-sizing:border-box;
  display:grid;grid-template-columns:repeat(3,auto);column-gap:18px;
  box-shadow:0 6px 24px rgba(0,0,0,.35)}
.fs-pick-panel label{display:flex;align-items:center;gap:8px;
  min-height:44px;font-size:13px;color:var(--text-primary);
  cursor:pointer;white-space:normal;line-height:1.35}
.fs-pick-panel input{width:15px;height:15px;accent-color:var(--series-1)}
.fs-pick-panel label:has(input:disabled){opacity:.4;cursor:default}
.fs-pick-note{font-size:11px;color:var(--muted);margin-top:2px;
  border-top:1px solid var(--grid);padding-top:8px;white-space:nowrap;
  grid-column:1/-1}
/* 頁尾的收合說明區：預設收起只露一行，展開才見完整指標與來源說明 */
.foot-fold>summary{cursor:pointer;list-style:none;font-weight:700;
  color:var(--muted);font-size:12px;user-select:none;padding:4px 0}
.foot-fold>summary::before{content:"▸ ";font-weight:400}
.foot-fold[open]>summary::before{content:"▾ "}
.foot-fold>summary::-webkit-details-marker{display:none}
.foot-fold-body span{display:block;margin-top:6px;line-height:1.8}
@media(max-width:759px){
  .fs-pick{position:static}
  /* 手機的觸控目標：熱區（summary）拉到 44px，外觀（.fs-pick-btn）不變 */
  .fs-pick>summary{min-height:44px;box-sizing:border-box}
  .fs-pick-panel{position:static;margin-top:8px;width:100%;min-width:0;
    box-shadow:none;grid-template-columns:repeat(2,1fr);column-gap:10px}
  /* 窄欄容不下 nowrap 的長標籤（「12 月 FOMC 升降息機率」）——
     手機允許換行、字縮一號；備註行同理 */
  .fs-pick-panel label{white-space:normal;font-size:12px;line-height:1.4}
  .fs-pick-note{white-space:normal}
  .foot-fold>summary{display:flex;align-items:center;min-height:44px}}
/* chips 之間用細分隔線取代純留白：三顆數字各自成柱、視線好對位；
   最後一顆不畫線。手機換行時分隔線自動消失（border 在左側）。 */
/* 固定四格網格：桌機一行四格、手機 2×2。格位天天一樣，選什麼放什麼，
   不再隨勾選數量換行漂移。分隔線在網格版取消（隱藏的 chip 仍在 DOM，
   nth-child 對不準「可見的第一格」，畫了只會斷在怪地方）。 */
.fs-chips{display:grid;grid-template-columns:repeat(4,1fr);
  gap:10px 18px;margin-top:8px}
.fs-chip{padding:2px 0;min-width:0}
@media(max-width:759px){
  .fs-chips{grid-template-columns:repeat(2,1fr)}}
.fs-chip span{display:block;font-size:11px;color:var(--muted);margin-bottom:1px}
.fs-chip b{font-size:17px;font-weight:700;font-variant-numeric:tabular-nums}
.fs-chip i{font-style:normal;font-size:11.5px;margin-left:6px;color:var(--muted)}
.fs-chip i.up{color:var(--critical)}
.fs-chip i.dn{color:var(--good)}
.fs-src{font-size:10.5px;color:var(--muted);margin-left:7px;white-space:nowrap}
/* 焦點段給一個淺色底框：跟上方數字 chips 分成兩個視覺層，
   一眼分得出「數字」與「敘述」——先前兩者直接疊在一起。 */
/* 論述容器：底色框只包一次，段落在框內分段——每段各自一個框
   會把一篇報導切成三塊碎片 */
.fs-body{margin:12px 0 0;max-width:47em;background:var(--surface-2);
  border-radius:9px;padding:11px 13px}
/* 3 則重點：一則一行、左側小圓點，則與則之間留白——掃一眼就看得出
   今天有幾件事（先前是兩三段散文，被嫌太長又太籠統）。 */
.fs-list{list-style:none}
/* 版式 A：主軸一段＋補充清單（補充清單嵌在同一個底色框裡） */
.fs-main{margin:0;font-size:14px;line-height:1.85;color:var(--text-primary)}
.fs-body .fs-list{margin:10px 0 0;padding:10px 0 0;
  border-top:1px solid var(--grid)}
.fs-body .fs-text{font-size:13.5px;line-height:1.8;color:var(--text-primary);
  margin:0;position:relative;padding-left:14px}
/* 不用 justify：中英數混排的短行會把中文字距硬撐開（手機實測） */
.fs-list .fs-text::before{content:"";position:absolute;left:2px;top:.78em;
  width:5px;height:5px;border-radius:50%;background:var(--series-1)}
.fs-body .fs-text+.fs-text{margin-top:9px}
.fs-link{padding:4px 0}
.fs-link a{color:var(--series-1);text-decoration:none;font-size:12.5px;
  display:inline-block;padding:8px 0;line-height:1.5}
.fs-note{margin-top:8px;font-size:10.5px;color:var(--muted);line-height:1.6}

/* ---------- 焦點條 2026-10 改版：截圖友善 ----------
   使用者每天把這一區截圖發社群，所以它要像一張獨立的圖卡：
   桌機兩欄（左：2×2 數據磚；右：新聞），手機上下堆疊；
   數字是有底色的磚（標籤→數值→變動→資料日四層），新聞框不再限寬，
   最底下一條品牌列（站名、標語、更新時間、新聞來源）。 */
.fs-grid{display:grid;grid-template-columns:1fr;gap:12px;margin-top:10px}
@media(min-width:900px){
  .fs-grid{grid-template-columns:minmax(300px,36%) 1fr;align-items:stretch}}
.focus-strip .fs-chips{grid-template-columns:repeat(2,1fr);gap:8px;margin:0;
  grid-auto-rows:1fr;align-content:stretch}
/* 「選擇」是 details：全站 details 預設有上框線＋上邊距，套到這顆小按鈕上
   就是標題上方那條莫名的短線（截圖裡很明顯）——這裡全部歸零 */
.focus-strip .fs-pick,.focus-strip .fs-pick[open]{margin-top:0;border-top:0;
  padding-top:0;padding-bottom:0}
.focus-strip .fs-head{display:flex;align-items:center;flex-wrap:wrap;gap:6px}
.focus-strip .fs-chip{background:var(--surface-2);border-radius:10px;
  padding:10px 12px 9px;display:flex;flex-direction:column;min-height:82px;
  box-sizing:border-box}
.focus-strip .fs-chip.fs-off{display:none}
.focus-strip .fs-chip span{font-size:11.5px;color:var(--text-secondary);
  margin-bottom:3px;line-height:1.35}
.focus-strip .fs-chip b{font-size:21px;font-weight:800;line-height:1.2;
  letter-spacing:-.01em}
.focus-strip .fs-chip i{margin-left:0;margin-top:2px;font-size:12px;
  font-weight:600;line-height:1.35}
.focus-strip .fs-chip .fs-when{margin-top:4px}
/* 桌機：磚被拉到跟新聞框同高，內容垂直置中、數字放大一號 */
@media(min-width:900px){
  .focus-strip .fs-chip{justify-content:center;padding:12px 14px}
  .focus-strip .fs-chip b{font-size:25px}
  .focus-strip .fs-chip i{font-size:12.5px}}
.fs-news{min-width:0;display:flex;flex-direction:column}
.fs-news .fs-body{margin:0;max-width:none;flex:1;padding:13px 15px}
.fs-kicker{font-size:11px;font-weight:800;letter-spacing:.08em;
  color:var(--series-1);margin-bottom:4px}
.fs-news .fs-main{font-size:14.5px;line-height:1.85}
.fs-main+.fs-main{margin-top:8px}
/* 主軸標題（2026-10）：一句粗體點出今天的核心事件，只看標題也知道重點 */
.fs-news .fs-headline{margin:2px 0 8px;font-size:17px;font-weight:800;line-height:1.45;
  color:var(--brand-ink,var(--text-primary));letter-spacing:.01em}
/* 對利率：主軸最後一句，跟網站自己的利率判讀一致 */
.fs-news .fs-rate{margin:10px 0 0;padding:8px 12px;font-size:14px;line-height:1.7;
  color:var(--text-primary);background:var(--surface-2,rgba(18,35,59,.05));
  border-left:3px solid var(--brand-orange,#E67143);border-radius:0 6px 6px 0}
.fs-news .fs-rate b{margin-right:8px;color:var(--brand-orange,#E67143);font-weight:800}
@media(max-width:759px){.fs-news .fs-headline{font-size:16px}}
/* 補充依讀者選的前兩個指標換主題（2026-10）：行首的主題標籤 */
.fs-tag{display:inline-block;margin-right:6px;padding:0 6px;border-radius:5px;
  background:#e6eef8;color:var(--series-1);font-size:11.5px;font-weight:700;
  line-height:1.7;vertical-align:1px;white-space:nowrap}
/* ---------- 期中選舉預測卡（Polymarket） ---------- */
:root{--el-dem:#2f6db5;--el-rep:#c2413a;--el-mix:#8a7fb8;--el-mix2:#b9a6d6;--el-oth:#b8b7af}
.el-card a{color:inherit;text-decoration:none}
.el-rows{display:grid;gap:8px}
.el-row{display:grid;grid-template-columns:62px minmax(0,1fr) auto 96px;gap:12px;
  align-items:center;padding:10px 12px;border-radius:10px;background:var(--surface-2)}
.el-row:hover,.el-race:hover,.el-bal:hover{outline:1px solid var(--border)}
.el-name{font-size:13.5px;font-weight:800}
.el-bar,.el-stack,.el-mini{display:flex;height:10px;border-radius:5px;overflow:hidden;
  background:var(--grid,#e3e2dd)}
.el-bar i,.el-stack i,.el-mini i{display:block;height:100%}
.el-card i.dem,.el-sw.dem{background:var(--el-dem)}
.el-card i.rep,.el-sw.rep{background:var(--el-rep)}
.el-card i.mix,.el-sw.mix{background:var(--el-mix)}
.el-card i.mix2,.el-sw.mix2{background:var(--el-mix2)}
.el-card i.oth,.el-sw.oth{background:var(--el-oth)}
.el-val{text-align:right;min-width:0}
.el-val b{display:block;font-size:17px;font-variant-numeric:tabular-nums;white-space:nowrap}
.el-card b.dem{color:var(--el-dem)}.el-card b.rep{color:var(--el-rep)}
.el-val small{display:flex;justify-content:flex-end;gap:8px;font-size:11.5px;
  color:var(--muted);white-space:nowrap}
.el-spark{display:block}
.el-miss{grid-column:2/-1;font-size:12.5px;color:var(--muted)}
.el-sub{display:block;margin:16px 0 8px;font-size:12px;font-weight:800;color:var(--muted);
  letter-spacing:.04em}
.el-bal{display:block}
.el-stack{height:14px;border-radius:7px}
.el-legend{list-style:none;margin:8px 0 0;padding:0;display:grid;
  grid-template-columns:repeat(2,minmax(0,1fr));gap:4px 16px}
.el-legend li{display:flex;align-items:center;gap:7px;font-size:12.5px;min-width:0}
.el-legend b{margin-left:auto;font-variant-numeric:tabular-nums}
.el-sw{flex:none;width:10px;height:10px;border-radius:3px}
.el-races{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px}
.el-race{display:block;padding:10px 11px;border-radius:10px;background:var(--surface-2);min-width:0}
.el-state{display:block;font-size:11.5px;color:var(--muted);font-weight:700}
.el-race b{display:block;margin-top:2px;font-size:17px;line-height:1.3;
  font-variant-numeric:tabular-nums}
.el-race small{display:block;font-size:11.5px;color:var(--muted);line-height:1.45;
  overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.el-race small.el-nm{color:var(--text-secondary)}
.el-race .el-mini{margin-top:7px}
.el-mini{height:6px;border-radius:3px}
.el-note{margin:12px 0 0;font-size:11.5px;line-height:1.7;color:var(--muted)}
/* 全站的 details 有上框線與內距（收合區塊用）——這裡是行內的小說明，歸零 */
.el-how{margin:0;padding:0;border-top:0;font-size:11.5px;color:var(--muted)}
.el-how>summary{display:inline-flex;align-items:center;min-height:32px;cursor:pointer;
  color:var(--series-1);font-weight:700;list-style:none}
.el-how>summary::-webkit-details-marker{display:none}
.el-how>summary::after{content:" ▾"}.el-how[open]>summary::after{content:" ▴"}
.el-how p{margin:0 0 4px;line-height:1.75}

/* ---------- 聯準會頁（2026-10）：事實清單、時間軸、委員、點陣圖、紀要 ---------- */
.ai-tag{display:inline-block;font-size:10px;font-weight:700;letter-spacing:.04em;
  padding:1px 5px;margin-right:6px;border-radius:4px;border:1px solid var(--border);
  color:var(--muted);vertical-align:1px}
.fx-ai{margin-top:6px;font-size:13px;line-height:1.65;color:var(--text-secondary)}
.fx-list{border-top:1px solid var(--grid);margin-top:6px}
.fx-row{display:grid;grid-template-columns:minmax(96px,.55fr) minmax(0,2fr) auto;gap:4px 14px;
  align-items:start;padding:11px 2px;border-bottom:1px solid var(--grid)}
.fx-k{font-size:12.5px;color:var(--muted);padding-top:2px}
.fx-v{font-size:14px;line-height:1.6}
.fx-v small{display:block;font-size:12px;color:var(--muted);margin-top:2px}
.fx-dir{font-size:12px;font-weight:700;white-space:nowrap;padding-top:2px;color:var(--muted)}
.fx-dir.hawkish,.fx-act.hawkish{color:var(--critical)}
.fx-dir.dovish,.fx-act.dovish{color:var(--good)}
.fx-bo{display:inline-block;font-size:13px;font-weight:600;padding:6px 10px;border-radius:8px;
  background:var(--surface-2);margin:2px 0 10px}
.fx-bo.in{background:var(--tint-haw);color:var(--serious)}
.fx-tl{list-style:none;margin:0;padding:0;border-left:2px solid var(--grid)}
.fx-tl li{position:relative;display:grid;grid-template-columns:52px auto minmax(0,1fr);gap:2px 10px;
  padding:7px 0 7px 14px;font-size:13.5px;line-height:1.55}
.fx-tl li::before{content:"";position:absolute;left:-6px;top:13px;width:10px;height:10px;
  border-radius:50%;background:var(--surface-1);border:2px solid var(--baseline)}
.fx-tl li.tl-key::before{background:var(--series-1);border-color:var(--series-1)}
.fx-tl li.tl-key b{color:var(--series-1)}
.fx-tl .tl-d{font-variant-numeric:tabular-nums;color:var(--muted)}
.fx-tl .tl-b{color:var(--text-secondary)}
.fx-people{display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:8px;margin-bottom:6px}
.fx-p,.fx-sp{border:1px solid var(--border);border-radius:10px;padding:10px 12px;background:var(--surface-1)}
.fx-pn{display:flex;flex-wrap:wrap;align-items:baseline;gap:2px 8px}
.fx-pn b{font-size:14.5px}
.fx-pn span{font-size:12px;color:var(--muted)}
.fx-tag{display:inline-block;margin-top:6px;font-size:11.5px;padding:2px 7px;border-radius:6px;
  border:1px solid var(--border);color:var(--muted)}
.fx-tag.hawkish{border-color:var(--critical);color:var(--critical)}
.fx-tag.dovish{border-color:var(--good);color:var(--good)}
.fx-pnote{font-size:12px;color:var(--text-secondary);margin-top:6px;line-height:1.55}
.fx-lead{font-size:14.5px;line-height:1.7;margin:4px 0 10px}
.fx-dotwrap{overflow-x:auto;-webkit-overflow-scrolling:touch}
.fx-dots{width:100%;max-width:900px;height:auto;display:block;margin:4px 0}
.fx-tier3{margin:10px 0 0}
@media (max-width:640px){.fx-dots{min-width:620px}}
.fx-dec td,.fx-dec th{text-align:left}
.fx-dots circle{fill:var(--series-1);opacity:.85}
.fx-dots .g{stroke:var(--grid);stroke-width:1}
.fx-dots .now{stroke:var(--muted);stroke-width:1.2;stroke-dasharray:4 4}
.fx-dots .med{stroke:var(--critical);stroke-width:2.5}
.fx-dots text{fill:var(--muted);font-size:11px}
.fx-dots .yl{text-anchor:end}.fx-dots .xl{text-anchor:middle;font-size:12px}
.fx-dots .nl{text-anchor:end;font-size:10.5px}
.fx-sep td,.fx-sep th{text-align:right;white-space:nowrap}
.fx-sep th.rowhead{text-align:left}
.fx-sep td small{display:block;font-size:10.5px;color:var(--muted);font-weight:400}
.fx-sep td small.up{color:var(--critical)}.fx-sep td small.dn{color:var(--good)}
/* Meeting minutes: same source content on desktop and phone. */
.mn-overview{font-size:15px;line-height:1.85;margin:8px 0;color:var(--text-primary)}
.mn-count{display:block;font-size:11.5px;color:var(--muted);font-weight:400;margin:5px 0 0}
.mn-table{width:100%;table-layout:fixed;border-collapse:collapse;margin:10px 0}
.mn-table th,.mn-table td{text-align:left;white-space:normal;vertical-align:top;padding:14px 16px;line-height:1.75;overflow-wrap:anywhere}
.mn-table thead th{font-size:12px;color:var(--muted);background:transparent;border-bottom:1px solid var(--grid)}
.mn-table th:first-child{width:18%}
.mn-table tbody th{font-size:14px;font-weight:700}
.mn-table tbody td{font-size:14px}
.mn-table p{margin:0}
.mn-table tbody tr+tr>*{border-top:1px solid var(--grid)}
.mn-caution{margin:12px 0 18px}
.mn-evidence{margin:18px 0 0}
.mn-evidence summary{font-weight:600;cursor:pointer}
@media(max-width:640px){
  .mn-table,.mn-table tbody{display:block;width:100%}
  .mn-table thead{display:none}
  .mn-table tr{display:block;padding:16px 0}
  .mn-table tbody tr+tr{border-top:1px solid var(--grid)}
  .mn-table th,.mn-table td{display:block;width:100%!important;border:0!important;padding:0;background:transparent}
  .mn-table tbody th{font-size:15px;margin-bottom:12px}
  .mn-table td+td{margin-top:14px}
  .mn-table td:before{content:attr(data-label);display:block;font-size:11.5px;color:var(--muted);margin-bottom:4px}
  .mn-table .mn-count{margin-top:3px}
}
.fx-q,.fx-ev,.fx-cond{list-style:none;margin:0 0 6px;padding:0}
.fx-q li,.fx-ev li,.fx-cond li{display:grid;grid-template-columns:auto minmax(0,1fr);gap:4px 10px;
  padding:8px 0;border-bottom:1px solid var(--grid);font-size:13.5px;line-height:1.6}
.q-lv{font-size:11.5px;font-weight:700;padding:2px 7px;border-radius:6px;white-space:nowrap;
  background:var(--surface-2);color:var(--text-secondary);align-self:start}
.q-lv.r0,.q-lv.r1,.q-lv.r2{background:var(--series-1);color:#fff}
.q-lv.r3{background:var(--tint-dov);color:var(--series-1)}
.q-en{color:var(--text-secondary);font-size:13px}
.fx-ev .fx-tag{margin-top:2px;align-self:start}
.fx-cond .cmark{font-weight:700;color:var(--muted)}
.fx-cond li.met .cmark{color:var(--good)}
.fx-cond small{display:block;color:var(--muted);font-size:12px}
.fx-sps{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:8px}
.sp-i{font-size:13px;line-height:1.55;margin-top:6px}
.sp-i a{color:inherit}
.sp-k{font-size:10.5px;font-weight:700;color:var(--muted);margin-right:6px}
.sp-d{display:block;font-size:11.5px;color:var(--muted)}
@media (max-width:640px){
  .fx-row{grid-template-columns:minmax(0,1fr) auto}
  .fx-k{grid-column:1/-1;padding-top:0}
  .fx-tl li{grid-template-columns:44px minmax(0,1fr)}
  .fx-tl .tl-b{grid-column:2}
  .fx-people,.fx-sps{grid-template-columns:1fr}
}
.el-card .home-zone-head{flex-direction:row;align-items:flex-start}
.el-card .home-primary-link{font-size:12.5px;min-height:36px;margin-top:-4px;white-space:nowrap}
/* ---- 各州地圖（可收合）---- */
.c-D-safe{--f:#1d4e94}.c-D-likely{--f:#4f7fc6}.c-D-lean{--f:#a7c2e8}
.c-R-safe{--f:#b0261f}.c-R-likely{--f:#dc5d52}.c-R-lean{--f:#f2aba3}
.c-I-safe{--f:#5e4b8b}.c-I-likely{--f:#8a77b8}.c-I-lean{--f:#c3b7dd}
.c-U-safe,.c-U-likely,.c-U-lean{--f:#9a9a94}
.c-toss{--f:#e3cf8f}.c-off{--f:#e9e8e3}.c-na{--f:#f8f7f3}
.el-map{margin-top:14px;border-top:1px solid var(--border);padding-top:4px}
.el-map>summary{display:flex;align-items:center;gap:8px 10px;min-height:44px;cursor:pointer;
  list-style:none;flex-wrap:wrap;padding:6px 0}
.el-map>summary::-webkit-details-marker{display:none}
.el-map-t{font-size:14px;font-weight:800}
.el-map-s{display:flex;flex-wrap:wrap;gap:6px}
.el-chip{display:inline-flex;align-items:center;gap:6px;padding:3px 10px;border-radius:999px;
  background:var(--surface-2);font-size:12.5px;font-weight:700;color:var(--text-secondary);
  font-variant-numeric:tabular-nums;white-space:nowrap}
.el-card .vd{color:var(--el-dem)}.el-card .vr{color:var(--el-rep)}
.el-map-c{margin-left:auto;font-size:12px;font-weight:700;color:var(--series-1);
  border:1px solid var(--border);border-radius:999px;padding:3px 12px}
.el-map-c::before{content:"展開 ▾"}
.el-map[open] .el-map-c::before{content:"收合 ▴"}
.el-map-body{padding:6px 0 4px}
.el-tabs{display:flex;gap:6px;margin-bottom:12px}
.el-tab{font:inherit;font-size:13px;font-weight:700;padding:6px 16px;min-height:36px;
  border-radius:999px;border:1px solid var(--border);background:var(--surface-1);
  color:var(--text-secondary);cursor:pointer}
.el-tab[aria-selected="true"]{background:var(--text-primary);color:#fff;border-color:var(--text-primary)}
.el-score{display:grid;grid-template-columns:auto minmax(0,1fr) auto;gap:14px;align-items:center}
.el-sc b{display:block;font-size:34px;line-height:1;font-variant-numeric:tabular-nums}
.el-sc span{display:block;font-size:12px;font-weight:700;margin-top:3px}
.el-sc.dem{color:var(--el-dem)}.el-sc.rep{color:var(--el-rep);text-align:right}
.el-sbar{position:relative;display:flex;height:16px;border-radius:8px;background:var(--grid)}
.el-sbar>i{display:block;height:100%}
.el-sbar>i:first-child{border-radius:8px 0 0 8px}.el-sbar>i:last-of-type{border-radius:0 8px 8px 0}
.el-sbar i.dem{background:var(--el-dem)}.el-sbar i.rep{background:var(--el-rep)}
.el-sbar i.ind{background:var(--el-mix)}
.el-maj{position:absolute;top:-5px;bottom:-5px;width:0;border-left:2px dashed var(--text-primary)}
.el-maj span{position:absolute;top:-17px;left:-24px;width:48px;text-align:center;
  font-size:10.5px;font-weight:700;color:var(--text-secondary);font-style:normal}
.el-sc-ind{font-size:12px;color:var(--muted);text-align:center;margin-top:4px}
.el-stats{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:6px;margin-top:10px}
.el-st{padding:8px 10px;border-radius:9px;background:var(--surface-2);min-width:0}
.el-st>span{display:block;font-size:11px;color:var(--muted);line-height:1.4}
.el-st b{display:block;margin-top:2px;font-size:15px;font-variant-numeric:tabular-nums;
  white-space:nowrap}
.el-st b small{margin-left:6px;font-size:11px;font-weight:600;color:var(--muted)}
.el-say{margin:12px 0 0;padding:2px 0 2px 12px;border-left:3px solid var(--text-primary);
  font-size:14px;line-height:1.75;font-weight:600}
.el-mapwrap{margin-top:12px}
.el-svg{display:block;width:100%;height:auto}
.el-svg .st{fill:var(--f);stroke:#fff;stroke-width:.8;cursor:pointer}
.el-svg .st.c-na{stroke:#b8b7af;stroke-dasharray:3 2}
.el-svg .st:hover,.el-svg .sb:hover .st{stroke:var(--text-primary);stroke-width:1.6}
.el-svg .lb{font-size:11px;font-weight:700;fill:#2b2b2b;text-anchor:middle;pointer-events:none}
.el-svg .lb-w{fill:#fff}
.el-info{display:flex;flex-wrap:wrap;align-items:baseline;gap:2px 12px;min-height:40px;
  margin-top:8px;padding:8px 12px;border-radius:9px;background:var(--surface-2);
  font-size:12.5px;color:var(--text-secondary);font-variant-numeric:tabular-nums}
.el-info b,.el-info span{flex-basis:100%}
.el-info b{font-size:13.5px;color:var(--text-primary)}
.el-info a{color:var(--series-1);font-weight:700}
.el-lg{list-style:none;margin:10px 0 0;padding:0;display:flex;flex-wrap:wrap;gap:6px 14px;
  font-size:11.5px;color:var(--muted)}
.el-lg li{display:flex;align-items:center;gap:3px}
.el-lg i{display:inline-block;width:12px;height:12px;border-radius:3px;background:var(--f);
  border:1px solid rgba(0,0,0,.08)}
.el-sub small{margin-left:6px;font-size:11px;font-weight:500;letter-spacing:0}
.el-cps{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:6px}
.el-cp{display:block;padding:7px 10px;border-radius:8px;background:var(--surface-2);
  border-left:5px solid var(--f);min-width:0}
.el-cp-s{display:block;font-size:11.5px;color:var(--muted);font-weight:700}
.el-cp b{display:block;font-size:16px;font-variant-numeric:tabular-nums}
.el-cp small{display:block;font-size:11.5px;color:var(--text-secondary);
  overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
@media (max-width:759px){
  .el-svg .lb{display:none}
  .el-sc b{font-size:28px}
  .el-stats{grid-template-columns:repeat(2,minmax(0,1fr))}
  .el-map-t{flex:1}
  .el-map-c{order:2}
  .el-map-s{order:3;flex-basis:100%}
  .el-cps{grid-template-columns:repeat(2,minmax(0,1fr))}
  .el-say{font-size:13.5px}
  .el-row{grid-template-columns:auto minmax(0,1fr);grid-template-areas:"name val" "bar bar";
    gap:8px 10px}
  .el-name{grid-area:name}.el-val{grid-area:val}.el-bar{grid-area:bar}
  .el-spark{display:none}
  .el-races{grid-template-columns:repeat(2,minmax(0,1fr))}
  .el-legend{grid-template-columns:1fr}}
.fs-brand{display:flex;justify-content:space-between;align-items:baseline;
  flex-wrap:wrap;gap:2px 12px;margin-top:12px;padding-top:9px;
  border-top:1px solid var(--grid)}
.fs-brand-name{font-size:11.5px;color:var(--text-secondary)}
.fs-brand-name b{font-size:13px;font-weight:800;letter-spacing:.04em;
  color:var(--text-primary);margin-right:8px}
.fs-brand-meta{font-size:11px;color:var(--muted);font-variant-numeric:tabular-nums}
.focus-strip .fs-note{margin-top:4px}

.home-transition{background:var(--surface-2)}
.home-transition-grid{display:grid;grid-template-columns:1fr;gap:8px}
.home-cell-now,.home-cell-next{padding:13px 14px;border-radius:10px;
  background:var(--surface-1);border:1px solid var(--border)}
.home-cell-now>span,.home-cell-next>span{display:block;font-size:10.5px;color:var(--muted)}
.home-cell-now b,.home-cell-next b{display:block;font-size:17px;line-height:1.35;margin-top:3px}
.home-cell-now small,.home-cell-next small{display:block;font-size:11.5px;color:var(--muted);margin-top:4px}
.home-cell-now{border-left:3px solid var(--series-1)}
.home-cell-next{border-left:3px solid var(--warning)}
.home-transition-arrow{display:none}
.home-trigger-detail{display:flex;flex-wrap:wrap;gap:6px}
.home-trigger-detail span{font-size:11.5px;padding:5px 8px;border-radius:999px;
  background:var(--surface-1);border:1px solid var(--border);color:var(--text-secondary)}
.home-trigger-unlock{margin-top:10px;font-size:11.5px;line-height:1.7;
  color:var(--text-secondary)}
.home-trigger-unlock>span{display:inline-block;font-size:10px;padding:2px 7px;
  margin-right:7px;border-radius:999px;border:1px solid var(--border);
  color:var(--muted);vertical-align:1px}
.home-dates{margin-top:12px;padding-top:10px;border-top:1px solid var(--grid);
  font-size:11px;line-height:1.7;color:var(--muted);font-variant-numeric:tabular-nums}

.home-module-list{border-top:1px solid var(--grid)}
details.home-module{margin:0;padding:0;border:0;border-bottom:1px solid var(--grid);
  background:transparent}
details.home-module[open]{padding-bottom:0}
.home-module>summary{position:relative;display:grid;grid-template-columns:1fr auto;
  gap:5px 10px;align-items:center;min-height:76px;padding:13px 34px 13px 2px;color:var(--text-primary)}
/* 模組列是卡片級收合：右側 ▾/▴，跟分頁的 .sect 同一家族 */
.home-module>summary::after{content:"▾";position:absolute;right:3px;top:22px;
  color:var(--muted);font-size:12px}
.home-module[open]>summary::after{content:"▴"}
.home-module-name{font-size:15px;font-weight:800}
.home-status{font-size:11.5px;font-weight:700;padding:3px 8px;border-radius:999px;
  background:var(--surface-2);white-space:nowrap}
.home-status.hawkish{color:var(--serious);background:var(--tint-haw)}
.home-status.dovish{color:var(--series-1);background:var(--tint-dov)}
.home-module-summary{grid-column:1/-1;font-size:12.5px;font-weight:400;
  line-height:1.55;color:var(--text-secondary)}
.home-module-toggle{display:none}
.home-module-body{padding:0 2px 14px}
.home-module-stats{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));
  gap:7px;padding:11px;border-radius:10px;background:var(--surface-2)}
.home-module-stats>div{min-width:0}
.home-module-stats span{display:block;font-size:10.5px;color:var(--muted)}
.home-module-stats b{display:block;margin-top:2px;font-size:14px;
  font-variant-numeric:tabular-nums;overflow-wrap:anywhere}
.home-inline-link{margin-top:4px}

.home-change-list{display:grid;gap:0;border-top:1px solid var(--grid)}
.home-change{display:grid;grid-template-columns:8px minmax(0,1fr);gap:0 10px;
  padding:13px 2px;border-bottom:1px solid var(--grid)}
.home-change-dot{width:7px;height:7px;border-radius:50%;margin-top:8px;background:var(--muted-bar)}
.home-change-dot.hawkish{background:var(--series-2)}
.home-change-dot.dovish{background:var(--series-1)}
.home-change>div{display:flex;flex-direction:column;min-width:0}
.home-change b{font-size:13.5px}
.home-change span{font-size:12px;color:var(--muted);font-variant-numeric:tabular-nums}
.home-change p{grid-column:2;font-size:12.5px;line-height:1.5;color:var(--text-secondary);margin:5px 0 0}
.home-empty{padding:20px 2px;color:var(--muted);font-size:13px}

/* 接下來看什麼：發布日倒數 ＋「它會動什麼」。
   日期欄固定寬、tabular-nums，六列掃下來像一張行事曆。 */
.home-next-list{border-top:1px solid var(--grid)}
.hn-row{display:grid;grid-template-columns:96px minmax(0,1fr);gap:2px 14px;
  padding:12px 2px;border-bottom:1px solid var(--grid)}
.hn-date b{display:block;font-size:15px;font-weight:700;
  font-variant-numeric:tabular-nums}
.hn-date span{display:block;font-size:10.5px;color:var(--muted);margin-top:2px;
  white-space:nowrap}
.hn-main b{display:block;font-size:13.5px}
.hn-main span{display:block;font-size:12px;line-height:1.65;
  color:var(--text-secondary);margin-top:3px}
.hn-src{grid-column:2;font-size:10.5px;color:var(--muted)}
/* 本週／下週分組標題；影響小標（高＝實心、中＝外框），顏色不單獨承載意義 */
.hn-group{font-size:11.5px;font-weight:700;letter-spacing:.06em;
  color:var(--muted);padding:14px 2px 4px;border-bottom:1px solid var(--grid)}
.hn-imp{display:inline-block;font-style:normal;font-size:10.5px;
  font-weight:700;line-height:1;padding:3px 5px;border-radius:3px;
  margin-left:7px;vertical-align:1px}
.hn-imp.high{background:var(--series-1);color:var(--surface-1)}
.hn-imp.mid{border:1px solid var(--border);color:var(--text-secondary)}
@media(min-width:760px){
  .hn-row{grid-template-columns:112px minmax(0,1fr) auto;align-items:start}
  .hn-src{grid-column:auto;padding-top:3px}
}
.home-next-foot{margin-top:12px;font-size:11.5px;line-height:1.7;color:var(--muted)}
.data-tag.next{border-color:var(--series-1);color:var(--series-1)}

.home-footer{display:grid;grid-template-columns:1fr;gap:16px;padding-top:18px;
  border-top:1px solid var(--baseline)}
.home-footer>div{display:flex;flex-direction:column;gap:3px}
.home-footer b{font-size:12px;color:var(--text-secondary)}
.home-footer span{font-size:11.5px;line-height:1.65;color:var(--muted)}
.home-footer a{color:var(--series-1);text-decoration:none}

@media(min-width:760px){
  .home-dashboard{margin-top:18px}
  .home-hero{padding:27px 29px}
  .home-hero-top{flex-direction:row;align-items:flex-start;justify-content:space-between}
  .home-hero h2{font-size:36px}
  .home-verdict{min-width:230px}
  .home-narrative{margin-top:24px;padding-top:21px}
  .home-brief-label{flex-direction:row;align-items:baseline;gap:10px}
  .home-brief-text,.home-brief-more p{font-size:15.5px}
  .home-status-rail{grid-template-columns:repeat(4,minmax(0,1fr))}
  .home-status-rail>div{padding:12px 14px;border-bottom:0}
  .home-status-rail>div:nth-child(2n){border-right:1px solid var(--grid)}
  .home-status-rail>div:last-child{border-right:0}
  .home-status-rail b{font-size:14px}
  .home-zone{margin-top:18px;padding:22px 25px}
  .home-zone-head{align-items:center}
  .home-zone-head h2{font-size:20px}
  .home-transition-grid{grid-template-columns:minmax(0,1fr) 34px minmax(0,1fr);
    align-items:stretch}
  .home-transition-arrow{display:flex;align-items:center;justify-content:center;
    color:var(--muted);font-size:19px}
  .home-trigger-detail{grid-column:3}
  .home-cell-now,.home-cell-next{padding:15px 17px}
  .home-cell-now b,.home-cell-next b{font-size:19px}
  .home-module>summary{grid-template-columns:110px 105px minmax(0,1fr) 44px;
    gap:14px;min-height:68px;padding:12px 2px}
  .home-module>summary::after{display:none}
  .home-module-summary{grid-column:auto;font-size:13px}
  .home-module-toggle{display:block;text-align:right;font-size:12px;color:var(--series-1)}
  .home-module-stats{grid-template-columns:repeat(4,minmax(0,1fr));padding:13px 15px}
  .home-change{grid-template-columns:8px minmax(180px,.75fr) minmax(0,1fr);
    align-items:start;column-gap:12px}
  .home-change p{grid-column:3;margin:0;font-size:13px}
  .home-footer{grid-template-columns:1.15fr .85fr;gap:40px}
}
@media(max-width:430px){
  .home-zone-head{flex-direction:column;gap:7px}
  .home-zone-head p{text-align:left;margin:0}
  .home-primary-link{margin:0}
  .home-hero h2{font-size:26px}
}
@media(max-width:759px){
  details.home-module+details.home-module{margin-top:7px}
}

/* ---------- 內容頁 v3：主卡精簡、主題單層收合 ---------- */
.focus-card{padding:18px 17px;border-radius:15px;border-top-width:4px}
.focus-title{font-size:25px;line-height:1.25}
.focus-sub{max-width:52em;line-height:1.65;margin-top:7px}
.focus-grid{grid-template-columns:1fr;gap:0;margin-top:17px;
  border-top:1px solid var(--grid);border-bottom:1px solid var(--grid)}
.focus-metric{display:grid;grid-template-columns:minmax(94px,.7fr) minmax(0,1fr);
  gap:2px 12px;align-items:start;padding:11px 4px;border:0;border-radius:0;
  border-bottom:1px solid var(--grid);background:transparent}
.focus-metric:last-child{border-bottom:0}
.focus-metric>span{grid-column:1;grid-row:1/3;padding-top:2px}
.focus-metric>b{grid-column:2;font-size:17px;overflow-wrap:anywhere}
.focus-metric>small{grid-column:2;line-height:1.45}
.focus-metric.hawkish,.focus-metric.dovish,.focus-metric.watch{border-left:0}
.focus-metric.hawkish{box-shadow:inset 3px 0 0 var(--critical)}
.focus-metric.dovish{box-shadow:inset 3px 0 0 var(--good)}
.focus-metric.watch{box-shadow:inset 3px 0 0 var(--warning)}

.focus-evidence{margin:14px 0 0;padding:0;border-top:1px solid var(--grid)}
.focus-evidence>summary{display:flex;align-items:center;min-height:44px;padding:9px 0;
  font-size:12.5px;color:var(--series-1)}
/* 卡內收合統一「開頭 ▸/▾」家族 */
.focus-evidence>summary::before{content:"▸";margin-right:6px;font-size:10px}
.focus-evidence[open]>summary::before{content:"▾"}
.focus-evidence>summary::after{content:""}
.focus-evidence-body{padding:0 0 5px}
.focus-evidence .logic-strip{margin-top:0;gap:0}
.focus-evidence .logic-step{padding:10px 2px;border:0;border-radius:0;
  border-bottom:1px solid var(--grid);background:transparent}
.focus-evidence .logic-step:last-child{border-bottom:0}
.focus-evidence .grid-flow{margin-top:0}
.focus-evidence .flow-box{background:var(--surface-2);box-shadow:none}

.focus-card .data-line{margin-top:10px;padding-top:9px;border-top:1px solid var(--grid);
  gap:3px 12px}
.focus-card .data-tag{padding:2px 0;border:0;border-radius:0;background:transparent;
  color:var(--muted)}
.focus-card .data-tag[href]{min-height:40px}

/* 下方每個主題就是唯一可操作的收合層；內部舊細節只做靜態分隔。 */
/* 教學層：「這在看什麼？」。全站固定樣式與位置——讀者看熟了就知道
   每一區都有地方可以學。刻意用不同底色跟證據層（f-more）區分：
   一個是教你怎麼讀，一個是給你驗算。 */
/* 收合時只是一行提示——跟「依據」（.f-more）同字級、同高度、同位置感，
   卡片的比例才不會被一個大盒子撐歪；全站每張卡都長一樣。
   展開後內容才進到虛線盒（教學內容跟證據層還是要分得出來）。
   summary 上下 padding 12px：17px 行高 + 24px ＝ 41px，滿足 40px 觸控高。 */
.teach{margin:0 0 4px;border:0;border-radius:0;background:transparent}
.teach>summary{cursor:pointer;list-style:none;padding:12px 0;font-size:12.5px;
  font-weight:500;color:var(--muted)}
.teach>summary:hover{color:var(--series-1)}
.teach>summary::-webkit-details-marker{display:none}
.teach>summary::before{content:"？";display:inline-block;width:17px;height:17px;
  line-height:17px;text-align:center;border-radius:50%;background:var(--surface-2);
  border:1px solid var(--grid);margin-right:7px;font-size:11px}
.teach-body{margin:2px 0 12px;padding:8px 12px;border:1px dashed var(--grid);
  border-radius:9px;background:var(--surface-2);
  font-size:12.5px;line-height:1.8;color:var(--text-primary)}
.teach-body p{margin:6px 0}
/* 關鍵指標檢核：格子等高。高度不一的原因是各格的說明文長度不同，
   說明移進收合層之後，剩下的固定四行（名稱／數值／狀態／歷史條）自然等高。 */
.l-link{display:inline-block;margin-top:4px;padding:12px 0;font-size:12px;
  font-weight:600;color:var(--series-1);text-decoration:none}
.lights{align-items:stretch}
.light{display:flex;flex-direction:column}
.light .l-more{margin-top:auto;padding-top:8px}
.light .l-more>summary{cursor:pointer;list-style:none;font-size:12px;
  color:var(--muted)}
.light .l-more>summary::-webkit-details-marker{display:none}
/* 燈卡的收合改用全站統一的「開頭 ▸/▾」——先前是結尾 ▾，
   跟其他卡內收合方向相反。 */
.light .l-more>summary{padding-left:13px;text-indent:-13px}
.light .l-more>summary::before{content:"▸";display:inline-block;width:13px;
  text-indent:0;font-size:9px;color:var(--series-1)}
.light .l-more[open]>summary::before{content:"▾"}
.legacy-detail{margin-top:15px;padding-top:14px;border-top:1px solid var(--grid)}
.legacy-detail>h4{font-size:13px;margin:0 0 9px;color:var(--text-secondary)}
.sect-body .card{box-shadow:none}
.sect-body .legacy-detail .card{border:0;background:transparent;padding-left:0;padding-right:0}
.sect-tools{margin-top:14px}

@media(min-width:760px){
  .focus-card{padding:25px 27px}
  .focus-title{font-size:29px}
  .focus-grid{grid-template-columns:repeat(4,minmax(0,1fr))}
  .focus-metric{display:flex;flex-direction:column;gap:3px;padding:12px 15px;
    border-bottom:0;border-right:1px solid var(--grid)}
  .focus-metric:last-child{border-right:0}
  .focus-metric>span,.focus-metric>b,.focus-metric>small{display:block}
  .focus-metric>b{font-size:19px}
  .focus-evidence .logic-strip{grid-template-columns:repeat(3,minmax(0,1fr))}
  .focus-evidence .logic-step{padding:11px 14px;border-bottom:0;border-right:1px solid var(--grid)}
  .focus-evidence .logic-step:last-child{border-right:0}
}
@media(max-width:759px){
  .focus-card+.sect-tools{margin-top:10px}
  details.card.sect+details.card.sect{margin-top:9px}
  .sect>summary{padding:14px 14px;min-height:64px}
  .sect-body{padding:0 14px 16px}
}

/* ===================================================================
   2026-10 圖表改版：近 5 期（kh）、精簡走勢（cl）、瀑布（wf）、
   數線（nl）、傳導鏈（chain）、零軸細柱（gc）
   =================================================================== */
.kh{margin-top:10px;font-variant-numeric:tabular-nums}
.kh-top{display:flex;justify-content:space-between;gap:8px;font-size:11.5px;
  color:var(--muted);margin-bottom:4px}
.kh-vals,.kh-dates{display:grid;grid-template-columns:repeat(var(--n),minmax(0,1fr));
  text-align:center}
.kh-vals span{font-size:12.5px;color:var(--text-secondary);font-weight:500}
.kh-vals span.last{color:var(--series-1);font-weight:700}
.kh-dates span{font-size:11px;color:var(--muted);margin-top:4px;white-space:nowrap}
.kh-plot{position:relative;height:76px;display:grid;
  grid-template-columns:repeat(var(--n),minmax(0,1fr));
  border-bottom:1px solid var(--grid)}
.kh-col{position:relative;cursor:default}
.kh-col:hover{background:var(--surface-2)}
.kh-bar{position:absolute;left:50%;transform:translateX(-50%);width:min(22px,46%);
  background:var(--muted-bar);border-radius:3px}
.kh-bar.last{background:var(--series-1)}
.kh-dot{position:absolute;left:50%;width:9px;height:9px;border-radius:50%;
  transform:translate(-50%,-50%);background:var(--muted-bar);
  box-shadow:0 0 0 2px var(--surface-1)}
.kh-dot.last{background:var(--series-1);width:11px;height:11px}
.kh-line{position:absolute;inset:0;width:100%;height:100%;pointer-events:none}
.kh-ref{position:absolute;left:0;right:0;border-top:1.5px dashed var(--text-secondary);
  pointer-events:none;z-index:1}
.kh-zero{position:absolute;left:0;right:0;border-top:1px solid var(--baseline);
  pointer-events:none}
.kh-band{position:absolute;left:0;right:0;background:rgba(42,120,214,.12);
  pointer-events:none}
.kh-leg,.cl-leg{display:flex;flex-wrap:wrap;gap:4px 14px;font-size:12px;
  color:var(--text-secondary);margin-top:8px}
.kh-leg span,.cl-leg span{display:inline-flex;align-items:center;gap:5px}
.cl-leg i{display:inline-block;width:14px;height:3px;border-radius:2px}
.cl-leg b{color:var(--text-primary)}
.cl-leg em{font-style:normal;color:var(--muted);font-size:11px}
i.lg-ref{display:inline-block;width:16px;height:0!important;
  border-top:1.5px dashed var(--text-secondary);background:none!important}
i.lg-band{display:inline-block;width:14px;height:10px;background:rgba(42,120,214,.18);
  border-radius:2px}
i.lg-fill{display:inline-block;width:14px!important;height:10px!important;
  background:rgba(235,104,52,.22)!important}

.cl{margin-top:8px}
.cl-plot{position:relative;margin-left:38px;border-bottom:1px solid var(--baseline)}
.cl-plot svg{display:block;width:100%;height:100%}
.cl-tick{position:absolute;right:calc(100% + 6px);transform:translateY(-50%);
  font-size:11px;color:var(--muted);white-space:nowrap;
  font-variant-numeric:tabular-nums}
.cl-reflab{position:absolute;left:4px;transform:translateY(-120%);font-size:11px;
  color:var(--text-secondary);background:var(--surface-1);padding:0 3px;
  border-radius:3px;pointer-events:none}
.cl-hit{position:absolute;top:0;bottom:0;z-index:2}
.cl-hit:hover::after{content:"";position:absolute;left:50%;top:0;bottom:0;
  border-left:1px solid var(--text-secondary);opacity:.5}
.cl-x{display:flex;justify-content:space-between;font-size:11.5px;color:var(--muted);
  margin:5px 0 0 38px;font-variant-numeric:tabular-nums}
.cl-note{font-size:12px;color:var(--muted);margin-top:4px}
.cl-pair{display:grid;gap:18px}
@media(min-width:760px){.cl-pair{grid-template-columns:1fr 1fr}}
.cl-pair h4,.viz-h{font-size:13.5px;margin:0 0 2px;font-weight:700;color:var(--text-primary)}
.viz-sub{font-size:12px;color:var(--muted);margin:0 0 4px}

.wf{margin-top:14px}
.wf-row{display:grid;grid-template-columns:minmax(84px,30%) 1fr 72px;gap:10px;
  align-items:center;padding:7px 4px;border-radius:6px}
.wf-row:hover{background:var(--surface-2)}
.wf-name{font-size:13px;line-height:1.35}
.wf-note{display:block;font-size:11px;color:var(--muted)}
.wf-track{position:relative;height:18px}
.wf-zero{position:absolute;top:-8px;bottom:-8px;border-left:1px solid var(--text-secondary)}
.wf-seg{position:absolute;top:0;bottom:0;border-radius:3px}
.wf-seg.up{background:var(--neg)}
.wf-seg.dn{background:var(--pos)}
.wf-val{text-align:right;font-weight:700;font-size:14px;font-variant-numeric:tabular-nums}
.wf-val small{font-size:11px;font-weight:500;color:var(--muted);margin-left:2px}
.wf-val.up{color:var(--critical)}
.wf-val.dn{color:var(--series-1)}
.wf-leg{display:flex;flex-wrap:wrap;gap:4px 14px;font-size:12px;color:var(--text-secondary);
  margin-top:8px}
.wf-leg i{display:inline-block;width:12px;height:12px;border-radius:3px;
  vertical-align:-2px;margin-right:5px}
.wf-leg i.up{background:var(--neg)}
.wf-leg i.dn{background:var(--pos)}
.wf-hint{color:var(--muted)}

.nl{margin:18px 4px 4px}
.nl-axis{position:relative;height:22px;border-bottom:2px solid var(--baseline)}
.nl-dot{position:absolute;bottom:-8px;width:14px;height:14px;border-radius:50%;
  transform:translateX(-50%);box-shadow:0 0 0 2px var(--surface-1);z-index:2}
.nl-tgt{position:absolute;bottom:-10px;height:30px;border-left:2px dashed var(--text-secondary)}
.nl-tgtlab{position:absolute;top:-16px;transform:translateX(-50%);font-size:11.5px;
  color:var(--text-secondary);white-space:nowrap;font-weight:600}
.nl-ticks{position:relative;height:18px;margin-top:4px}
.nl-ticks span{position:absolute;transform:translateX(-50%);font-size:11px;
  color:var(--muted);top:4px}
.nl-labs{margin-top:6px}
.nl-lab{position:relative;height:24px}
.nl-txt{position:absolute;left:clamp(0px,calc(var(--x) - 80px),calc(100% - 190px));
  font-size:12.5px;white-space:nowrap;top:3px}
.nl-txt i{display:inline-block;width:9px;height:9px;border-radius:50%;margin-right:5px}
.nl-txt b{font-variant-numeric:tabular-nums}

.chain{display:grid;grid-template-columns:1fr;gap:0;margin:14px 0 4px}
@media(min-width:760px){.chain{grid-template-columns:1fr 76px 1fr 76px 1fr;align-items:stretch}}
.ch-step{border:1px solid var(--border);border-radius:10px;padding:11px 13px;
  background:var(--surface-1)}
.ch-step.hl{border-color:var(--text-primary);box-shadow:inset 0 0 0 1px var(--text-primary)}
.ch-lab{font-size:12.5px;color:var(--text-secondary);font-weight:600}
.ch-val{font-size:22px;font-weight:700;margin-top:2px;font-variant-numeric:tabular-nums}
.ch-step.up .ch-val{color:var(--critical)}
.ch-step.down .ch-val{color:var(--series-1)}
.ch-note{font-size:12px;color:var(--muted);margin-top:3px;line-height:1.5}
.ch-arrow{display:flex;align-items:center;justify-content:center;position:relative;
  height:30px;font-size:11px;color:var(--muted);text-align:center;line-height:1.35}
.ch-arrow::before{content:"↓";font-size:16px;color:var(--text-secondary);margin-right:6px}
@media(min-width:760px){
  .ch-arrow{height:auto;flex-direction:column}
  .ch-arrow::before{content:"→";font-size:20px;margin:0}
}

.gc{margin-top:8px}
.gc-plot{position:relative;height:96px;display:flex;gap:2px;margin-left:38px}
.gc-plot.lbl{margin-bottom:18px}
.gc-zero{position:absolute;left:0;right:0;top:50%;border-top:1px solid var(--text-secondary)}
.gc-mx,.gc-mn{position:absolute;right:calc(100% + 6px);font-size:11px;color:var(--muted);
  font-variant-numeric:tabular-nums}
.gc-mx{top:-6px}.gc-mn{bottom:-6px}
.gc-col{position:relative;flex:1 1 0;min-width:0}
.gc-col:hover{background:var(--surface-2)}
.gc-bar{position:absolute;left:12%;right:12%;border-radius:2px;opacity:.45}
.gc-bar.up{background:var(--neg)}.gc-bar.dn{background:var(--pos)}
.gc-bar.on{opacity:1}
.gc-lab{position:absolute;top:100%;left:0;right:0;text-align:center;font-size:10.5px;
  color:var(--muted);margin-top:3px}
.cl-leg i.gc-up{width:10px;height:10px;background:var(--neg)}
.cl-leg i.gc-dn{width:10px;height:10px;background:var(--pos)}
.viz-block{margin-top:18px}

/* ---------- 長端頁（2026-10）---------- */
.le-top{display:flex;flex-wrap:wrap;align-items:flex-end;gap:6px 22px;margin:4px 0 6px}
.le-k{display:block;font-size:12.5px;color:var(--muted);font-weight:600}
.le-big b{font-size:44px;font-weight:800;line-height:1.05;font-variant-numeric:tabular-nums;color:var(--brand-ink)}
.le-small b{font-size:24px;font-weight:700;font-variant-numeric:tabular-nums}
.le-small span:last-child{display:block;font-size:12.5px;color:var(--muted)}
.le-chg{display:inline-block;margin-left:10px;font-size:13px;font-weight:700;padding:2px 8px;border-radius:999px;vertical-align:6px}
.le-chg.up{background:#fbe9e9;color:var(--critical)}.le-chg.dn{background:#e6eef9;color:var(--series-1)}
.le-asof{font-size:12px;color:var(--muted);margin-left:auto}
.sg{margin-top:14px}
.sg-h{font-size:12.5px;color:var(--text-secondary);font-weight:600;margin-bottom:6px}
.sg-bar{display:flex;height:34px;border-radius:8px;overflow:hidden;gap:2px}
.sg-seg{display:flex;align-items:center;justify-content:center;color:#fff;font-size:13px;min-width:0}
.sg-seg b{font-weight:700;font-variant-numeric:tabular-nums;white-space:nowrap;overflow:hidden}
.sg .cl-leg i{width:10px!important;height:10px!important}
.sg-neg{font-size:12px;color:var(--muted);margin-top:4px}
.le-tiles{display:grid;gap:8px;margin-top:14px}
@media(min-width:760px){.le-tiles{grid-template-columns:repeat(3,1fr)}}
.le-tile{position:relative;border:1px solid var(--border);border-left:5px solid var(--c);border-radius:10px;
  padding:10px 12px;background:var(--surface-1)}
.le-tile.main{box-shadow:0 0 0 2px var(--c) inset}
.le-badge{display:inline-block;font-size:11px;font-weight:700;color:#fff;background:#E67143;border-radius:999px;
  padding:1px 8px;margin-left:8px;vertical-align:2px}
.le-tile .le-badge{position:absolute;right:10px;top:10px;margin:0}
.le-tk{font-size:12px;font-weight:700;color:var(--text-secondary);letter-spacing:.04em}
.le-tn{font-size:14px;font-weight:700;margin-top:1px}
.le-tv{font-size:22px;font-weight:700;margin-top:4px;font-variant-numeric:tabular-nums}
.le-tv span{font-size:13px;margin-left:8px;font-weight:700}
.le-tv .up{color:var(--critical)}.le-tv .dn{color:var(--series-1)}
.le-tx{font-size:12.5px;color:var(--text-secondary);margin-top:4px;line-height:1.55}
.evs{margin-top:14px;border-top:1px solid var(--grid);padding-top:10px}
.evs-h{font-size:12px;font-weight:700;color:var(--muted);letter-spacing:.06em;margin-bottom:4px}
.ev{display:flex;gap:10px;align-items:baseline;font-size:13px;padding:3px 0}
.ev-d{font-weight:700;font-variant-numeric:tabular-nums;min-width:40px;color:var(--brand-ink)}
.ev-k{font-size:11.5px;padding:1px 7px;border-radius:6px;background:var(--surface-2);color:var(--text-secondary);white-space:nowrap}
.tabs{margin-top:12px}
.tabs>input{position:absolute;opacity:0;pointer-events:none}
.tabs>label{display:inline-block;font-size:13px;font-weight:600;padding:6px 14px;border:1px solid var(--border);
  border-radius:999px;margin:0 6px 8px 0;cursor:pointer;color:var(--text-secondary)}
.tabs>input:checked+label{background:var(--brand-navy);color:#fff;border-color:var(--brand-ink)}
.tabs>input:focus-visible+label{outline:2px solid var(--series-1)}
.tabp{display:none}
#le-br1:checked~.tabp.p1,#le-br3:checked~.tabp.p3,#le-br12:checked~.tabp.p12{display:block}
.br{margin-top:4px}
.br-row{display:grid;grid-template-columns:minmax(96px,32%) 1fr 70px;gap:10px;align-items:center;padding:6px 4px;border-radius:6px}
.br-row:hover{background:var(--surface-2)}
.br-row.main .br-name{font-weight:700}
.br-name{font-size:13px;line-height:1.35}
.br-note{display:block;font-size:11px;color:var(--muted)}
.br-track{position:relative;height:18px}
.br-guide{position:absolute;top:-10px;bottom:-10px;border-left:1px dashed var(--baseline)}
.br-seg{position:absolute;top:0;bottom:0;border-radius:3px}
.br-seg.up{background:var(--neg)}.br-seg.dn{background:var(--pos)}.br-seg.muted{opacity:.35}
.br-tick{position:absolute;top:-4px;bottom:-4px;width:4px;margin-left:-2px;border-radius:2px;background:var(--muted-bar)}
.br-tick.now{background:var(--brand-navy)}
.br-end{border-top:1px solid var(--grid)}
.br-row:first-child{border-top:0}
.br-val{text-align:right;font-weight:700;font-variant-numeric:tabular-nums;font-size:14px}
.br-val small{font-size:11px;color:var(--muted);font-weight:500;margin-left:2px}
.br-val.up{color:var(--critical)}.br-val.dn{color:var(--series-1)}
.le-match{margin-top:18px;border:1px solid var(--border);border-radius:12px;padding:12px 14px}
.le-mrow{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin:8px 0}
.le-mrow span{display:block;font-size:11.5px;color:var(--muted)}
.le-mrow b{font-size:20px;font-variant-numeric:tabular-nums}
.le-mrow em{display:block;font-style:normal;font-size:12px;color:var(--text-secondary)}
.cat-x{display:grid;grid-template-columns:repeat(var(--n),1fr);margin:5px 0 0 38px;text-align:center;
  font-size:11.5px;color:var(--muted)}
.ldot.sm{width:6px;height:6px}
.le-slope{border:1px solid var(--border);border-radius:10px;padding:10px 12px}
.le-sk{font-size:12.5px;font-weight:700;color:var(--text-secondary)}
.le-sv{font-size:24px;font-weight:700;font-variant-numeric:tabular-nums}
.le-sv small{font-size:12px;color:var(--muted);margin-left:2px}
.le-sv span{font-size:12px;font-weight:500;color:var(--muted);margin-left:10px}
.le-gs{display:grid;grid-template-columns:repeat(2,1fr);gap:8px;margin-top:10px}
@media(min-width:760px){.le-gs{grid-template-columns:repeat(4,1fr)}}
.le-g{border:1px solid var(--border);border-radius:10px;padding:9px 12px}
.le-g span{display:block;font-size:12.5px;font-weight:700;color:var(--text-secondary)}
.le-g b{font-size:21px;font-variant-numeric:tabular-nums}
.le-g em{display:block;font-style:normal;font-size:12px;color:var(--muted)}
.le-h3{font-size:15px;margin:18px 0 8px;padding-top:10px;border-top:1px solid var(--grid)}
.le-h3:first-child{border-top:0;padding-top:0;margin-top:4px}
.le-quote{border-left:4px solid #12233B;background:var(--surface-2);border-radius:0 10px 10px 0;padding:10px 14px;font-size:13.5px;line-height:1.65}
.le-qh{font-size:12px;font-weight:700;color:var(--muted)}
.le-quote blockquote{margin:6px 0;font-style:italic;color:var(--brand-ink)}
.le-quote p{margin:4px 0}
.le-sizes{display:grid;gap:10px;margin-top:12px}
@media(min-width:760px){.le-sizes{grid-template-columns:repeat(2,1fr)}}
@media(min-width:1100px){.le-sizes{grid-template-columns:repeat(3,1fr)}}
.le-size{border:1px solid var(--border);border-radius:10px;padding:10px 12px}
.le-szh{display:flex;justify-content:space-between;gap:8px;align-items:baseline;font-size:12.5px;color:var(--muted)}
.le-szh b{font-size:15px;color:var(--text-primary)}
.le-size .kh{margin-top:4px}.le-size .kh-vals span{font-size:11px}
.le-ups{margin-top:8px}
.le-up{display:grid;grid-template-columns:46px 1fr auto auto;gap:10px;align-items:baseline;font-size:13.5px;padding:6px 0;border-bottom:1px solid var(--grid)}
.le-up span:nth-child(3){font-size:12px;color:var(--muted)}
.le-mix{display:grid;grid-template-columns:96px 1fr;gap:10px;align-items:center;margin-top:8px}
.le-mixk{font-size:12.5px;color:var(--text-secondary)}
.le-mixb{display:flex;height:26px;border-radius:6px;overflow:hidden;gap:2px}
.le-mixb span{display:flex;align-items:center;justify-content:center;color:#fff;font-size:11.5px;font-weight:700;min-width:0}
.le-wam{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin:6px 0 4px}
.le-wam div{border:1px solid var(--border);border-radius:10px;padding:9px 12px}
.le-wam span{display:block;font-size:12px;color:var(--muted)}
.le-wam b{font-size:24px;font-variant-numeric:tabular-nums}
.le-wam small{font-size:13px;font-weight:500}
.le-wam em{display:block;font-style:normal;font-size:11.5px;color:var(--muted)}
.dc2-col{position:relative;flex:1 1 0;min-width:0}
.dc2-col:hover{background:var(--surface-2)}
.dc2-bar{position:absolute;width:40%;border-radius:2px}
.aus{display:grid;grid-template-columns:repeat(2,1fr);gap:8px;margin-top:12px}
@media(min-width:760px){.aus{grid-template-columns:repeat(4,1fr)}}
.au{border:1px solid var(--border);border-top:4px solid var(--muted-bar);border-radius:10px;padding:9px 11px;background:var(--surface-1)}
.au.weak{border-top-color:var(--critical)}.au.strong{border-top-color:var(--good)}
.au-h{display:flex;align-items:baseline;gap:6px;flex-wrap:wrap}
.au-h b{font-size:15px}.au-h span{font-size:11.5px;color:var(--muted)}
.au-v{margin-left:auto;font-weight:700;color:var(--text-secondary)!important}
.au.weak .au-v{color:var(--critical)!important}.au.strong .au-v{color:var(--good)!important}
.au-y{font-size:20px;font-weight:700;font-variant-numeric:tabular-nums;margin:2px 0 4px}
.au-y small{font-size:11px;color:var(--muted);font-weight:500;margin-left:4px}
.au-kv{display:flex;align-items:baseline;gap:6px;font-size:12px;padding:2px 0}
.au-kv span{color:var(--muted);min-width:58px}
.au-kv b{font-variant-numeric:tabular-nums}
.au-kv b.up{color:var(--critical)}.au-kv b.dn{color:var(--good)}
.au-kv em{font-style:normal;color:var(--muted);font-size:11px;margin-left:auto}
@media(max-width:759px){.au-kv{flex-wrap:wrap;gap:0 6px}.au-kv span{min-width:0}
  .au-kv em{width:100%;margin-left:0;font-size:10.5px}}
.au-gauge{position:relative;height:6px;border-radius:3px;margin:2px 0 4px;
  background:linear-gradient(90deg,#f3c6c6,#eeede9 45%,#eeede9 55%,#c7e6c7)}
.au-gauge i{position:absolute;top:-3px;width:4px;height:12px;margin-left:-2px;background:var(--brand-navy);border-radius:2px}
.au-mix{display:flex;height:10px;border-radius:5px;overflow:hidden;gap:1px;margin-top:8px}
.le-hss{display:grid;gap:10px;margin-top:12px}
@media(min-width:760px){.le-hss{grid-template-columns:repeat(2,1fr)}}
@media(min-width:1100px){.le-hss{grid-template-columns:repeat(3,1fr)}}
.le-hs{border:1px solid var(--border);border-radius:10px;padding:10px 12px}
.le-hsr{font-size:12.5px;color:var(--text-secondary)}
.le-hsr b{font-size:15px}.le-hsr b.up{color:var(--critical)}
.le-hsd{font-size:12px;color:var(--muted);margin-top:4px}
.le-hs .kh-vals span{font-size:10.5px}
.le-lgs{display:grid;gap:4px 10px;grid-template-columns:1fr}
.le-lgc{display:grid;gap:8px;grid-template-columns:repeat(2,minmax(0,1fr))}
@media(min-width:760px){.le-lgs{grid-template-columns:repeat(4,minmax(0,1fr))}
  .le-lg{grid-column:span var(--k)}.le-lgc{grid-template-columns:repeat(var(--k),minmax(0,1fr))}}
.le-hero .focus-title{font-size:22px}
@media(min-width:760px){.le-hero .focus-title{font-size:26px}}

/* ---------- 聯準會：官員樹狀圖＋人物面板（2026-10）---------- */
.ot{margin-top:6px}
.ot-root{display:flex;align-items:baseline;justify-content:center;gap:10px;margin:0 auto;
  width:max-content;padding:8px 18px;border-radius:999px;background:var(--brand-navy);color:#fff}
.ot-root span{font-weight:800;letter-spacing:.08em}
.ot-root b{font-weight:500;font-size:13px;opacity:.9}
.ot-brs{position:relative;display:grid;gap:12px;margin-top:22px}
.ot-brs::before{content:"";position:absolute;left:50%;top:-22px;height:12px;
  border-left:1.5px solid var(--baseline)}
.ot-br{position:relative;border:1px solid var(--border);border-radius:12px;padding:12px 12px 10px;
  background:var(--surface-1)}
.ot-br.alts{background:var(--surface-2);border-style:dashed}
.ot-bh{display:flex;flex-wrap:wrap;align-items:baseline;gap:4px 10px;margin-bottom:10px}
.ot-bt{font-weight:700;font-size:14px}
.ot-bt b{font-size:17px;color:var(--series-1)}
.ot-bw{font-size:12px;color:var(--muted)}
.ot-nodes{display:flex;flex-wrap:wrap;gap:6px 4px}
.ot-n{appearance:none;border:0;background:none;padding:6px 4px 4px;border-radius:10px;cursor:pointer;
  display:flex;flex-direction:column;align-items:center;width:80px;font:inherit;color:inherit}
.ot-n:hover{background:var(--surface-2)}
.ot-n:focus-visible{outline:2px solid var(--series-1);outline-offset:1px}
.ot-n[aria-pressed="true"]{background:#e8eef7}
.ot-n[aria-pressed="true"] .ot-av{box-shadow:0 0 0 3px #fff,0 0 0 5px var(--series-1)}
.ot-av{position:relative;display:flex;align-items:center;justify-content:center;width:42px;height:42px;
  border-radius:50%;background:var(--bg);border:3px solid var(--muted-bar);font-weight:700;font-size:14px;
  letter-spacing:.02em;color:var(--text-primary)}
.ot-av.hawkish{border-color:var(--critical)}
.ot-av.dovish{border-color:var(--good)}
.ot-n.t1 .ot-av{width:54px;height:54px;font-size:17px;background:var(--brand-navy);color:#fff}
.ot-n.t2 .ot-av{width:48px;height:48px;font-size:15px}
.ot-n.alt .ot-av{color:var(--muted);border-style:dashed}
.ot-star{position:absolute;right:-5px;top:-5px;font-style:normal;font-size:13px;color:#E67143;
  text-shadow:0 0 2px #fff}
.ot-sn{font-size:12.5px;font-weight:600;margin-top:5px;max-width:100%;overflow:hidden;
  text-overflow:ellipsis;white-space:nowrap}
.ot-role{font-size:11px;color:var(--muted);white-space:nowrap}
.ot-leg{display:flex;flex-wrap:wrap;gap:4px 14px;font-size:12px;color:var(--text-secondary);margin-top:10px}
.ot-leg span{display:inline-flex;align-items:center;gap:6px}
.ot-lg{display:inline-block;width:13px;height:13px;border-radius:50%;border:3px solid var(--muted-bar);background:var(--bg)}
.ot-lg.hawkish{border-color:var(--critical)}.ot-lg.dovish{border-color:var(--good)}
.ot-hint{color:var(--muted)}
.ot-panel{margin-top:12px;border:1px solid var(--text-primary);border-radius:12px;padding:14px 14px 12px;
  background:var(--surface-1);scroll-margin-top:calc(var(--navh) + 70px)}
.od-head{display:flex;gap:12px;align-items:flex-start}
.ot-av.big{width:52px;height:52px;flex:none;font-size:17px}
.od-name{font-size:17px;font-weight:700}
.od-title{font-size:13px;color:var(--text-secondary);margin-top:1px}
.od-bs{display:flex;flex-wrap:wrap;gap:6px;margin-top:6px;align-items:center}
.od-bs .fx-tag{margin-top:0}
.od-b{font-size:11.5px;padding:2px 8px;border-radius:999px;background:#e8eef7;color:var(--brand-ink);font-weight:600}
.od-b.muted{background:var(--surface-2);color:var(--muted)}
.vs{margin-top:14px}
.vs-h{font-size:12.5px;font-weight:700;color:var(--text-secondary);margin-bottom:6px}
.vs-row{display:flex;gap:4px;flex-wrap:wrap}
.vs-c{position:relative;width:38px;height:30px;border-radius:6px;display:flex;align-items:flex-start;
  justify-content:center;font-size:13px;font-weight:700;color:#fff;padding-top:2px;margin-bottom:16px}
.vs-c em{position:absolute;top:100%;left:0;right:0;text-align:center;font-style:normal;font-size:10.5px;
  color:var(--muted);font-weight:400;margin-top:2px}
.vs-c.for{background:var(--muted-bar)}
.vs-c.none{border:1.5px dashed var(--baseline)}
.vs-leg{display:flex;flex-wrap:wrap;gap:3px 12px;font-size:11.5px;color:var(--muted);margin:4px 0 4px}
.vs-leg i{display:inline-block;width:11px;height:11px;border-radius:3px;vertical-align:-1px;margin-right:4px}
.vs-c.x.haw{background:var(--critical)}.vs-c.x.dov{background:var(--good)}.vs-c.x.oth{background:var(--warning)}
.od-talk{margin-top:6px;border-top:1px solid var(--grid);padding-top:10px}
@media(min-width:760px){
  .ot-brs{grid-template-columns:7fr 5fr;}
  .ot-br.alts{grid-column:1/-1}
  .ot-brs::after{content:"";position:absolute;left:25%;right:25%;top:-10px;
    border-top:1.5px solid var(--baseline)}
}
@media(max-width:759px){
  .ot-brs{margin-left:10px;padding-left:12px;border-left:1.5px solid var(--baseline);margin-top:12px}
  .ot-brs::before{display:none}
  .ot-br::before{content:"";position:absolute;left:-13px;top:22px;width:12px;border-top:1.5px solid var(--baseline)}
  .ot-root{margin:0}
  .ot-nodes{display:grid;grid-template-columns:repeat(4,minmax(0,1fr))}
  .ot-n{width:auto;min-width:0}
  .ot-sn{font-size:11.5px}
  .ot-n{padding:6px 1px 4px}
  .vs-row{display:grid;grid-template-columns:repeat(var(--n),minmax(0,1fr))}
  .vs-c{width:auto}
  .fx-rot th,.fx-rot td{white-space:normal;padding:8px 5px;font-size:13px}
  .fx-rot th.rowhead{font-size:11.5px;line-height:1.4}
}
.fx-rot,.tscroll>table.fx-rot{width:100%}
.cfs{display:grid;gap:8px;margin-top:12px}
@media(min-width:760px){.cfs{grid-template-columns:repeat(3,1fr)}}
.cf{border:1px solid var(--border);border-radius:10px;padding:10px 12px;background:var(--surface-1)}
.cf b{display:block;font-size:20px;color:var(--brand-ink)}
.cf span{font-size:12.5px;color:var(--text-secondary);line-height:1.55}
.fx-rot td,.fx-rot th{text-align:center}
.fx-rot th.rowhead{text-align:left;font-weight:500;font-size:12.5px;color:var(--text-secondary)}
.fx-rot td small{display:block;font-size:11px;color:var(--muted)}
/* SEP 小卡 */
.scs{display:grid;gap:10px;margin-top:14px;grid-template-columns:1fr 1fr}
@media(min-width:760px){.scs{grid-template-columns:repeat(5,1fr)}}
@media(max-width:340px){.scs{grid-template-columns:1fr}}
@media(max-width:759px){.scs .sc:last-child:nth-child(odd){grid-column:1/-1}
  .sc-v{font-size:22px}.sc-x b{font-size:11px}.sc-x span{font-size:9.5px}}
.sc{border:1px solid var(--border);border-radius:12px;padding:11px 12px 8px;background:var(--surface-1)}
.sc-k{font-size:12.5px;font-weight:700;color:var(--text-secondary)}
.sc-v{font-size:26px;font-weight:700;line-height:1.15;margin-top:2px;font-variant-numeric:tabular-nums}
.sc-v small{font-size:14px;margin-left:1px}
.sc-y{font-size:11px;color:var(--muted)}
.sc-chip{display:inline-block;font-size:11.5px;padding:1px 7px;border-radius:6px;margin-top:5px;
  background:var(--surface-2);color:var(--text-secondary);font-weight:600}
.sc-chip.haw{background:#fbe9e9;color:var(--critical)}
.sc-chip.dov{background:#e6f3e6;color:var(--good)}
.sc-plot{position:relative;height:56px;margin-top:10px}
.sc-plot svg{position:absolute;inset:0;width:100%;height:100%}
.sc-dot{position:absolute;width:7px;height:7px;border-radius:50%;background:var(--series-1);
  transform:translate(-50%,-50%);box-shadow:0 0 0 2px var(--surface-1)}
.sc-dot.now{width:10px;height:10px}
.sc-x{display:grid;grid-template-columns:repeat(var(--n),1fr);text-align:center;margin-top:4px}
.sc-x span{font-size:10px;color:var(--muted);line-height:1.3}
.sc-x b{display:block;font-size:11.5px;color:var(--text-primary);font-variant-numeric:tabular-nums}
.sc-leg{display:flex;flex-wrap:wrap;gap:4px 14px;font-size:12px;color:var(--text-secondary);margin:8px 0 10px}
.sc-leg span{display:inline-flex;align-items:center;gap:6px}
.sc-l{display:inline-block;width:16px;border-top:2px solid var(--series-1)}
.sc-l.prev{border-top:2px dashed var(--muted-bar)}

/* ===================================================================
   字級系統（2026-10，使用者：「字體一下大一下小」）
   全站內容區只用 8 級，放在 CSS 最後統一收斂，個別元件不再自訂字級：
     --fs-display 40  頁首主數字（長端 10Y）
     --fs-title   26  結論卡標題（手機 22）
     --fs-num     22  卡片裡的數字（手機 20）
     --fs-h2      17  區塊標題
     --fs-h3      15  區塊內小標
     --fs-body    14  內文、結論句、表格、展開列
     --fs-small   12.5 標籤、註解、圖例、資料來源
     --fs-micro   11  座標軸刻度、徽章、日期格
   字重只用 400（內文）／600（標籤）／700（標題與數字）。
   =================================================================== */
:root,.viz-root{--fs-display:40px;--fs-title:26px;--fs-num:22px;--fs-h2:17px;--fs-h3:15px;
  --fs-body:14px;--fs-small:12.5px;--fs-micro:11px}
@media(max-width:759px){:root,.viz-root{--fs-display:36px;--fs-title:22px;--fs-num:20px}}

/* 頁首主數字與結論卡標題 */
.viz-root:not(#_) .le-big b{font-size:var(--fs-display);font-weight:700}
.viz-root:not(#_) .focus-title,.viz-root:not(#_) .le-hero .focus-title{font-size:var(--fs-title);font-weight:700}
.viz-root:not(#_) .v-main{font-size:var(--fs-title)}

/* 卡片數字：一律同一級 */
.viz-root:not(#_) .stat .s-value,.viz-root:not(#_) .light .l-value,.viz-root:not(#_) .le-tv,.viz-root:not(#_) .le-small b,
.viz-root:not(#_) .au-y,.viz-root:not(#_) .le-sv,.viz-root:not(#_) .le-g b,.viz-root:not(#_) .le-wam b,.viz-root:not(#_) .le-mrow b,
.viz-root:not(#_) .sc-v,.viz-root:not(#_) .ch-val,.viz-root:not(#_) .cf b,.viz-root:not(#_) .kpi .k-value,.viz-root:not(#_) .focus-metric>b,
.viz-root:not(#_) .bk-val,.viz-root:not(#_) .sax-val{font-size:var(--fs-num);font-weight:700;line-height:1.2}
.viz-root:not(#_) .le-tv span,.viz-root:not(#_) .le-sv span,.viz-root:not(#_) .le-chg{font-size:var(--fs-small);font-weight:700}
.viz-root:not(#_) .au-y small,.viz-root:not(#_) .le-sv small,.viz-root:not(#_) .le-wam small,.viz-root:not(#_) .sc-v small{font-size:var(--fs-small);font-weight:400}

/* 標題 */
.viz-root:not(#_) .card h2{font-size:var(--fs-h2)}
.viz-root:not(#_) .card h3,.viz-root:not(#_) .le-h3{font-size:var(--fs-h3);font-weight:700}
.viz-root:not(#_) .viz-h,.viz-root:not(#_) .le-tn,.viz-root:not(#_) .au-h b,.viz-root:not(#_) .le-szh b,.viz-root:not(#_) .od-name{font-size:var(--fs-body);font-weight:700}

/* 內文 */
.viz-root:not(#_) .hint,.viz-root:not(#_) .focus-sub,.viz-root:not(#_) .v-why,.viz-root:not(#_) .f-detail,.viz-root:not(#_) .gloss dd,
.viz-root:not(#_) .gloss dt,.viz-root:not(#_) .teach-body,.viz-root:not(#_) .teach-body p,.viz-root:not(#_) .card li,.viz-root:not(#_) .card p,
.viz-root summary,.viz-root:not(#_) .tline>summary,.viz-root:not(#_) .le-quote,.viz-root:not(#_) .le-up,.viz-root:not(#_) .ev,
.viz-root:not(#_) .br-name,.viz-root:not(#_) .br-val,.viz-root:not(#_) .wf-name,.viz-root:not(#_) .wf-val,.viz-root:not(#_) .warnbox,
.viz-root:not(#_) .card td,.viz-root:not(#_) .card th{font-size:var(--fs-body)}
.viz-root:not(#_) .impact{font-size:var(--fs-body);font-weight:600;line-height:1.6}
.viz-root:not(#_) .impact b{font-weight:700}

/* 標籤與註解 */
.viz-root:not(#_) .stat .s-label,.viz-root:not(#_) .stat .s-note,.viz-root:not(#_) .viz-sub,.viz-root:not(#_) .src,.viz-root:not(#_) .le-tx,
.viz-root:not(#_) .le-tk,.viz-root:not(#_) .le-k,.viz-root:not(#_) .le-sk,.viz-root:not(#_) .le-g span,.viz-root:not(#_) .le-g em,
.viz-root:not(#_) .le-wam span,.viz-root:not(#_) .le-wam em,.viz-root:not(#_) .le-mrow span,.viz-root:not(#_) .le-mrow em,
.viz-root:not(#_) .le-asof,.viz-root:not(#_) .le-szh,.viz-root:not(#_) .le-hsr,.viz-root:not(#_) .le-hsd,.viz-root:not(#_) .cl-leg,
.viz-root:not(#_) .kh-leg,.viz-root:not(#_) .wf-leg,.viz-root:not(#_) .sc-leg,.viz-root:not(#_) .ot-leg,.viz-root:not(#_) .au-kv,
.viz-root:not(#_) .au-h span,.viz-root:not(#_) .sg-h,.viz-root:not(#_) .evs-h,.viz-root:not(#_) .le-qh,.viz-root:not(#_) .teach>summary,
.viz-root:not(#_) .light .l-top,.viz-root:not(#_) .l-state,.viz-root:not(#_) .l-desc,.viz-root:not(#_) .kh-top,.viz-root:not(#_) .kh-vals span,
.viz-root:not(#_) .sig-tier,.viz-root:not(#_) .cf span,.viz-root:not(#_) .ch-lab,.viz-root:not(#_) .ch-note,.viz-root:not(#_) .sc-k,.viz-root:not(#_) .sc-chip,
.viz-root:not(#_) .data-tag,.viz-root:not(#_) .k-sub,.viz-root:not(#_) .k-plain,.viz-root:not(#_) .le-mixk,.viz-root:not(#_) .le-tile .le-badge,
.viz-root:not(#_) .br-note,.viz-root:not(#_) .wf-note,.viz-root:not(#_) .dnote,.viz-root:not(#_) .ev-k,.viz-root:not(#_) .au-v{font-size:var(--fs-small)}
.viz-root:not(#_) .au-kv em,.viz-root:not(#_) .le-g em{font-size:var(--fs-small)}

/* 最小一級 */
.viz-root:not(#_) .cl-tick,.viz-root:not(#_) .cl-x,.viz-root:not(#_) .cat-x,.viz-root:not(#_) .kh-dates span,.viz-root:not(#_) .kh-unit,
.viz-root:not(#_) .gc-lab,.viz-root:not(#_) .gc-mx,.viz-root:not(#_) .gc-mn,.viz-root:not(#_) .lmark,.viz-root:not(#_) .cl-reflab,
.viz-root:not(#_) .le-badge,.viz-root:not(#_) .focus-eyebrow,.viz-root:not(#_) .sc-x span,.viz-root:not(#_) .sc-y,.viz-root:not(#_) .vs-c em,
.viz-root:not(#_) .nl-ticks span,.viz-root:not(#_) .ot-role,.viz-root:not(#_) .au-mix{font-size:var(--fs-micro)}
.viz-root:not(#_) .sc-x b,.viz-root:not(#_) .kh-vals span.last{font-size:var(--fs-small)}

/* 卡中卡：同一種外觀（細框、圓角、內距），不再各自一套 */
.viz-root:not(#_) .le-tile,.viz-root:not(#_) .le-g,.viz-root:not(#_) .le-wam>div,.viz-root:not(#_) .le-slope,.viz-root:not(#_) .le-size,
.viz-root:not(#_) .au,.viz-root:not(#_) .le-hs,.viz-root:not(#_) .le-match,.viz-root:not(#_) .cf,.viz-root:not(#_) .sc,.viz-root:not(#_) .ch-step{
  border-radius:10px;padding:12px 14px}
.viz-root:not(#_) .le-g,.viz-root:not(#_) .le-wam>div,.viz-root:not(#_) .le-slope,.viz-root:not(#_) .le-size,.viz-root:not(#_) .le-hs,.viz-root:not(#_) .cf{
  border:0;background:var(--surface-2)}
.viz-root:not(#_) .viz-block{margin-top:20px}
.viz-root:not(#_) .le-h3{margin-top:24px}

/* 收斂剩下的零星字級 */
.viz-root:not(#_) .focus-eyebrow{font-weight:700}
.viz-root:not(#_) .sg-seg b,.viz-root:not(#_) .le-mixb span{font-size:var(--fs-small);font-weight:700}
.viz-root:not(#_) .logic-step b,.viz-root:not(#_) .tabs>label{font-size:var(--fs-body)}
.viz-root:not(#_) .logic-step span,.viz-root:not(#_) .le-up span,.viz-root:not(#_) .focus-metric>span,.viz-root:not(#_) .focus-metric>small,
.viz-root:not(#_) .tlines-k,.viz-root:not(#_) .l-more>summary,.viz-root:not(#_) .pagenav a{font-size:var(--fs-small)}
.viz-root:not(#_) .br-val small,.viz-root:not(#_) .wf-val small{font-size:var(--fs-micro);font-weight:400}
.viz-root:not(#_) .teach>summary,.viz-root:not(#_) .f-more>summary,.viz-root:not(#_) .card th{font-weight:600}
.viz-root:not(#_) .kh-vals span{font-weight:400}.viz-root:not(#_) .kh-vals span.last{font-weight:700}
.viz-root:not(#_) .l-value span{font-size:var(--fs-small)}

/* 全站其他頁的零星字級（2026-10 盤點後收斂） */
.viz-root:not(#_) .dnew,.viz-root:not(#_) .dold,.viz-root:not(#_) .q-en,.viz-root:not(#_) .pline,
.viz-root:not(#_) .dlabel,.viz-root:not(#_) .dval,.viz-root:not(#_) .sig-sum,.viz-root:not(#_) .sig-sum span,
.viz-root:not(#_) .hn-main,.viz-root:not(#_) .hn-main b,.viz-root:not(#_) .home-module-summary,
.viz-root:not(#_) .home-change p,.viz-root:not(#_) .us-name,.viz-root:not(#_) .ub-name,.viz-root:not(#_) .sname,
.viz-root:not(#_) .tname,.viz-root:not(#_) .tdist,.viz-root:not(#_) .poslist dt,.viz-root:not(#_) .poslist dd,
.viz-root:not(#_) .banner,.viz-root:not(#_) .banner summary,.viz-root:not(#_) .banner-body,.viz-root:not(#_) .flow-values,
.viz-root:not(#_) .fs-text,.viz-root:not(#_) .brief-new,.viz-root:not(#_) .home-inline-link,
.viz-root:not(#_) .home-primary-link,.viz-root:not(#_) .sp-i a,.viz-root:not(#_) .rtab,
.viz-root:not(#_) .fs-pick-panel label,.viz-root:not(#_) .home-verdict b,.viz-root:not(#_) .sig-sum b{font-size:var(--fs-body)}
.viz-root:not(#_) .sig-sum b{font-weight:700}
.viz-root:not(#_) .k-chip,.viz-root:not(#_) .q-lv,.viz-root:not(#_) .dlabel2,.viz-root:not(#_) .f-tag,
.viz-root:not(#_) .l-link,.viz-root:not(#_) td small,.viz-root:not(#_) .k-label,.viz-root:not(#_) .k-label-zh,
.viz-root:not(#_) .us-yoy,.viz-root:not(#_) .us-yoy b,.viz-root:not(#_) .dlegend span,.viz-root:not(#_) .hn-src,
.viz-root:not(#_) .hn-date,.viz-root:not(#_) .wx-w,.viz-root:not(#_) .fx-dir,.viz-root:not(#_) .vs-leg span,
.viz-root:not(#_) .fs-chip span,.viz-root:not(#_) .home-status,.viz-root:not(#_) .sgrid .axis,.viz-root:not(#_) .tnow,
.viz-root:not(#_) .wx-src,.viz-root:not(#_) .home-zone-head p,.viz-root:not(#_) .nb,.viz-root:not(#_) .lxaxis span,
.viz-root:not(#_) .fx-v small,.viz-root:not(#_) .ot-bw,.viz-root:not(#_) .rcmp-l,.viz-root:not(#_) .home-trigger-detail span,
.viz-root:not(#_) .hn-group,.viz-root:not(#_) .home-next-foot,.viz-root:not(#_) .foot-fold-body span,
.viz-root:not(#_) .sp-d,.viz-root:not(#_) .fx-tag,.viz-root:not(#_) .od-b,.viz-root:not(#_) .fs-pick-btn,
.viz-root:not(#_) .fs-brand-name,.viz-root:not(#_) .home-brief-label,.viz-root:not(#_) .home-cell-now small,
.viz-root:not(#_) .home-cell-next small,.viz-root:not(#_) .home-trigger-unlock,.viz-root:not(#_) .home-module-toggle,
.viz-root:not(#_) .ot-sn,.viz-root:not(#_) .k-chips span,.viz-root:not(#_) .focus-metric span,
.viz-root:not(#_) .focus-metric small,.viz-root:not(#_) .ub-name span{font-size:var(--fs-small)}
.viz-root:not(#_) .hn-imp,.viz-root:not(#_) .sp-k,.viz-root:not(#_) .glab,.viz-root:not(#_) .fs-note,
.viz-root:not(#_) .home-cell-now span,.viz-root:not(#_) .home-cell-next span,.viz-root:not(#_) .home-trigger-unlock span,
.viz-root:not(#_) .tadj,.viz-root:not(#_) .tdir,.viz-root:not(#_) .fs-when,.viz-root:not(#_) .home-tag{font-size:var(--fs-micro)}
.viz-root:not(#_) .f-head{font-size:var(--fs-h3)}
.viz-root:not(#_) .ld-v{font-size:var(--fs-h3);font-weight:700}
.viz-root:not(#_) .ld-v.last,.viz-root:not(#_) .fs-chip b{font-size:var(--fs-num)}
.viz-root:not(#_) .ub-head b,.viz-root:not(#_) .pagehead h1{font-size:var(--fs-title)}
.viz-root:not(#_) h2{font-size:var(--fs-h2)}
@media(max-width:759px){.viz-root:not(#_) .ot-sn{font-size:var(--fs-micro)}}

/* 長端：首卡事件格、發行規模表（2026-10 第二輪） */
.ev-grid{display:grid;gap:4px 18px}
@media(min-width:760px){.ev-grid{grid-template-columns:1fr 1fr}}
.ev-t{min-width:0}
.le-sizes{display:block!important;margin-top:12px}
.sz-head,.sz-row{display:grid;grid-template-columns:64px 1fr 1fr 2fr;gap:10px;align-items:center;padding:8px 2px}
.sz-head{border-bottom:1px solid var(--grid)}
.sz-head span{font-size:var(--fs-small);color:var(--muted)}
.sz-row{border-bottom:1px solid var(--grid)}
.sz-row b,.sz-v,.sz-c{font-size:var(--fs-body)}
.sz-v{font-weight:700;font-variant-numeric:tabular-nums}
.sz-c{color:var(--text-secondary)}
.sz-m{display:flex;align-items:flex-end;gap:3px;height:26px;max-width:220px}
.sz-m i{flex:1;background:var(--muted-bar);border-radius:2px 2px 0 0;min-height:2px}
.sz-m i:last-child{background:var(--series-1)}
@media(max-width:759px){.sz-head,.sz-row{grid-template-columns:48px 1fr 1fr 1.4fr;gap:8px}}

/* ===================================================================
   情境合成頁（2026-10 改版，手機優先）
   =================================================================== */
.sx-h3{font-size:var(--fs-h3);font-weight:700;margin:22px 0 10px}
.sx-note{font-size:var(--fs-small);color:var(--muted);line-height:1.6;margin-top:8px}
/* 首卡：本站判讀 vs 期貨定價 */
.sx-dv{display:grid;grid-template-columns:1fr auto 1fr;gap:8px;align-items:stretch;margin-top:12px}
.sx-dv-c{padding:11px 13px;border-radius:10px;background:var(--surface-2);min-width:0;display:flex;flex-direction:column;gap:2px}
.sx-dv-c span{font-size:var(--fs-small);color:var(--muted)}
.sx-dv-c b{font-size:var(--fs-h2);font-weight:700}
.sx-dv-c b.hawkish{color:var(--serious)}.sx-dv-c b.dovish{color:var(--series-1)}
.sx-dv-c small{font-size:var(--fs-small);color:var(--text-secondary);line-height:1.4}
.sx-dv-vs{align-self:center;font-size:var(--fs-small);font-weight:700;padding:4px 9px;border-radius:999px;white-space:nowrap}
.sx-dv.agree .sx-dv-vs{background:var(--surface-2);color:var(--good);border:1px solid var(--good)}
.sx-dv.split .sx-dv-vs{background:var(--tint-haw);color:var(--critical);border:1px solid var(--critical)}
.sx-dv.na .sx-dv-vs{color:var(--muted)}
/* 九宮格上方：兩軸準則＋重心 */
.sx-axes{display:grid;gap:8px;margin:4px 0 12px}
@media(min-width:760px){.sx-axes{grid-template-columns:1fr 1fr}}
.sx-ax{display:grid;grid-template-columns:auto auto 1fr;gap:4px 10px;align-items:baseline;
  padding:10px 12px;border-radius:10px;background:var(--surface-2)}
.sx-ax-k{font-size:var(--fs-small);color:var(--muted);font-weight:600}
.sx-ax-v{font-size:var(--fs-h2);font-weight:700}
.sx-ax-t{font-size:var(--fs-small);color:var(--text-secondary);line-height:1.55}
.sx-ax-t b{color:var(--text-primary)}
@media(max-width:759px){.sx-ax{grid-template-columns:auto 1fr}.sx-ax-t{grid-column:1/-1}}
.sx-rg{display:flex;flex-wrap:wrap;align-items:center;gap:6px 8px;margin:0 0 12px}
.sx-rg-k{font-size:var(--fs-small);color:var(--muted)}
.sx-rg b{font-size:var(--fs-body);font-weight:700}
.sx-ev{font-size:var(--fs-small);color:var(--text-secondary);background:var(--surface-2);
  border:1px solid var(--border);border-radius:999px;padding:2px 9px}
/* 相鄰格：實線框；手機上非相鄰格降成淡色 */
.scell.adj{border:1px solid var(--text-secondary)}
@media(min-width:760px){.scell.conflict{padding-right:14px}}
@media(max-width:759px){.scell{padding:10px 6px}}
.scell.conflict::after{top:3px;right:4px}
.sx-lg{margin-top:12px!important;line-height:2}
.sx-lg-adj{display:inline-block;border:1px solid var(--text-secondary);border-radius:4px;padding:0 5px;white-space:nowrap}
@media(max-width:759px){
  .scell.far{opacity:.42}
  .scell.far .sname{font-weight:600}
  .scell.far .sn-qual{display:none}
}
/* 格位軌跡：每月一張 3×3 小格 */
.sx-trail-h{display:flex;flex-wrap:wrap;gap:4px 10px;align-items:baseline}
.sx-trail-h b{font-size:var(--fs-body)}
.sx-trail-h span{font-size:var(--fs-small);color:var(--text-secondary)}
.sx-tis{display:flex;gap:10px;margin-top:10px;flex-wrap:wrap}
.sx-ti{display:flex;flex-direction:column;align-items:center;gap:4px}
.sx-ti span{font-size:var(--fs-micro);color:var(--muted)}
.sx-ti.now span{color:var(--text-primary);font-weight:700}
.sx-tg{display:grid;grid-template-columns:repeat(3,9px);gap:2px;padding:3px;border-radius:5px;background:var(--surface-1)}
.sx-tg i{width:9px;height:9px;border-radius:2px;background:var(--grid)}
.sx-tg i.f{background:var(--text-secondary)}
.sx-tg i.f.hawkish{background:var(--serious)}.sx-tg i.f.dovish{background:var(--series-1)}
.sx-tg.now{box-shadow:0 0 0 2px var(--text-primary)}
@media(max-width:400px){.sx-tis{gap:7px}.sx-tg{grid-template-columns:repeat(3,8px)}.sx-tg i{width:8px;height:8px}}
/* 主要驅動因素 */
.sx-dcs{display:grid;gap:10px;margin-top:6px}
@media(min-width:760px){.sx-dcs{grid-template-columns:1fr 1fr}}
.sx-dc{display:flex;flex-direction:column;gap:6px;padding:12px 14px;border-radius:10px;
  background:var(--surface-2);border-left:3px solid var(--muted-bar);color:inherit;text-decoration:none}
.sx-dc.hawkish{border-left-color:var(--serious)}.sx-dc.dovish{border-left-color:var(--series-1)}
.sx-dc:hover{background:var(--surface-1);box-shadow:0 0 0 1px var(--border) inset}
.sx-dc-k{font-size:var(--fs-small);color:var(--muted);display:flex;align-items:center;gap:6px}
.sx-dc-t{font-size:var(--fs-body);font-weight:700;line-height:1.5}
.sx-dc-f{font-size:var(--fs-small);color:var(--text-secondary);display:flex;gap:8px;align-items:center}
.sx-lean{font-style:normal;font-weight:700}
.sx-lean.hawkish{color:var(--serious)}.sx-lean.dovish{color:var(--series-1)}.sx-lean.neutral{color:var(--muted)}
.sx-sev{font-style:normal;font-size:var(--fs-micro);font-weight:700;padding:0 5px;border-radius:4px;border:1px solid}
.sx-sev.alert{color:var(--critical)}.sx-sev.watch{color:var(--warning)}
/* 情境轉換門檻：距離條 */
.sx-tg-h{font-size:var(--fs-small);font-weight:700;color:var(--muted);margin:14px 0 6px}
.sx-tr{padding:10px 0;border-bottom:1px solid var(--grid)}
.sx-tr-h{display:flex;flex-wrap:wrap;align-items:center;gap:4px 6px}
.sx-tr-h b{font-size:var(--fs-body);font-weight:700}
.sx-tr-d{margin-left:auto;font-size:var(--fs-body);font-weight:700;font-variant-numeric:tabular-nums}
.sx-tr-bar{height:6px;border-radius:3px;background:var(--grid);margin:8px 0 6px;overflow:hidden}
.sx-tr-bar i{display:block;height:100%;border-radius:3px;background:var(--series-1)}
.sx-tr.far .sx-tr-bar i{background:var(--muted-bar)}
.sx-tr.met .sx-tr-bar i{background:var(--critical)}
.sx-tr-n{font-size:var(--fs-small);color:var(--text-secondary)}
.sx-tr .tadj,.sx-tr .tdir,.sx-tr .tbind{font-size:var(--fs-micro);font-weight:700;border:1px solid;border-radius:4px;padding:0 5px;white-space:nowrap}
.sx-tr .tadj{color:var(--series-1)}.sx-tr .tdir{color:var(--good)}.sx-tr .tbind{color:var(--warning)}
/* 下一個數據 */
.sx-nxs{display:grid;gap:8px}
@media(min-width:760px){.sx-nxs{grid-template-columns:1fr 1fr}}
.sx-nx{display:grid;grid-template-columns:auto 1fr;gap:10px;align-items:start;padding:10px 12px;border-radius:10px;background:var(--surface-2)}
.sx-nx-d{font-size:var(--fs-body);font-weight:700;white-space:nowrap;font-variant-numeric:tabular-nums}
.sx-nx-b{display:flex;flex-wrap:wrap;gap:2px 8px;align-items:baseline;min-width:0}
.sx-nx-b b{font-size:var(--fs-body)}
.sx-nx-a{font-size:var(--fs-micro);font-weight:700;color:var(--muted);border:1px solid var(--border);border-radius:4px;padding:0 5px}
.sx-nx-b small{flex-basis:100%;font-size:var(--fs-small);color:var(--text-secondary);line-height:1.5}
/* 固定收益對照表：桌機四欄、手機兩列卡片 */
.sx-pos{margin-top:8px}
.sx-ph,.sx-pr{display:grid;grid-template-columns:minmax(0,1.3fr) minmax(0,1fr) minmax(0,1fr) 64px;gap:10px;align-items:center}
.sx-ph{padding:0 2px 8px;border-bottom:1px solid var(--grid)}
.sx-ph span{font-size:var(--fs-small);color:var(--muted)}
.sx-pr{padding:10px 2px;border-bottom:1px solid var(--grid)}
.sx-pk b{display:block;font-size:var(--fs-body)}
.sx-pk small{font-size:var(--fs-small);color:var(--muted)}
.sx-pe,.sx-pa{font-size:var(--fs-body);font-weight:600}
.sx-pe em,.sx-pa em{display:none;font-style:normal;font-size:var(--fs-micro);color:var(--muted);font-weight:600}
.sx-pa small{margin-left:6px;font-size:var(--fs-small);font-weight:700;color:var(--text-secondary);font-variant-numeric:tabular-nums}
.sx-m{display:inline-block;font-size:var(--fs-small);font-weight:700;padding:1px 8px;border-radius:999px;white-space:nowrap}
.sx-m.same{color:var(--good);background:var(--surface-2)}
.sx-m.off{color:var(--warning);background:var(--surface-2)}
.sx-m.opp{color:#fff;background:var(--critical)}
.sx-m.na{color:var(--muted)}
.sx-pr.opp{background:var(--tint-haw)}
@media(max-width:759px){
  .sx-ph{display:none}
  .sx-pr{grid-template-columns:1fr 1fr;grid-template-areas:"k m" "e a";gap:6px 10px;padding:12px 10px;
    border:0;border-radius:10px;background:var(--surface-2);margin-bottom:8px}
  .sx-pr.opp{background:var(--tint-haw)}
  .sx-pk{grid-area:k}.sx-pm{grid-area:m;justify-self:end}.sx-pe{grid-area:e}.sx-pa{grid-area:a}
  .sx-pe em,.sx-pa em{display:block}
}
.sx-pos-line{font-size:var(--fs-body);line-height:1.65;margin-top:12px;color:var(--text-secondary)}
.sx-pos-line b{color:var(--critical)}
/* 存續期間試算 */
.sx-dus{display:grid;grid-template-columns:1fr 1fr;gap:8px}
@media(min-width:760px){.sx-dus{grid-template-columns:repeat(4,1fr)}}
.sx-du{padding:12px 14px;border-radius:10px;background:var(--surface-2);display:flex;flex-direction:column;gap:6px;min-width:0}
.sx-du-h{display:flex;justify-content:space-between;align-items:baseline;gap:6px}
.sx-du-h b{font-size:var(--fs-body)}
.sx-du-h span{font-size:var(--fs-small);color:var(--muted)}
.sx-du-v{font-size:var(--fs-num);font-weight:700;font-variant-numeric:tabular-nums;line-height:1.2}
.sx-du-v.dn{color:var(--critical)}.sx-du-v.up{color:var(--good)}
.sx-du-v small{display:block;font-size:var(--fs-small);font-weight:400;color:var(--text-secondary);margin-top:2px}
.sx-du-s{display:flex;flex-direction:column;gap:1px;border-top:1px solid var(--grid);padding-top:6px}
.sx-du-s span{font-size:var(--fs-small);color:var(--muted);display:flex;justify-content:space-between}
.sx-du-s b{color:var(--text-primary);font-variant-numeric:tabular-nums}
/* 期貨路徑 */
.sx-stats{margin:14px 0 6px}
.sx-fp{display:grid;grid-template-columns:auto 1fr;gap:6px;margin-top:16px}
.sx-fp-y{display:flex;flex-direction:column;justify-content:space-between;height:150px;font-size:var(--fs-micro);color:var(--muted);text-align:right}
.sx-fp-p{position:relative;display:flex;gap:3px;height:150px;border-bottom:1px solid var(--text-secondary)}
.sx-fp-c{position:relative;flex:1 1 0;min-width:0}
.sx-fp-c:hover{background:var(--surface-2)}
.sx-fp-b{position:absolute;bottom:0;left:10%;right:10%;border-radius:3px 3px 0 0;background:var(--neg);opacity:.55}
.sx-fp-b.dn{background:var(--pos)}
.sx-fp-c.on .sx-fp-b{opacity:1}
.sx-fp-c.thin .sx-fp-b{opacity:.28;background-image:repeating-linear-gradient(135deg,transparent 0 3px,rgba(255,255,255,.6) 3px 5px)}
.sx-fp-c.thin.on .sx-fp-b{opacity:.6}
.sx-fp-b em{position:absolute;bottom:calc(100% + 3px);left:50%;transform:translateX(-50%);font-style:normal;
  font-size:var(--fs-micro);font-weight:700;color:var(--text-primary);white-space:nowrap;font-variant-numeric:tabular-nums}
.sx-fp-dot{position:absolute;left:-2px;right:-2px;height:0;border-top:2px dashed var(--text-primary);opacity:.75}
.sx-fp-x{position:absolute;top:calc(100% + 4px);left:50%;transform:translateX(-50%);font-size:var(--fs-micro);color:var(--muted);white-space:nowrap}
.sx-fp + .cl-leg{margin-top:32px}
.sx-lg-dot{display:inline-block;width:16px;border-top:2px dashed var(--text-primary)}
.sx-lg-thin{display:inline-block;width:12px;height:10px;border-radius:2px;background:var(--neg);opacity:.28}
@media(max-width:400px){.sx-fp-p{gap:2px}.sx-fp-b em{font-size:10px}}
/* 九宮格第二版：單一強調色、門檻寫進欄列標題 */
.sx-now{font-size:var(--fs-small);color:var(--muted);margin:2px 0 12px}
.sx-now b{color:var(--text-primary);font-size:var(--fs-body)}
.sx-tabs{display:block}
.sx-tabs-k{font-size:var(--fs-small);color:var(--muted);margin-right:6px}
.viz-root:not(#_) .sx-tabs .rtab{font-size:var(--fs-small);font-weight:600;padding:4px 10px;border-radius:999px;
  margin:0 2px 0 0;background:transparent;border:1px solid var(--border);color:var(--text-secondary)}
.viz-root:not(#_) .sx-tabs .rtab-in:checked + .rtab{background:var(--text-primary);border-color:var(--text-primary);color:var(--surface-1)}
.sx-tabs .rt-now{display:none}
.sx-tabs .rpanels{margin-top:14px}
.sx-tabs .rt-hypo{margin:0 0 10px;font-size:var(--fs-small)}
.sx-g{display:grid;grid-template-columns:56px repeat(3,minmax(0,1fr));gap:6px}
.sx-gk{position:relative;border-bottom:1px solid var(--grid)}
.sx-gk span{position:absolute;font-size:var(--fs-micro);color:var(--muted)}
.sx-gk span:first-child{left:0;bottom:3px}.sx-gk span:last-child{right:4px;top:0}
.sx-gh,.sx-gr{display:flex;flex-direction:column;justify-content:center;color:var(--muted);line-height:1.3}
.sx-gh{align-items:center;padding:0 0 4px;border-bottom:1px solid var(--grid)}
.sx-gr{align-items:flex-start;padding-left:2px}
.sx-gh b,.sx-gr b{font-size:var(--fs-body);font-weight:700}
.sx-gh small,.sx-gr small{font-size:var(--fs-micro);font-variant-numeric:tabular-nums;white-space:nowrap;letter-spacing:-.2px}
.sx-gh.cur b,.sx-gr.cur b{color:var(--text-primary)}
.sx-gx{min-height:64px;border-radius:10px;padding:10px;display:flex;flex-direction:column;justify-content:center;gap:2px;min-width:0}
.sx-gn{font-size:var(--fs-body);font-weight:700;line-height:1.35}
.sx-gq{font-size:var(--fs-micro);line-height:1.3}
.sx-gt{font-size:var(--fs-micro);font-weight:600;margin-top:4px;opacity:.8}
.sx-gx.far{background:var(--surface-2);color:var(--muted)}
.sx-gx.far .sx-gn{font-weight:600}
.sx-gx.adj{background:var(--surface-1);border:1px solid var(--muted-bar);color:var(--text-primary)}
.sx-gx.cur{background:var(--brand-navy);color:#fff}
.sx-g{max-width:760px}
@media(min-width:760px){.sx-g{grid-template-columns:72px repeat(3,minmax(0,1fr));gap:8px}.sx-gx{min-height:78px;padding:12px 14px}}
@media(max-width:400px){.sx-g{grid-template-columns:52px repeat(3,minmax(0,1fr));gap:5px}.sx-gx{padding:9px 7px}
  .sx-gh small,.sx-gr small{font-size:10px}}
.sx-glg{display:flex;align-items:center;gap:6px;margin-top:10px}
.sx-glg i{display:inline-block;width:12px;height:12px;border-radius:3px}
.sx-glg-cur{background:var(--brand-navy)}
.sx-glg-adj{border:1px solid var(--muted-bar);background:var(--surface-1);margin-left:8px}
.sx-trail .sx-tis{margin:4px 0 0}
.sx-tg i.f{background:var(--brand-navy)}

/* KPI 卡四格對齊（2026-10，使用者：「近 5 期與比較基準四個要對齊」）
   桌機：同一列的卡共用四條列軌（subgrid），每一格取該列最高者。
   展開某張卡的「近 5 期」只會撐高第四軌，其他卡的收合列仍貼在軌頂、位置不動。 */
@media(min-width:760px){
  .grid.inner:has(>.kpi){grid-auto-rows:auto;align-items:stretch}
  .grid.inner>.kpi{display:grid;grid-row:span 4;grid-template-rows:subgrid;row-gap:0;align-content:start}
  .grid.inner>.kpi>div{align-self:start;min-width:0}
  .grid.inner>.kpi .k-label,.grid.inner>.kpi .k-chips,.grid.inner>.kpi .k-plain{min-height:0}
  .grid.inner>.kpi>.k-s1{align-self:stretch;display:flex;flex-direction:column}
  .grid.inner>.kpi .k-s1 .k-value{margin-top:auto;padding-top:5px}
}

/* ===================================================================
   總覽第二版（2026-10）：藏青＋橘的品牌語言，閱讀舒適度優先
   =================================================================== */
.hm .focus-strip{border-top-color:var(--brand-ink)}
.hm-num{display:inline-block;font-size:var(--fs-small);font-weight:700;color:var(--brand-orange);
  letter-spacing:.08em;margin-right:8px;font-variant-numeric:tabular-nums}
/* 主卡 */
.viz-root:not(#_) .hm-hero{padding:0;border:1px solid var(--border);border-top:0;border-radius:16px;overflow:hidden}
.hm-band{background:var(--brand-navy);color:#fff;padding:22px 20px 22px;position:relative}
.hm-band::after{content:"";position:absolute;left:20px;bottom:0;width:56px;height:3px;background:var(--brand-orange)}
.hm-kick{font-size:var(--fs-small);font-weight:600;color:rgba(255,255,255,.72)}
.viz-root:not(#_) .hm-band h2{font-size:var(--fs-title);font-weight:700;color:#fff;margin:8px 0 0;line-height:1.3;letter-spacing:0}
.hm-verdict{display:inline-flex;align-items:center;gap:10px;margin-top:12px;padding:5px 12px;border-radius:999px;
  border:1px solid var(--brand-orange)}
.hm-verdict b{font-size:var(--fs-body);color:#fff}
.hm-verdict span{font-size:var(--fs-small);font-weight:700;color:var(--brand-orange)}
.hm-key{font-size:16px;line-height:1.75;color:#fff;margin:16px 0 0;max-width:40em}
.hm-layer{padding:20px 20px 22px}
.hm-lh{font-size:var(--fs-small);font-weight:700;color:var(--muted);letter-spacing:.04em;margin:0 0 10px}
.hm-lh+.hm-brs{margin-top:0}
.hm-brs{display:grid;gap:0}
.hm-br{display:grid;grid-template-columns:76px 1fr;gap:12px;padding:12px 0;border-top:1px solid var(--grid)}
.hm-br:first-child{border-top:0;padding-top:2px}
.hm-br b{font-size:var(--fs-body);font-weight:700;color:var(--brand-ink)}
.viz-root:not(#_) .hm-br p{font-size:15px;line-height:1.8;margin:0;color:var(--text-primary);max-width:44em}
@media(max-width:759px){.hm-br{grid-template-columns:1fr;gap:2px}}
.hm-new{margin:6px 0 22px;border-radius:10px;background:var(--surface-2);padding:0 14px}
.hm-new>summary{list-style:none;cursor:pointer;padding:11px 0;font-size:var(--fs-small);color:var(--text-secondary);line-height:1.6}
.hm-new>summary::-webkit-details-marker{display:none}
.hm-new>summary span{font-weight:700;color:var(--brand-ink);margin-right:8px}
.hm-new>summary em{font-style:normal;color:var(--brand-orange);font-weight:600;margin-left:6px;white-space:nowrap}
.hm-new[open]{padding-bottom:12px}
.hm-new-i{display:inline-block;font-size:var(--fs-small);color:var(--text-secondary);background:var(--surface-1);
  border:1px solid var(--border);border-radius:999px;padding:2px 10px;margin:0 6px 6px 0}
/* 四大模組（主卡第二層） */
.viz-root:not(#_) .hm-hero .home-status-rail{display:block;border:0;margin:0;border-radius:0;overflow:visible}
.hm-mods{display:grid;grid-template-columns:1fr 1fr;gap:10px}
@media(min-width:760px){.hm-mods{grid-template-columns:repeat(4,1fr)}}
.hm-mod{display:flex;flex-direction:column;gap:8px;padding:14px;border-radius:12px;background:var(--surface-2);
  color:inherit;text-decoration:none;border:1px solid transparent}
.hm-mod:hover{border-color:var(--brand-ink);background:var(--surface-1)}
.hm-mod-h{display:flex;flex-direction:column;gap:3px}
.hm-mod-h b{font-size:var(--fs-body);font-weight:700;color:var(--brand-ink)}
.hm-st{font-size:var(--fs-small);color:var(--text-secondary);display:inline-flex;align-items:center;gap:6px}
.hm-dot{display:inline-block;width:8px;height:8px;border-radius:50%;background:var(--muted-bar);flex:none}
.hm-dot.haw{background:var(--serious)}.hm-dot.dov{background:var(--series-1)}
.hm-mod-kv{display:grid;gap:4px;border-top:1px solid var(--grid);padding-top:8px}
.hm-mod-kv div{display:flex;justify-content:space-between;gap:8px;align-items:baseline}
.hm-mod-kv span{font-size:var(--fs-small);color:var(--muted)}
.hm-mod-kv b{font-size:var(--fs-body);font-weight:700;font-variant-numeric:tabular-nums;text-align:right}
@media(max-width:759px){.hm-mod{padding:12px}.hm-mod-kv div{flex-direction:column;align-items:flex-start;gap:0}
  .hm-mod-kv b{text-align:left}}
.hm-mod-go{font-size:var(--fs-small);font-weight:600;color:var(--brand-orange);margin-top:auto}
/* 區塊標題 */
.hm-zone{padding:22px 20px}
.hm-zh{display:flex;justify-content:space-between;align-items:baseline;gap:12px;margin-bottom:16px}
.hm-zh h2{display:inline;font-size:var(--fs-h2);font-weight:700;color:var(--brand-ink);margin:0}
.hm-zh p{font-size:var(--fs-small);color:var(--muted);margin:0;text-align:right}
.hm-link{font-size:var(--fs-small);font-weight:700;color:var(--brand-orange);text-decoration:none;white-space:nowrap}
/* 九宮格小圖＋路徑 */
.hm-gwrap{display:grid;gap:18px}
@media(min-width:760px){.hm-gwrap{grid-template-columns:minmax(0,420px) 1fr;align-items:center;gap:28px}}
.hm-g{display:grid;grid-template-columns:30px repeat(3,minmax(0,1fr));gap:4px}
.hm-gcap{font-size:var(--fs-micro);color:var(--muted);margin-bottom:6px}
.viz-root:not(#_) .hm-hero .home-status-rail>div{background:transparent;border:0;padding:0}
.hm-gh,.hm-gr{font-size:var(--fs-micro);color:var(--muted);text-align:center;align-self:center}
.hm-gc{font-size:12px;font-weight:600;color:var(--muted);background:var(--surface-2);border-radius:7px;
  padding:9px 4px;text-align:center;line-height:1.3;min-height:20px}
.hm-gc.cur{background:var(--brand-navy);color:#fff}
.hm-gc.nxt{background:var(--surface-1);color:var(--text-primary);box-shadow:0 0 0 1.5px var(--brand-orange) inset}
.hm-path{display:grid;gap:10px}
.hm-step{padding:12px 14px;border-radius:12px;background:var(--surface-2);display:flex;flex-direction:column;gap:3px}
.hm-step span{font-size:var(--fs-small);color:var(--muted)}
.hm-step b{font-size:var(--fs-h2);font-weight:700;color:var(--brand-ink)}
.hm-step:first-child{border-left:4px solid var(--brand-navy)}
.hm-step.nxt{background:var(--surface-1);border:1px solid var(--border);border-left:4px solid var(--brand-orange)}
.hm-step small{font-size:var(--fs-small);color:var(--text-secondary);line-height:1.6}
.hm-bar{height:6px;border-radius:3px;background:var(--grid);margin-top:6px;overflow:hidden}
.hm-bar i{display:block;height:100%;background:var(--brand-orange);border-radius:3px}
.hm-unlock{font-size:var(--fs-small);color:var(--text-secondary)}
.hm-unlock span{font-weight:700;color:var(--muted);margin-right:8px}
/* 本期變化 */
.hm-ch{display:grid;grid-template-columns:14px 1fr;gap:6px;padding:12px 0;border-top:1px solid var(--grid)}
.hm-ch:first-child{border-top:0;padding-top:0}
.hm-ch .hm-dot{margin-top:7px}
.hm-ch-h{display:flex;flex-wrap:wrap;align-items:baseline;gap:4px 10px}
.hm-ch-h b{font-size:var(--fs-body);color:var(--brand-ink)}
.hm-ch-h span{font-size:var(--fs-small);color:var(--muted)}
.hm-ch-h em{font-style:normal;font-size:var(--fs-body);font-weight:600;color:var(--text-primary)}
.hm-ch ul{margin:6px 0 0;padding-left:18px}
.hm-more{list-style:none;margin-left:-18px}
.viz-root:not(#_) .hm-more details,.viz-root:not(#_) .hm-more summary{border:0;padding:4px 0;margin:0;background:none;list-style:none}
.hm-more summary::-webkit-details-marker{display:none}
.hm-more summary{cursor:pointer;font-size:var(--fs-small);color:var(--brand-orange);font-weight:600}
.viz-root:not(#_) .hm-ch li{font-size:var(--fs-small);line-height:1.7;color:var(--text-secondary)}
/* 接下來看什麼 */
.hm-hi{display:grid;grid-template-columns:120px 1fr;gap:14px;padding:14px 16px;border-radius:12px;
  background:var(--surface-1);border:1px solid var(--border);border-left:4px solid var(--brand-orange);margin-bottom:10px}
.hm-hi-d b{display:block;white-space:nowrap;font-size:var(--fs-h2);font-weight:700;color:var(--brand-ink);font-variant-numeric:tabular-nums}
.hm-hi-d span{font-size:var(--fs-small);color:var(--muted)}
.hm-hi-b b{font-size:var(--fs-h3);font-weight:700}
.hm-hi-b em{font-style:normal;font-size:var(--fs-micro);font-weight:700;color:#fff;background:var(--brand-orange);
  border-radius:4px;padding:1px 6px;margin-left:8px;vertical-align:2px}
.viz-root:not(#_) .hm-hi-b p{font-size:var(--fs-body);line-height:1.7;margin:4px 0 0;color:var(--text-secondary)}
.hm-mids-h{font-size:var(--fs-small);font-weight:700;color:var(--muted);margin:16px 0 4px}
.hm-mid{display:grid;grid-template-columns:96px 1fr auto;gap:12px;align-items:baseline;padding:9px 0;border-top:1px solid var(--grid)}
.hm-mid-d{font-size:var(--fs-body);font-weight:600;font-variant-numeric:tabular-nums}
.hm-mid b{font-size:var(--fs-body);font-weight:600}
.hm-mid-t{font-size:var(--fs-small);color:var(--muted);white-space:nowrap}
@media(max-width:759px){.hm-hi{grid-template-columns:1fr;gap:6px}.hm-hi-d b{display:inline;margin-right:8px}
  .hm-mid{grid-template-columns:auto 1fr;gap:2px 12px}.hm-mid-t{grid-column:2}}
.hm-foot{font-size:var(--fs-small);color:var(--muted);margin:14px 0 0;line-height:1.6}
/* 品牌收尾 */
.hm-sign{display:grid;grid-template-columns:auto 1fr;gap:4px 14px;align-items:center;margin:28px 0 8px;padding:18px 20px;
  border-radius:14px;background:var(--brand-navy);color:#fff}
.hm-sign-gg{grid-row:span 3;font-size:30px!important;font-size:26px;font-weight:800;letter-spacing:-.04em;color:#fff;
  border-bottom:3px solid var(--brand-orange);line-height:1.1}
.hm-sign b{display:block;font-size:var(--fs-body);letter-spacing:.06em}
.hm-sign span{font-size:var(--fs-small);color:rgba(255,255,255,.75)}
.hm-sign small{grid-column:2;font-size:var(--fs-micro);color:rgba(255,255,255,.6);line-height:1.6}
/* 總覽第三版：白底＋細線分隔（取代一格一格的灰底） */
.hm .focus-strip .fs-chips{gap:0;border:1px solid var(--border);border-radius:12px;overflow:hidden;background:var(--surface-1)}
.hm .focus-strip .fs-chip{background:transparent;border-radius:0;border-right:1px solid var(--grid);border-bottom:1px solid var(--grid)}
.hm .focus-strip .fs-chips>.fs-chip:not(.fs-off):nth-child(2n of :not(.fs-off)){border-right:0}
.hm .focus-strip .fs-chips>.fs-chip:not(.fs-off):nth-child(n+3 of :not(.fs-off)){border-bottom:0}
.hm .fs-news .fs-body{background:transparent;border-left:3px solid var(--brand-navy);border-radius:0;padding:4px 0 4px 16px}
.hm .fs-news .f-more{margin-left:19px}
.hm .fs-tag{background:transparent;border:1px solid var(--brand-navy);color:var(--brand-ink)}
.hm .fs-kicker{color:var(--brand-orange)}
/* 指標選擇：四格下拉 */
.viz-root:not(#_) .hm .fs-pick-panel{display:block}
.fs-slot{display:grid;grid-template-columns:132px minmax(0,1fr);align-items:center;gap:10px;margin:0 0 10px}
.fs-slot span{white-space:nowrap}
.fs-slot em{display:block;margin-left:0!important}
.fs-slot span{font-size:var(--fs-small);font-weight:600;color:var(--text-secondary)}
.fs-slot em{font-style:normal;font-size:var(--fs-micro);font-weight:700;color:var(--brand-orange);margin-left:6px}
.fs-slot select{font:inherit;font-size:var(--fs-body);padding:8px 10px;border:1px solid var(--border);border-radius:8px;
  background:var(--surface-1);color:var(--text-primary);min-height:40px}
.fs-pick-foot{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-top:4px}
.viz-root:not(#_) .fs-pick-foot .fs-pick-note{border:0;padding:0;margin:0}
.fs-reset{white-space:nowrap;font:inherit;font-size:var(--fs-small);font-weight:600;color:var(--brand-ink);background:transparent;
  border:1px solid var(--brand-navy);border-radius:999px;padding:5px 12px;cursor:pointer}
@media(min-width:760px){.hm .fs-pick-panel{min-width:300px}}
.fs-slot{min-width:0}.fs-slot select{width:100%;max-width:100%;min-width:0}
/* 選舉卡 */
.hm .el-row{background:transparent;border-radius:0;border-top:1px solid var(--grid);padding:12px 2px}
.hm .el-rows .el-row:first-child{border-top:0}
.hm .el-races{gap:0;border:1px solid var(--border);border-radius:12px;overflow:hidden}
.hm .el-race{background:transparent;border-radius:0;border-right:1px solid var(--grid)}
.hm .el-race:last-child{border-right:0}
@media(max-width:759px){.hm .el-races{grid-template-columns:1fr 1fr}.hm .el-race:nth-child(2n){border-right:0}
  .hm .el-race:nth-child(-n+2){border-bottom:1px solid var(--grid)}}
.hm .el-st{background:transparent;border:1px solid var(--grid)}
/* 主卡：可能下一格（品牌帶內） */
.hm-next{display:grid;grid-template-columns:auto 1fr auto;gap:2px 12px;align-items:baseline;margin-top:18px;padding-top:14px;
  border-top:1px solid rgba(255,255,255,.18);color:#fff;text-decoration:none}
.hm-next span{font-size:var(--fs-small);color:rgba(255,255,255,.7)}
.hm-next b{font-size:var(--fs-body);font-weight:700}
.hm-next small{grid-column:2;font-size:var(--fs-small);color:rgba(255,255,255,.75)}
.hm-next .hm-bar{grid-column:2;background:rgba(255,255,255,.18);height:5px;margin-top:6px}
.hm-next em{grid-column:3;grid-row:1;font-style:normal;font-size:var(--fs-small);font-weight:700;color:var(--brand-orange);white-space:nowrap}
@media(max-width:759px){.hm-next{grid-template-columns:1fr auto}.hm-next small,.hm-next .hm-bar{grid-column:1/-1}
  .hm-next em{grid-column:2;grid-row:1}.hm-next span{grid-column:1/-1}}
/* 四大模組收合列 */
.hm-modx{margin-top:4px;border-top:1px solid var(--grid)}
/* 第十八批：整體情勢預設收合，是第二層的第一個區塊——不要再多一條上框線 */
.viz-root:not(#_) .hm .hm-layer>.hm-briefx:first-child{margin-top:0;border-top:0}

.hm-modx>summary{list-style:none;cursor:pointer;display:flex;flex-wrap:wrap;align-items:center;gap:6px 14px;padding:14px 0}
.hm-modx>summary::-webkit-details-marker{display:none}
.hm-modx>summary::after{content:"展開 ▾";margin-left:auto;font-size:var(--fs-small);font-weight:600;color:var(--brand-orange)}
.hm-modx[open]>summary::after{content:"收合 ▴"}
.hm-modx-k{font-size:var(--fs-small);font-weight:700;color:var(--muted);letter-spacing:.04em}
.hm-modx-s{display:flex;flex-wrap:wrap;gap:4px 16px}
.viz-root:not(#_) .hm-modx-s span{display:inline-flex;align-items:center;gap:6px;font-size:var(--fs-body);font-weight:600;color:var(--text-primary)}
.hm .hm-hero{margin-top:18px}
/* 模組卡改白底細線 */
.hm .hm-mods{gap:0;border:1px solid var(--border);border-radius:12px;overflow:hidden}
.hm .hm-mod{background:transparent;border:0;border-radius:0;border-right:1px solid var(--grid)}
.hm .hm-mod:last-child{border-right:0}
.hm .hm-mod:hover{background:var(--surface-2)}
@media(max-width:759px){.hm .hm-mod:nth-child(2n){border-right:0}.hm .hm-mod:nth-child(-n+2){border-bottom:1px solid var(--grid)}}
.hm .hm-new{background:transparent;border:1px solid var(--grid)}
/* 日曆換週 */
.hm-wk-in{position:absolute;opacity:0;pointer-events:none}
/* 第十八批：接下來看什麼的三個篩選（純 CSS radio）＋市場預估 */
.hm-cat-in{position:absolute;opacity:0;pointer-events:none}
.hm-cats{display:flex;gap:0;margin:0 0 14px;border-bottom:1px solid var(--grid)}
.hm-cats label{cursor:pointer;padding:8px 14px;font-size:var(--fs-small);font-weight:700;color:var(--muted);
  border-bottom:2px solid transparent;margin-bottom:-1px}
#hm-cat-data:checked~.hm-cats label[for=hm-cat-data],#hm-cat-sup:checked~.hm-cats label[for=hm-cat-sup],
#hm-cat-spk:checked~.hm-cats label[for=hm-cat-spk],#hm-cat-hol:checked~.hm-cats label[for=hm-cat-hol]{color:var(--brand-ink);border-bottom-color:var(--brand-orange)}
.hm-cat,.hm-cnt{display:none}
#hm-cat-data:checked~.hm-wk .hm-cat-data,#hm-cat-sup:checked~.hm-wk .hm-cat-sup,#hm-cat-spk:checked~.hm-wk .hm-cat-spk,#hm-cat-hol:checked~.hm-wk .hm-cat-hol{display:block}
#hm-cat-data:checked~.hm-wk .hm-cnt-data,#hm-cat-sup:checked~.hm-wk .hm-cnt-sup,#hm-cat-spk:checked~.hm-wk .hm-cnt-spk,#hm-cat-hol:checked~.hm-wk .hm-cnt-hol{display:inline}
.hm-cons{display:flex;flex-wrap:wrap;align-items:baseline;gap:6px 16px;margin-top:8px;padding:8px 10px;border-radius:8px;background:var(--surface-2)}
.hm-cons-k{font-size:var(--fs-micro);font-weight:700;color:var(--muted)}
.hm-cons-i{display:inline-flex;align-items:baseline;gap:6px;font-variant-numeric:tabular-nums}
.hm-cons-l{font-size:var(--fs-small);color:var(--text-secondary)}
.hm-cons-i b{font-size:var(--fs-body);font-weight:800;color:var(--brand-ink)}
.hm-cons-i small{font-size:var(--fs-micro);color:var(--muted)}
.hm-cons-p{font-size:var(--fs-small);color:var(--text-secondary)}
.hm-cons-s{margin-left:8px;font-size:var(--fs-micro);font-weight:600;color:var(--muted);font-variant-numeric:tabular-nums;white-space:nowrap}
.hm-tr{margin-top:6px}
.hm-tr>summary{cursor:pointer;font-size:var(--fs-small);font-weight:700;color:var(--brand-ink);list-style:none}
.hm-tr>summary::-webkit-details-marker{display:none}
.hm-tr>summary::after{content:" ▾";color:var(--brand-orange)}
.hm-tr[open]>summary::after{content:" ▴"}
.hm-tr .kh{margin-top:6px;max-width:420px}
.hm-x b{display:block}
.hm-cat>.hm-mid:first-child{border-top:0}
.hm-x-sub{display:block;margin-top:2px;font-size:var(--fs-small);font-weight:400;color:var(--muted)}
.hm-x-tag,.hm-x-vote{white-space:nowrap;display:inline-block;font-style:normal;font-size:var(--fs-micro);font-weight:700;border-radius:4px;padding:0 5px;vertical-align:1px}
.hm-x-tag{margin-right:6px;color:var(--brand-ink);background:var(--surface-2);border:1px solid var(--border)}
.hm-x-vote{margin-left:6px;color:#fff;background:var(--brand-orange)}
/* 休市（2026-10）：標籤三色——全部休市（實心橘）、部分休市（橘框）、提早收盤（灰框） */
.hm-hol-tag{white-space:nowrap;display:inline-block;font-style:normal;font-size:var(--fs-micro);font-weight:700;
  border-radius:4px;padding:0 5px;margin-right:8px;vertical-align:1px;border:1px solid transparent}
.hm-hol-all{color:#fff;background:var(--brand-orange);border-color:var(--brand-orange)}
.hm-hol-part{color:var(--brand-orange);border-color:var(--brand-orange)}
.hm-hol-early{color:var(--text-secondary);border-color:var(--border)}
.hm-hol-nm{margin-left:8px;font-weight:400;color:var(--text-secondary)}
.hm-hol.hm-same{border-top-style:dashed}
.hm-hol.hm-same .hm-mid-d{visibility:hidden}
.hm-notes{margin-top:14px}.hm-notes .hm-foot{margin:6px 0 0}
.hm-notes .hc-note{display:none}#hm-view-cal:checked~.hm-notes .hc-note{display:block}
.hm-hol-note{color:var(--text-secondary)}
.hm-hol-tw{white-space:nowrap}
/* 「接下來看什麼」列表／月曆切換（2026-10） */
.hm-view{position:relative}
.hm-view-in,.hc-m-in,.hc-f-in{position:absolute;opacity:0;pointer-events:none}
.hm-view-sw{display:flex;justify-content:flex-end;gap:0;margin:-6px 0 10px}
.hm-view-sw label{cursor:pointer;font-size:var(--fs-micro);font-weight:700;color:var(--muted);padding:4px 12px;
  border:1px solid var(--border);background:var(--surface-1)}
.hm-view-sw label:first-child{border-radius:999px 0 0 999px}.hm-view-sw label:last-child{border-radius:0 999px 999px 0;border-left:0}
#hm-view-list:checked~.hm-view-sw label[for=hm-view-list],#hm-view-cal:checked~.hm-view-sw label[for=hm-view-cal]{
  color:#fff;background:var(--brand-orange);border-color:var(--brand-orange)}
.hm-cal{display:none}
#hm-view-cal:checked~.hm-wkx{display:none}
#hm-view-cal:checked~.hm-cal{display:block}
/* 圖例兼篩選 */
.hc-lg{display:flex;flex-wrap:wrap;gap:6px;margin:0 0 10px}
.hc-lg label{cursor:pointer;display:inline-flex;align-items:center;gap:6px;font-size:var(--fs-micro);font-weight:700;
  color:var(--text-primary);padding:3px 10px;border:1px solid var(--border);border-radius:999px;background:var(--surface-1)}
#hc-f-d:not(:checked)~.hc-lg label[for=hc-f-d],#hc-f-s:not(:checked)~.hc-lg label[for=hc-f-s],
#hc-f-p:not(:checked)~.hc-lg label[for=hc-f-p],#hc-f-h:not(:checked)~.hc-lg label[for=hc-f-h]{opacity:.4;text-decoration:line-through}
#hc-f-d:not(:checked)~.hc-ms .mk-w:has(.mk-d),#hc-f-s:not(:checked)~.hc-ms .mk-w:has(.mk-s),
#hc-f-p:not(:checked)~.hc-ms .mk-w:has(.mk-p),#hc-f-h:not(:checked)~.hc-ms .hc-d .hc-h,
#hc-f-d:not(:checked)~.hc-dds .hc-k-d,#hc-f-s:not(:checked)~.hc-dds .hc-k-s,
#hc-f-p:not(:checked)~.hc-dds .hc-k-p,#hc-f-h:not(:checked)~.hc-dds .hc-k-h{display:none}
#hc-f-h:not(:checked)~.hc-ms .hc-gray{background:transparent}
/* 標記：數據圓（實心／空心）、發債方塊、談話三角——形狀＋顏色，不只靠顏色 */
.mk{display:inline-block;width:8px;height:8px;flex:none}
.mk-d{border-radius:50%;background:var(--brand-orange);border:1.5px solid var(--brand-orange);box-sizing:border-box}
.mk-d.mk-o{background:transparent}
.mk-s{background:var(--series-1);border-radius:1px}
.mk-p{width:9px;height:8px;background:var(--good);clip-path:polygon(50% 0,100% 100%,0 100%)}
.mk-w{display:inline-flex;align-items:center;gap:1px}
.mk-w small{font-size:9.5px;font-weight:700;color:var(--text-secondary);line-height:1}
/* 月份 */
.hc-mp{display:none}
#hc-m-0:checked~.hc-ms>.hc-mp:nth-child(1),#hc-m-1:checked~.hc-ms>.hc-mp:nth-child(2),
#hc-m-2:checked~.hc-ms>.hc-mp:nth-child(3),#hc-m-3:checked~.hc-ms>.hc-mp:nth-child(4){display:block}
.hc-grid{display:grid;grid-template-columns:repeat(5,1fr) .62fr .62fr;border-top:1px solid var(--grid);border-left:1px solid var(--grid)}
.hc-wd{font-size:var(--fs-micro);font-weight:700;color:var(--muted);text-align:center;padding:5px 0;
  border-right:1px solid var(--grid);border-bottom:1px solid var(--grid)}
.hc-wd.hc-we{color:var(--faint,var(--muted))}
.hc-d{position:relative;min-height:56px;padding:4px 4px 5px;border:0;border-right:1px solid var(--grid);
  border-bottom:1px solid var(--grid);background:transparent;font:inherit;color:inherit;text-align:left;cursor:pointer;
  display:flex;flex-direction:column;justify-content:space-between;min-width:0}
.hc-d.hc-out{cursor:default}
.hc-d.hc-we .hc-n{color:var(--muted)}
.hc-d.hc-gray{background:repeating-linear-gradient(135deg,var(--grid) 0 2px,transparent 2px 7px),var(--surface-2)}
.hc-d.hc-past .hc-n,.hc-d.hc-past .hc-m{opacity:.4}
.hc-n{font-size:var(--fs-small);font-weight:700;font-variant-numeric:tabular-nums;color:var(--text-primary);line-height:1.2}
.hc-d.hc-today .hc-n{color:#fff;background:var(--brand-orange);border-radius:999px;padding:0 6px;align-self:flex-start}
.hc-d.hc-sel{box-shadow:inset 0 0 0 2px var(--brand-orange)}
.hc-h{position:absolute;top:4px;right:4px;font-style:normal;font-size:10px;font-weight:700;line-height:1;
  color:var(--text-secondary);border:1px solid var(--border);border-radius:3px;padding:1px 2px;background:var(--surface-1)}
.hc-lg .hc-h{position:static}
.hc-m{display:flex;flex-wrap:wrap;gap:3px 5px;align-items:center;min-height:10px}
/* 當天明細 */
.hc-dds{margin-top:12px}
.hc-dd-h{font-size:var(--fs-body);font-weight:800;padding:6px 0;border-bottom:2px solid var(--brand-orange);margin-bottom:2px}
.hc-row .hm-mid-d{display:none}
.hc-row .hm-mid{grid-template-columns:1fr auto}
.hc-k-d .hm-mid>b::before,.hc-k-s .hm-mid>b::before,.hc-k-p .hm-mid>b::before{content:"";display:inline-block;margin-right:7px;vertical-align:1px}
.hc-k-d .hm-mid>b::before{width:8px;height:8px;border-radius:50%;background:var(--brand-orange)}
.hc-k-s .hm-mid>b::before{width:8px;height:8px;background:var(--series-1);border-radius:1px}
.hc-k-p .hm-mid>b::before{width:9px;height:8px;background:var(--good);clip-path:polygon(50% 0,100% 100%,0 100%)}
.hc-lo .hm-mid>b::before{background:transparent!important;border:1.5px solid var(--brand-orange);box-sizing:border-box}
@media(max-width:560px){.hc-d{min-height:50px;padding:3px 3px 4px}.hc-row .hm-mid{grid-template-columns:1fr auto}.hc-row .hm-mid-t{grid-column:2}}
.hm-hol-note::before{content:"→ ";color:var(--brand-orange)}
.hm-wk-p{display:none}
.hm-wk-in:nth-of-type(1):checked~.hm-wk-ps>.hm-wk-p:nth-child(1),
.hm-wk-in:nth-of-type(2):checked~.hm-wk-ps>.hm-wk-p:nth-child(2),
.hm-wk-in:nth-of-type(3):checked~.hm-wk-ps>.hm-wk-p:nth-child(3),
.hm-wk-in:nth-of-type(4):checked~.hm-wk-ps>.hm-wk-p:nth-child(4){display:block}
.hm-wk-h{display:grid;grid-template-columns:40px 1fr 40px;align-items:center;gap:8px;margin-bottom:14px;
  border-bottom:1px solid var(--grid);padding-bottom:12px}
.hm-wk-t{text-align:center;display:flex;flex-direction:column;align-items:center;gap:2px}
.hm-wk-t b{font-size:var(--fs-h3);color:var(--brand-ink)}
.hm-wk-t span{font-size:var(--fs-small);color:var(--muted)}
.hm-wk-dots{display:flex;gap:5px;margin-top:4px}
.hm-wk-dots i{width:6px;height:6px;border-radius:50%;background:var(--grid)}
.hm-wk-dots i.on{background:var(--brand-orange)}
.hm-wk-a{display:flex;align-items:center;justify-content:center;width:40px;height:40px;border-radius:50%;
  border:1px solid var(--border);font-size:22px;line-height:1;color:var(--brand-ink);cursor:pointer;user-select:none}
.hm-wk-a:hover{border-color:var(--brand-ink)}
.hm-wk-a.off{opacity:.25;cursor:default}
.hm .hm-hi{background:transparent}
/* 總覽 v4 */
/* 焦點：指標兩層（名稱＋日期／數字＋漲跌）；左欄不再跟著新聞撐高 */
.hm .fs-grid{align-items:start}
.hm .focus-strip .fs-chips{grid-auto-rows:auto;align-content:start}
.viz-root:not(#_) .hm .focus-strip .fs-chip{display:grid;grid-template-columns:auto 1fr auto;
  grid-template-areas:"l l d" "v x x";align-items:baseline;column-gap:10px;row-gap:4px;min-height:0;padding:12px 14px;justify-content:stretch}
.hm .focus-strip .fs-chip>span{grid-area:l;margin:0}
.hm .focus-strip .fs-chip>.fs-when{grid-area:d;margin:0;text-align:right}
.hm .focus-strip .fs-chip>b{grid-area:v}
.hm .focus-strip .fs-chip>i{grid-area:x;margin:0;line-height:1.35}
.viz-root:not(#_) .hm .focus-strip .fs-chip.fs-off{display:none}
.viz-root:not(#_) .hm .focus-strip .fs-chip{align-content:start}

.viz-root:not(#_) .hm .focus-strip .fs-chip>b{font-size:22px}
/* 四大模組：一列一個 */
.hm-mrs{border:1px solid var(--border);border-radius:12px;overflow:hidden;margin-bottom:6px}
.hm-mr{display:grid;grid-template-columns:96px 150px 1fr 20px;gap:12px;align-items:center;padding:13px 16px;
  border-top:1px solid var(--grid);color:inherit;text-decoration:none}
.hm-mr:first-child{border-top:0}
.hm-mr:hover{background:var(--surface-2)}
.hm-mr-n{font-size:var(--fs-body);font-weight:700;color:var(--brand-ink)}
.hm-mr .hm-st{font-size:var(--fs-body);color:var(--text-primary)}
.hm-mr-v{display:flex;flex-wrap:wrap;gap:4px 22px}
.viz-root:not(#_) .hm-mr-v>span{display:inline-flex;align-items:baseline;gap:8px}
.hm-mr-v em{font-style:normal;font-size:var(--fs-small);color:var(--muted)}
.hm-mr-v b{font-size:var(--fs-body);font-weight:700;font-variant-numeric:tabular-nums}
.hm-mr-go{color:var(--brand-orange);font-weight:700;text-align:right}
@media(max-width:759px){
  .hm-mr{grid-template-columns:1fr auto 16px;grid-template-areas:"n s g" "v v v";gap:6px 10px;padding:12px 14px}
  .hm-mr-n{grid-area:n}.hm-mr .hm-st{grid-area:s}.hm-mr-v{grid-area:v;display:grid;grid-template-columns:1fr 1fr;gap:4px 14px}
  .viz-root:not(#_) .hm-mr-v>span{display:flex;flex-direction:column;align-items:flex-start;gap:0}.hm-mr-go{grid-area:g}}
/* 本期變化：依方向分組 */
.viz-root:not(#_) .hm-chsum{font-size:15px;line-height:1.75;margin:0 0 16px}
.hm-chsum b{font-weight:700}.hm-chsum b.dov{color:var(--series-1)}.hm-chsum b.haw{color:var(--serious)}
.hm-chcs{display:grid;gap:12px}
@media(min-width:760px){.hm-chcs{grid-template-columns:repeat(3,minmax(0,1fr))}}
.hm-chc{border:1px solid var(--border);border-radius:12px;padding:14px 16px;border-top:3px solid var(--muted-bar)}
.hm-chc.dovish{border-top-color:var(--series-1)}.hm-chc.hawkish{border-top-color:var(--serious)}
.hm-chc-h{display:flex;flex-direction:column;gap:2px;margin-bottom:8px}
.hm-chc-h b{font-size:var(--fs-h3);color:var(--text-primary)}
.hm-chc-h span{font-size:var(--fs-small);color:var(--muted)}
.hm-chc ul{list-style:none;margin:0;padding:0}
.viz-root:not(#_) .hm-chc li{font-size:var(--fs-body);line-height:1.65;color:var(--text-primary);padding:7px 0;border-top:1px solid var(--grid)}
.hm-chc li:first-child{border-top:0}
.hm-tag{display:inline-block;font-size:var(--fs-micro);font-weight:700;color:var(--brand-ink);border:1px solid var(--border);
  border-radius:4px;padding:0 5px;margin-right:6px;vertical-align:1px}
.hm-chc .hm-more{margin-left:0}
/* 選舉：數字為主 */
.el2-chs{display:grid;gap:0;border:1px solid var(--border);border-radius:12px;overflow:hidden}
@media(min-width:760px){.el2-chs{grid-template-columns:1fr 1fr}.el2-ch+.el2-ch{border-left:1px solid var(--grid)}}
@media(max-width:759px){.el2-ch+.el2-ch{border-top:1px solid var(--grid)}}
.el2-ch{display:grid;grid-template-columns:auto 1fr auto;grid-template-areas:"k k s" "v v s" "m m s";gap:2px 12px;
  align-items:center;padding:14px 16px;color:inherit;text-decoration:none}
.el2-k{grid-area:k;font-size:var(--fs-small);font-weight:700;color:var(--muted)}
.el2-ch b{grid-area:v;font-size:var(--fs-num);font-weight:700;font-variant-numeric:tabular-nums}
.el2-ch b.dem{color:var(--el-dem)}.el2-ch b.rep{color:var(--el-rep)}
.el2-ch small{grid-area:m;font-size:var(--fs-small);color:var(--muted)}
.el2-ch .el-spark{grid-area:s}
.el2-line{display:grid;grid-template-columns:130px 1fr;gap:6px 14px;align-items:baseline;padding:13px 2px;
  border-bottom:1px solid var(--grid);color:inherit;text-decoration:none}
.el2-lk{font-size:var(--fs-small);font-weight:700;color:var(--muted)}
.el2-items{display:flex;flex-wrap:wrap;gap:4px 20px}
.el2-items span{display:inline-flex;align-items:center;gap:7px;font-size:var(--fs-body)}
.el2-items b{font-variant-numeric:tabular-nums}
.el2-rs{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:4px 16px}
.el2-r{display:flex;flex-direction:column;color:inherit;text-decoration:none;min-width:0}
.el2-r span{font-size:var(--fs-small);color:var(--muted)}
.el2-r b{font-size:var(--fs-body);font-weight:700;font-variant-numeric:tabular-nums}
.el2-r b.dem{color:var(--el-dem)}.el2-r b.rep{color:var(--el-rep)}
.el2-r small{font-size:var(--fs-micro);color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
@media(max-width:759px){.el2-line{grid-template-columns:1fr}.el2-rs{grid-template-columns:1fr 1fr;gap:10px 16px}}
.el-card .el2-line:first-of-type{margin-top:6px}
/* 總覽 v5：焦點指標＝報價板（一指標一行、欄位對齊、兩種字級、只有三角形有顏色） */
.viz-root:not(#_) .hm .focus-strip .fs-chips{display:block;border:1px solid var(--border);border-radius:12px;overflow:hidden;background:var(--surface-1)}
.hm .fs-hd,.viz-root:not(#_) .hm .focus-strip .fs-chip{display:grid;grid-template-columns:minmax(0,1fr) 92px 96px 44px;
  grid-template-areas:none;column-gap:10px;align-items:baseline;padding:11px 14px;min-height:0;border:0;border-radius:0;background:transparent}
.hm .fs-hd{padding:8px 14px;border-bottom:1px solid var(--border)}
.hm .fs-hd span{font-size:var(--fs-micro);color:var(--muted);font-weight:600}
.hm .fs-hd span:nth-child(n+2){text-align:right}
.viz-root:not(#_) .hm .focus-strip .fs-chip{border-top:1px solid var(--grid)}
.viz-root:not(#_) .hm .focus-strip .fs-hd+.fs-chip,.viz-root:not(#_) .hm .focus-strip .fs-hd~.fs-chip.fs-off+.fs-chip{border-top:0}
.viz-root:not(#_) .hm .focus-strip .fs-chip>*{grid-area:auto;margin:0}
.viz-root:not(#_) .hm .focus-strip .fs-chip>span{font-size:13px;color:var(--text-primary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.viz-root:not(#_) .hm .focus-strip .fs-chip>b{font-size:18px;font-weight:700;text-align:right;white-space:nowrap;color:var(--text-primary);line-height:1.3}
.viz-root:not(#_) .hm .focus-strip .fs-chip>i{font-size:13px;font-weight:400;font-style:normal;color:var(--text-secondary);text-align:right;white-space:nowrap}
.viz-root:not(#_) .hm .focus-strip .fs-chip>i.up::before{content:"▲ ";color:var(--critical);font-size:10px}
.viz-root:not(#_) .hm .focus-strip .fs-chip>i.dn::before{content:"▼ ";color:var(--good);font-size:10px}
.viz-root:not(#_) .hm .focus-strip .fs-chip>.fs-when{font-size:12px;color:var(--muted);text-align:right;white-space:nowrap}
@media(max-width:480px){.hm .fs-hd,.viz-root:not(#_) .hm .focus-strip .fs-chip{grid-template-columns:minmax(0,1fr) 82px 80px 34px;column-gap:8px;padding-left:12px;padding-right:12px}
  .viz-root:not(#_) .hm .focus-strip .fs-chip>b{font-size:17px}.viz-root:not(#_) .hm .focus-strip .fs-chip>.fs-when{font-size:11px}}
.viz-root:not(#_) .hm .focus-strip .fs-chip:is([data-chip=fedwatch],[data-chip=fw_h1],[data-chip=fw_h2],[data-chip=fw_h3])>i::before{content:none}
.viz-root:not(#_) .hm-mr-v em{white-space:nowrap}
@media(max-width:480px){.viz-root:not(#_) .hm .focus-strip .fs-chip[data-chip=fedwatch]>b{font-size:15px}}
.viz-root:not(#_) .hm-mr-v{min-width:0}
/* 四大模組：左（名稱＋判讀）｜右（兩個數字，標籤左、數值右對齊） */
.viz-root:not(#_) .hm-mr{grid-template-columns:168px 1fr 14px;grid-template-areas:none;gap:0 16px;align-items:center;padding:12px 16px}
.hm-mr-l{display:flex;flex-direction:column;gap:3px;padding-right:16px;border-right:1px solid var(--grid);align-self:stretch;justify-content:center}
.hm-mr-l b{font-size:var(--fs-body);font-weight:700;color:var(--brand-ink)}
.viz-root:not(#_) .hm-mr-l .hm-st{font-size:var(--fs-small);color:var(--text-secondary)}
.viz-root:not(#_) .hm-mr-v{display:grid;grid-template-columns:1fr;gap:4px;grid-area:auto}
.viz-root:not(#_) .hm-mr-v>span{display:flex;flex-direction:row;justify-content:space-between;align-items:baseline;gap:12px}
.viz-root:not(#_) .hm-mr-v em{font-style:normal;font-size:var(--fs-small);color:var(--muted)}
.viz-root:not(#_) .hm-mr-v b{font-size:var(--fs-body);font-weight:700;text-align:right;white-space:nowrap}
.viz-root:not(#_) .hm-mr-go{grid-area:auto;color:var(--muted-bar);font-size:18px;font-weight:400}
@media(max-width:759px){.viz-root:not(#_) .hm-mr{grid-template-columns:116px 1fr 10px;gap:0 12px;padding:12px}
  .hm-mr-l{padding-right:12px}}
/* 第十八批：四大模組切成等寬四格（桌機一列四格、手機 2×2），收合摘要與展開格一一對齊 */
.viz-root:not(#_) .hm .hm-modx>summary:has(.hm-ms4){flex-wrap:wrap}
.viz-root:not(#_) .hm .hm-modx>summary:has(.hm-ms4)::after{order:2}
.viz-root:not(#_) .hm .hm-ms4{order:3;flex:1 1 100%;display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:6px 0}
.viz-root:not(#_) .hm .hm-ms4>span{padding:0 16px;min-width:0;white-space:nowrap}
.viz-root:not(#_) .hm .hm-mrs{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:0}
.viz-root:not(#_) .hm .hm-mr{display:flex;flex-direction:column;align-items:stretch;gap:10px;position:relative;
  padding:14px 16px;border-top:0;border-left:1px solid var(--grid);min-width:0}
.viz-root:not(#_) .hm .hm-mr:first-child{border-left:0}
.viz-root:not(#_) .hm .hm-mr-l{padding:0 22px 10px 0;border-right:0;border-bottom:1px solid var(--grid);align-self:auto}
.viz-root:not(#_) .hm .hm-mr-v{display:grid;grid-template-columns:1fr;gap:6px}
.viz-root:not(#_) .hm .hm-mr-v>span{display:flex;flex-direction:row;justify-content:space-between;align-items:baseline;gap:8px;min-width:0}
.viz-root:not(#_) .hm .hm-mr-go{position:absolute;top:12px;right:12px}
@media(max-width:759px){
  .viz-root:not(#_) .hm .hm-ms4{grid-template-columns:repeat(2,minmax(0,1fr))}
  .viz-root:not(#_) .hm .hm-ms4>span{padding:0 12px}
  .viz-root:not(#_) .hm .hm-mrs{grid-template-columns:repeat(2,minmax(0,1fr))}
  .viz-root:not(#_) .hm .hm-mr{padding:12px}
  .viz-root:not(#_) .hm .hm-mr:nth-child(odd){border-left:0}
  .viz-root:not(#_) .hm .hm-mr:nth-child(n+3){border-top:1px solid var(--grid)}
  .viz-root:not(#_) .hm .hm-mr-v>span{flex-direction:column;align-items:flex-start;gap:0}}
/* 焦點報價板 v6：指標｜日期｜數值｜變動；文字欄靠左、數字欄靠右，欄名同向 */
.hm .fs-hd,.viz-root:not(#_) .hm .focus-strip .fs-chip{grid-template-columns:minmax(0,1fr) 46px 84px 96px;column-gap:10px}
.hm .fs-hd span:nth-child(-n+2){text-align:left}
.hm .fs-hd span:nth-child(n+3){text-align:right}
.viz-root:not(#_) .hm .focus-strip .fs-chip>.fs-when{grid-column:auto;text-align:left;font-size:12px;font-variant-numeric:tabular-nums}
.viz-root:not(#_) .hm .focus-strip .fs-chip>b{grid-column:auto;font-variant-numeric:tabular-nums}
.viz-root:not(#_) .hm .focus-strip .fs-chip>i{font-variant-numeric:tabular-nums}
.viz-root:not(#_) .hm .focus-strip .fs-chip[data-chip=fedwatch]>b{font-size:18px}
.viz-root:not(#_) .hm .focus-strip .fs-chip:is([data-chip=fedwatch],[data-chip=fw_h1],[data-chip=fw_h2],[data-chip=fw_h3])>i.up::before{content:"▲ ";color:var(--critical);font-size:10px}
.viz-root:not(#_) .hm .focus-strip .fs-chip:is([data-chip=fedwatch],[data-chip=fw_h1],[data-chip=fw_h2],[data-chip=fw_h3])>i.dn::before{content:"▼ ";color:var(--good);font-size:10px}
.viz-root:not(#_) .hm .focus-strip .fs-chip[title]{cursor:help}
@media(max-width:480px){.hm .fs-hd,.viz-root:not(#_) .hm .focus-strip .fs-chip{grid-template-columns:minmax(0,1fr) 38px 80px 80px;column-gap:6px;padding-left:10px;padding-right:10px}
  .viz-root:not(#_) .hm .focus-strip .fs-chip>b,.viz-root:not(#_) .hm .focus-strip .fs-chip[data-chip=fedwatch]>b{font-size:16px}
  .viz-root:not(#_) .hm .focus-strip .fs-chip>span,.viz-root:not(#_) .hm .focus-strip .fs-chip>i{font-size:12.5px}
  .viz-root:not(#_) .hm .focus-strip .fs-chip>.fs-when{font-size:11.5px}}
@media(max-width:380px){.viz-root:not(#_) .hm .focus-strip{padding-left:12px;padding-right:12px}
  .hm .fs-hd,.viz-root:not(#_) .hm .focus-strip .fs-chip{grid-template-columns:minmax(0,1fr) 34px 76px 76px;column-gap:5px;padding-left:8px;padding-right:8px}
  .viz-root:not(#_) .hm .focus-strip .fs-chip>span,.viz-root:not(#_) .hm .focus-strip .fs-chip>i{font-size:12px}
  .viz-root:not(#_) .hm .focus-strip .fs-chip>.fs-when{font-size:10.5px}
  .viz-root:not(#_) .hm .focus-strip .fs-chip>b,.viz-root:not(#_) .hm .focus-strip .fs-chip[data-chip=fedwatch]>b{font-size:15px}}
/* 報價板 v7：三欄（指標｜數值｜變動），日期改成名稱下方的淺灰小字 */
.hm .fs-hd,.viz-root:not(#_) .hm .focus-strip .fs-chip{grid-template-columns:minmax(0,1fr) 92px 92px;column-gap:12px;align-items:center}
.hm .fs-hd span:nth-child(1){text-align:left}.hm .fs-hd span:nth-child(n+2){text-align:right}
.hm .fs-nm{display:flex;flex-direction:column;min-width:0;gap:1px}
.viz-root:not(#_) .hm .focus-strip .fs-nm>span{font-size:13.5px;color:var(--text-primary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.viz-root:not(#_) .hm .focus-strip .fs-nm>.fs-when{font-size:11px;color:var(--faint);line-height:1.2;margin:0;text-align:left}
.viz-root:not(#_) .hm .focus-strip .fs-chip{padding-top:9px;padding-bottom:9px}
@media(max-width:480px){.hm .fs-hd,.viz-root:not(#_) .hm .focus-strip .fs-chip{grid-template-columns:minmax(0,1fr) 84px 80px;column-gap:8px}}
@media(max-width:380px){.hm .fs-hd,.viz-root:not(#_) .hm .focus-strip .fs-chip{grid-template-columns:minmax(0,1fr) 80px 74px;column-gap:6px}}
/* 報價板 v8：指標｜變動（靠左、箭頭對齊）｜數值（最右、置中） */
.hm .fs-hd,.viz-root:not(#_) .hm .focus-strip .fs-chip{grid-template-columns:38fr 32fr 30fr;column-gap:0;align-items:center}
.hm .fs-hd span:nth-child(1),.hm .fs-hd span:nth-child(2){text-align:left}
.hm .fs-hd span:nth-child(3){text-align:center}
.hm .fs-hd span:nth-child(2){padding-left:16px}
.viz-root:not(#_) .hm .focus-strip .fs-nm{padding-right:14px;border-right:1px solid var(--grid);align-self:stretch;justify-content:center}
.hm .fs-hd span:nth-child(1){border-right:1px solid var(--grid);padding-right:14px}
.viz-root:not(#_) .hm .focus-strip .fs-chip>i{text-align:left;padding-left:16px;color:var(--text-secondary)}
.viz-root:not(#_) .hm .focus-strip .fs-chip>i::before{display:inline-block;width:15px;font-size:10px;content:""}
.viz-root:not(#_) .hm .focus-strip .fs-chip>i.up::before,
.viz-root:not(#_) .hm .focus-strip .fs-chip:is([data-chip=fedwatch],[data-chip=fw_h1],[data-chip=fw_h2],[data-chip=fw_h3])>i.up::before{content:"▲";color:var(--critical);width:15px}
.viz-root:not(#_) .hm .focus-strip .fs-chip>i.dn::before,
.viz-root:not(#_) .hm .focus-strip .fs-chip:is([data-chip=fedwatch],[data-chip=fw_h1],[data-chip=fw_h2],[data-chip=fw_h3])>i.dn::before{content:"▼";color:var(--good);width:15px}
.viz-root:not(#_) .hm .focus-strip .fs-chip>b{text-align:center}
@media(max-width:480px){.hm .fs-hd,.viz-root:not(#_) .hm .focus-strip .fs-chip{grid-template-columns:38fr 31fr 31fr;column-gap:0}
  .viz-root:not(#_) .hm .focus-strip .fs-chip>i{padding-left:12px}.hm .fs-hd span:nth-child(2){padding-left:12px}
  .viz-root:not(#_) .hm .focus-strip .fs-nm{padding-right:10px}.hm .fs-hd span:nth-child(1){padding-right:10px}}
@media(max-width:380px){.hm .fs-hd,.viz-root:not(#_) .hm .focus-strip .fs-chip{grid-template-columns:36fr 32fr 32fr}
  .viz-root:not(#_) .hm .focus-strip .fs-chip>i{padding-left:10px}.hm .fs-hd span:nth-child(2){padding-left:10px}}
/* 報價板：點一下顯示提示（手機沒有滑鼠移上去） */
.viz-root:not(#_) .hm .focus-strip .fs-chip.tip-on::after{content:attr(title);grid-column:1/-1;font-size:11.5px;
  color:var(--text-secondary);padding-top:6px;line-height:1.5}
/* 報價板：就地編輯（2026-10） */
.fs-edit-btn{font:inherit;font-size:var(--fs-small);font-weight:600;color:var(--brand-ink);background:var(--surface-1);
  border:1px solid var(--border);border-radius:8px;padding:5px 11px;cursor:pointer;margin-left:6px}
.fs-editing .fs-edit-btn{background:var(--brand-navy);color:#fff;border-color:var(--brand-ink)}
.fs-editbar{display:none;align-items:center;gap:8px;flex-wrap:wrap;margin:10px 0 0;padding:9px 12px;border-radius:10px;
  background:var(--surface-2);font-size:var(--fs-small);color:var(--text-secondary)}
.fs-editing .fs-editbar{display:flex}
.fs-editbar span{flex:1 1 auto;white-space:nowrap}
.fs-editbar button{font:inherit;font-size:var(--fs-small);font-weight:600;border-radius:999px;padding:4px 12px;cursor:pointer}
.fs-editbar .fs-reset{background:transparent;border:1px solid var(--brand-navy);color:var(--brand-ink)}
.fs-editbar .fs-done{background:var(--brand-orange);border:1px solid var(--brand-orange);color:#fff}
.hm .focus-strip .fs-chip{position:relative}
.fs-rowsel{display:none}
.fs-editing .fs-chip:not(.fs-off) .fs-rowsel{display:block;position:absolute;inset:0;width:100%;height:100%;opacity:0;cursor:pointer;
  font-size:16px;-webkit-appearance:none;appearance:none;border:0}
.fs-editing .fs-chip:not(.fs-off){background:var(--surface-1);box-shadow:inset 3px 0 0 var(--brand-orange)}
.viz-root:not(#_) .hm .fs-editing .fs-chip:not(.fs-off)>b::after{content:" ▾";font-size:11px;color:var(--brand-orange);font-weight:700}
.viz-root:not(#_) .hm .fs-editing .fs-chip.slot1 .fs-nm>span::after,
.viz-root:not(#_) .hm .fs-editing .fs-chip.slot2 .fs-nm>span::after{content:"補充新聞";margin-left:6px;font-size:10px;font-weight:700;
  color:#fff;background:var(--brand-orange);border-radius:4px;padding:0 4px;vertical-align:1px}
.viz-root:not(#_) .hm .fs-editing .fs-chip .fs-nm>span{overflow:visible}
/* 第十八批：勾選清單（不限數量）＋變動欄「日／MTD／YTD」 */
.fs-editbar span{white-space:normal}
.fs-pk-cnt{margin-left:8px;color:var(--brand-ink);font-weight:700}
.fs-pickp{flex:1 1 100%;display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:12px 18px;
  margin-top:8px;padding-top:10px;border-top:1px solid var(--grid)}
.fs-pkg{border:0;margin:0;padding:0;min-width:0}
.fs-pkg legend{font-size:var(--fs-micro);font-weight:700;color:var(--muted);padding:0;margin-bottom:4px;letter-spacing:.04em}
.fs-pk{display:flex;align-items:center;gap:8px;padding:5px 2px;font-size:var(--fs-small);color:var(--text-primary);cursor:pointer}
.fs-pk input{width:16px;height:16px;margin:0;accent-color:var(--brand-orange);flex:none}
.fs-pk input:disabled+span{opacity:.75}
.fs-pk-n{margin-left:auto;font-style:normal;font-size:10.5px;font-weight:700;color:#fff;background:var(--brand-orange);
  border-radius:9px;min-width:18px;text-align:center;padding:0 5px;line-height:17px}
.fs-pk-n:empty{display:none}
.viz-root:not(#_) .hm .fs-editing .fs-chip:not(.fs-off)>b::after{content:none}
/* 2026-10：長按拖曳排序（平常與編輯狀態都可，不顯示把手）；排序不再綁補充新聞，拿掉「補充新聞」小標 */
.focus-strip .fs-chips [data-chip]{-webkit-user-select:none;user-select:none;-webkit-touch-callout:none}
.focus-strip .fs-chip.fs-drag{z-index:5;position:relative;background:var(--surface-1);cursor:grabbing;
  box-shadow:0 8px 22px rgba(18,35,59,.20),inset 3px 0 0 var(--brand-orange);opacity:.97}
.viz-root:not(#_) .hm .fs-editing .fs-chip.slot1 .fs-nm>span::after,
.viz-root:not(#_) .hm .fs-editing .fs-chip.slot2 .fs-nm>span::after{content:none}
.fs-mode{position:relative;display:inline-flex;align-items:center}
.fs-mode::after{content:"▾";position:absolute;right:6px;pointer-events:none;font-size:10px;color:var(--brand-orange)}
.fs-mode-sel{font:inherit;font-size:var(--fs-micro);font-weight:700;color:var(--brand-ink);background:var(--surface-1);
  border:1px solid var(--border);border-radius:6px;padding:2px 20px 2px 7px;cursor:pointer;
  -webkit-appearance:none;appearance:none;line-height:1.5}
.fs-mode-sel:hover,.fs-mode-sel:focus{border-color:var(--brand-ink);outline:none}
/* 新聞主題標籤（反向聯動） */
.fs-tps{display:flex;flex-wrap:wrap;align-items:center;gap:6px;margin:0 0 12px}
.fs-tps-k{font-size:var(--fs-micro);font-weight:700;color:var(--muted);margin-right:2px}
.fs-tp{font:inherit;font-size:var(--fs-small);font-weight:600;border-radius:999px;padding:3px 10px;cursor:pointer;
  background:var(--surface-1);color:var(--brand-ink);border:1px solid var(--border)}
.fs-tp:hover{border-color:var(--brand-ink)}
.fs-tp.on{background:var(--brand-navy);border-color:var(--brand-ink);color:#fff}
.fs-tp.na{opacity:.4;cursor:default}
/* 補充新聞主題標籤：可點、換主題（2026-10） */
.fs-tag.fs-tagsel{position:relative;padding-right:18px;cursor:pointer;border:1px solid var(--brand-navy)!important}
.fs-tag.fs-tagsel::after{content:"▾";position:absolute;right:5px;top:50%;transform:translateY(-52%);font-size:10px;color:var(--brand-orange)}
.fs-tag.fs-tagsel select{position:absolute;inset:0;width:100%;height:100%;opacity:0;cursor:pointer;font-size:16px;border:0;-webkit-appearance:none;appearance:none}
/* 選舉：兩院組合 100% 比例條、「更多」 */
.el-map2{margin-top:14px}
.el-more{margin-top:10px;border-top:1px solid var(--grid)}
.el-more>summary{list-style:none;cursor:pointer;padding:12px 0;font-size:var(--fs-small);font-weight:700;color:var(--brand-ink)}
.el-more>summary::-webkit-details-marker{display:none}
.el-more>summary::after{content:" ▾";color:var(--brand-orange)}
.el-more[open]>summary::after{content:" ▴"}
.el-more-k{font-size:var(--fs-small);font-weight:700;color:var(--muted);margin:16px 0 8px}
.el-more-b>.el-more-k:first-child{margin-top:4px}
.el-bal3{display:block;color:inherit;text-decoration:none}
.el-b3{display:flex;height:26px;border-radius:7px;overflow:hidden;gap:2px;background:var(--surface-1)}
.el-b3 i{display:flex;align-items:center;justify-content:center;min-width:2px}
.el-b3 i em{font-style:normal;font-size:var(--fs-small);font-weight:700;color:#fff;white-space:nowrap}
.el-b3 i.dem{background:var(--el-dem)}.el-b3 i.rep{background:var(--el-rep)}
.el-b3 i.mix{background:var(--el-mix)}.el-b3 i.mix2{background:var(--el-mix2)}.el-b3 i.oth{background:var(--el-oth)}
/* 長端首卡第三版：一行報價＋主因一句＋三段組成小表 */
.le2-q{display:grid;grid-template-columns:1fr 1fr;border:1px solid var(--border);border-radius:12px;overflow:hidden}
.le2-qi{min-width:0;display:grid;grid-template-columns:auto 1fr;grid-template-areas:"k k" "v c";gap:2px 10px;
  align-items:baseline;padding:12px 16px}
.le2-qi+.le2-qi{border-left:1px solid var(--grid)}
.le2-qi span{grid-area:k;font-size:var(--fs-small);color:var(--muted)}
.viz-root:not(#_) .le2-qi b{grid-area:v;font-size:var(--fs-num);font-weight:700;color:var(--brand-ink);font-variant-numeric:tabular-nums}
.le2-qi em{grid-area:c;font-style:normal;font-size:var(--fs-small);color:var(--text-secondary);white-space:nowrap}
.le2-qi em.up::before{content:"▲ ";color:var(--critical);font-size:10px}
.le2-qi em.dn::before{content:"▼ ";color:var(--good);font-size:10px}
@media(max-width:480px){.le2-qi{grid-template-areas:"k" "v" "c";grid-template-columns:1fr;padding:10px 12px}}
.le2-asof{font-size:var(--fs-micro);color:var(--faint);margin:6px 2px 0;text-align:right}
.le2 .focus-title{margin-top:16px}
.le2-t{margin-top:16px;border:1px solid var(--border);border-radius:12px;overflow:hidden}
.le2-h,.le2-r{display:grid;grid-template-columns:minmax(0,1fr) 76px 84px;column-gap:10px;align-items:center;padding:10px 14px}
.le2-h{padding:8px 14px;border-bottom:1px solid var(--border)}
.le2-h span{font-size:var(--fs-micro);font-weight:600;color:var(--muted)}
.le2-h span:nth-child(n+2){text-align:right}
.le2-r{border-top:1px solid var(--grid);cursor:help}
.le2-h+.le2-r{border-top:0}
.le2-r.main{box-shadow:inset 3px 0 0 var(--brand-orange);background:rgba(230,113,67,.05)}
.le2-n{display:flex;flex-direction:column;gap:1px;min-width:0}
.le2-n span{font-size:var(--fs-body);font-weight:600;color:var(--text-primary)}
.le2-n em{font-style:normal;font-size:10px;font-weight:700;color:#fff;background:var(--brand-orange);border-radius:4px;padding:0 5px;margin-left:6px;vertical-align:1px}
.le2-n small{font-size:var(--fs-micro);color:var(--faint)}
.viz-root:not(#_) .le2-r b{font-size:17px;font-weight:700;text-align:right;font-variant-numeric:tabular-nums}
.le2-r i{font-style:normal;font-size:var(--fs-small);color:var(--text-secondary);text-align:right;white-space:nowrap;font-variant-numeric:tabular-nums}
.le2-r i.up::before{content:"▲ ";color:var(--critical);font-size:10px}
.le2-r i.dn::before{content:"▼ ";color:var(--good);font-size:10px}
.le2-r.tip-on::after{content:attr(title);grid-column:1/-1;font-size:var(--fs-small);color:var(--text-secondary);padding-top:6px;line-height:1.5}
.le2-tip{font-size:var(--fs-micro);color:var(--faint);margin:6px 2px 0}
@media(max-width:400px){.le2-h,.le2-r{grid-template-columns:minmax(0,1fr) 66px 76px;padding-left:12px;padding-right:12px}}
.le2-seg{margin-top:16px}.le2-seg .cl-leg{display:none}.le2-seg+.le2-t{margin-top:8px}
.le2-sw{display:inline-block;width:9px;height:9px;border-radius:2px;margin-right:7px;vertical-align:1px}
.el-mpane[hidden],.el-msum[hidden]{display:none!important}
.el-mpane>.el-more-k:first-child{margin-top:4px}
/* 關鍵數字卡 2026-10：判讀小表取代膠囊；日期右上淺灰；白話收進收合層 */
.viz-root:not(#_) .kpi .k-label{display:flex;justify-content:space-between;align-items:baseline;gap:8px}
.kpi .k-when{flex:none;font-size:11px;font-weight:400;color:var(--faint);font-variant-numeric:tabular-nums}
.k-judge{display:grid;gap:0;margin-top:12px;border-top:1px solid var(--grid)}
.kj-r{display:grid;grid-template-columns:34px 1fr;gap:10px;align-items:baseline;padding:7px 0;border-bottom:1px solid var(--grid)}
.kj-k{font-size:var(--fs-small);color:var(--muted);font-weight:600}
.kj-v{font-size:var(--fs-body);color:var(--text-primary);line-height:1.45}
.kj-d{display:inline-block;width:7px;height:7px;border-radius:50%;margin-right:7px;vertical-align:1px;background:var(--muted-bar)}
.kj-d.haw{background:var(--serious)}.kj-d.dov{background:var(--series-1)}.kj-d.wat{background:var(--warning)}
.viz-root:not(#_) .k-plain2{font-size:var(--fs-body);line-height:1.75;color:var(--text-secondary);margin:2px 0 10px}
/* 科技巨頭第三版：三個數字＋加總圖＋一家一列 */
.hs3-q{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));border:1px solid var(--border);border-radius:12px;overflow:hidden;margin-top:14px}
.hs3-q>div{display:flex;flex-direction:column;gap:2px;padding:12px 14px;min-width:0}
.hs3-q>div+div{border-left:1px solid var(--grid)}
.hs3-q span{font-size:var(--fs-small);color:var(--muted)}
.viz-root:not(#_) .hs3-q b{font-size:var(--fs-num);font-weight:700;color:var(--brand-ink);font-variant-numeric:tabular-nums;line-height:1.25}
.viz-root:not(#_) .hs3-q b.over{color:var(--critical)}
.hs3-q small{font-size:var(--fs-micro);color:var(--faint);line-height:1.4}
@media(max-width:600px){.hs3-q{grid-template-columns:1fr}.hs3-q>div+div{border-left:0;border-top:1px solid var(--grid)}
  .hs3-q>div{display:grid;grid-template-columns:1fr auto;align-items:baseline}.hs3-q small{grid-column:1/-1}}
.hs3-chart{margin-top:18px}
.hs3-ch{font-size:var(--fs-small);font-weight:700;color:var(--muted);margin-bottom:24px}
.hs3-p{position:relative;display:flex;gap:6px;height:150px;border-bottom:1px solid var(--text-secondary)}
.hs3-c{position:relative;flex:1 1 0;min-width:0}
.hs3-b{position:absolute;bottom:0;left:16%;right:16%;background:#b7c0cc;border-radius:3px 3px 0 0}
.hs3-c.on .hs3-b{background:var(--brand-navy)}
.hs3-b.over{background:#e7a48a}.hs3-c.on .hs3-b.over{background:var(--brand-orange)}
.hs3-b em,.hs3-o em{position:absolute;left:50%;transform:translateX(-50%);font-style:normal;font-size:var(--fs-micro);font-weight:700;white-space:nowrap}
.hs3-b em{bottom:calc(100% + 3px);color:var(--text-primary)}
.hs3-o{position:absolute;left:4%;right:4%;height:0;border-top:2.5px solid var(--text-primary)}
.hs3-o em{top:-18px;left:auto;right:-4px;transform:none;color:var(--text-secondary)}
.hs3-x{position:absolute;top:calc(100% + 4px);left:50%;transform:translateX(-50%);font-size:var(--fs-micro);color:var(--muted);white-space:nowrap}
.hs3-chart .cl-leg{margin-top:28px}
.hs3-lg-b{display:inline-block;width:12px;height:10px;border-radius:2px;background:var(--brand-navy)}
.hs3-lg-o{display:inline-block;width:16px;border-top:2.5px solid var(--text-primary)}
.hs3-note{font-size:var(--fs-micro);color:var(--faint);margin:6px 0 0;line-height:1.6}
.hs3-t{margin-top:18px;border:1px solid var(--border);border-radius:12px;overflow:hidden}
.hs3-hd,.hs3-r>summary{display:grid;grid-template-columns:minmax(0,1.2fr) 0.9fr 0.7fr 1.3fr 0.8fr 1.1fr;column-gap:12px;align-items:center;padding:10px 14px}
.hs3-hd{border-bottom:1px solid var(--border)}
.hs3-hd span{font-size:var(--fs-micro);font-weight:600;color:var(--muted)}
.hs3-hd span:nth-child(n+2){text-align:right}
.hs3-r{border-top:1px solid var(--grid)}
.hs3-hd+.hs3-r{border-top:0}
.hs3-r>summary{list-style:none;cursor:pointer}
.hs3-r>summary::-webkit-details-marker{display:none}
.hs3-r>summary:hover{background:var(--surface-2)}
.hs3-n{display:flex;flex-direction:column;min-width:0}
.hs3-n b{font-size:var(--fs-body);color:var(--brand-ink)}
.hs3-n small{font-size:var(--fs-micro);color:var(--faint)}
.hs3-v{font-size:var(--fs-body);font-weight:600;text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}
.hs3-v em{display:none;font-style:normal}
.hs3-ratio{display:flex;align-items:center;justify-content:flex-end;gap:8px}
.hs3-ratio b{font-weight:700}.hs3-ratio b.over{color:var(--critical)}
.hs3-rb{position:relative;display:inline-block;width:64px;height:6px;border-radius:3px;background:var(--grid)}
.hs3-rb i{position:absolute;left:0;top:0;bottom:0;border-radius:3px;background:var(--brand-navy)}
.hs3-rb i.over{background:var(--critical)}
.hs3-rb u{position:absolute;left:66.7%;top:-3px;bottom:-3px;border-left:1.5px solid var(--text-primary)}
.hs3-body{padding:4px 14px 14px}
.hs3-deb{font-size:var(--fs-small);color:var(--text-secondary);margin:6px 0 0}
.hs3-stale{font-size:var(--fs-micro);color:var(--faint);margin-top:8px}
.hs3-stale b{color:var(--warning)}
@media(max-width:759px){
  .hs3-hd{display:none}
  .hs3-r>summary{grid-template-columns:1fr 1fr;grid-template-areas:"n r" "a b" "c d";gap:6px 12px;padding:12px}
  .hs3-n{grid-area:n}.hs3-ratio{grid-area:r}
  .hs3-v{text-align:left;display:flex;flex-direction:column}
  .hs3-v em{display:block;font-size:var(--fs-micro);color:var(--faint);font-weight:400}
  .hs3-ratio{flex-direction:row;flex-wrap:wrap;justify-content:flex-end;text-align:right}
  .hs3-ratio em{width:100%;text-align:right}
}
.viz-root:not(#_) .hs3-r>summary{padding:10px 14px!important;margin:0!important;min-height:0!important;color:var(--text-primary);text-indent:0;border:0}
.viz-root:not(#_) .hs3-r{margin:0;padding:0}
.viz-root:not(#_) .hs3-r>summary::before{content:none}
.viz-root:not(#_) .hs3-v{color:var(--text-primary)}
.viz-root:not(#_) .hs3-chart .cl-leg i.hs3-lg-b{display:inline-block;width:12px;height:10px;border:0;border-radius:2px;background:var(--brand-navy)}
.viz-root:not(#_) .hs3-chart .cl-leg i.hs3-lg-o{display:inline-block;width:16px;height:0;border-top:2.5px solid var(--text-primary);background:none}
.hs3-ch{margin-bottom:6px}
.hs3-last{font-size:var(--fs-small);color:var(--text-secondary);margin-bottom:14px}
.hs3-last b{color:var(--text-primary);font-variant-numeric:tabular-nums}.hs3-last b.over{color:var(--critical)}
@media(max-width:759px){.viz-root:not(#_) .hs3-r>summary{padding:12px}}
/* ===== 2026-10 第一組：今日結論白底、本期變化精簡、選舉兩欄、全站收合 v2 ===== */
/* 今日結論：白底＋左側深藍粗線（使用者：深藍底太不協調） */
.viz-root:not(#_) .hm-hero{border-top:1px solid var(--border)}
.viz-root:not(#_) .hm-band{background:var(--surface-1);color:var(--text-primary);padding:22px 20px 20px 22px;
  border-left:5px solid var(--brand-navy);border-bottom:1px solid var(--grid)}
.viz-root:not(#_) .hm-band::after{display:none}
.viz-root:not(#_) .hm-kick{color:var(--brand-ink);font-weight:700}
.viz-root:not(#_) .hm-band h2{color:var(--brand-ink)}
.viz-root:not(#_) .hm-verdict{border-color:var(--brand-ink);background:transparent}
.viz-root:not(#_) .hm-verdict b{color:var(--brand-ink)}
.viz-root:not(#_) .hm-key{color:var(--text-primary)}
.viz-root:not(#_) .hm-next{color:var(--text-primary);border-top-color:var(--grid)}
.viz-root:not(#_) .hm-next span{color:var(--muted)}
.viz-root:not(#_) .hm-next b{color:var(--brand-ink)}
.viz-root:not(#_) .hm-next small{color:var(--text-secondary)}
.viz-root:not(#_) .hm-next .hm-bar{background:var(--grid)}
/* 本期變化 v2 */
.hm-c2-h{display:grid;gap:8px;margin:0 0 6px}
.viz-root:not(#_) .hm-c2-h p{margin:0;display:flex;flex-wrap:wrap;align-items:baseline;gap:4px 12px}
.hm-c2-h p b{font-size:var(--fs-h3);font-weight:700;color:var(--text-primary)}
.hm-c2-h p span{font-size:var(--fs-small);color:var(--muted)}
.hm-c2-bar{display:flex;gap:2px;height:8px;border-radius:4px;overflow:hidden;max-width:520px}
.hm-c2-bar i,.hm-c2-lg i,.hm-c2-d{background:var(--muted-bar)}
.hm-c2-bar i.dovish,.hm-c2-lg i.dovish,.hm-c2-d.dovish{background:var(--series-1)}
.hm-c2-bar i.hawkish,.hm-c2-lg i.hawkish,.hm-c2-d.hawkish{background:var(--serious)}
.hm-c2-lg{display:flex;flex-wrap:wrap;gap:4px 16px;font-size:var(--fs-small);color:var(--text-secondary)}
.hm-c2-lg span{display:inline-flex;align-items:center;gap:6px}
.hm-c2-lg i{width:8px;height:8px;border-radius:2px;display:inline-block}
.viz-root:not(#_) ul.hm-c2{list-style:none;margin:8px 0 0;padding:0}
.viz-root:not(#_) .hm-c2 li{display:grid;grid-template-columns:8px 44px minmax(0,1fr);gap:10px;align-items:baseline;
  padding:10px 0;border-top:1px solid var(--grid);font-size:var(--fs-body);line-height:1.6;color:var(--text-primary)}
.hm-c2 li:first-child{border-top:0}
.hm-c2-d{width:8px;height:8px;border-radius:50%;display:inline-block;transform:translateY(-1px)}
.hm-c2-sc .hm-c2-d{background:var(--brand-orange)}
.hm-c2-sc .hm-c2-t{font-weight:700}
.hm-c2-m{font-size:var(--fs-small);color:var(--muted);white-space:nowrap}
.hm-c2-t{min-width:0}
.hm-c2-gs{display:grid;gap:14px;padding:4px 0 6px}
@media(min-width:760px){.hm-c2-gs{grid-template-columns:repeat(3,minmax(0,1fr));gap:22px}}
.hm-c2-gh{display:flex;align-items:center;gap:8px;font-size:var(--fs-small);font-weight:700;color:var(--text-secondary);padding-bottom:4px}
.viz-root:not(#_) .hm-c2-g .hm-c2 li{grid-template-columns:44px minmax(0,1fr);font-size:var(--fs-small);padding:7px 0}
.hm-c2-g .hm-c2 li>.hm-c2-d{display:none}
/* 選舉：兩院永遠左右兩欄（手機也是），字級縮小 */
.viz-root:not(#_) .el2-chs{grid-template-columns:1fr 1fr}
.viz-root:not(#_) .el2-ch+.el2-ch{border-top:0;border-left:1px solid var(--grid)}
.viz-root:not(#_) .el2-ch b{font-size:22px}
@media(max-width:759px){
  .viz-root:not(#_) .el2-ch{grid-template-columns:1fr;grid-template-areas:"k" "v" "m";padding:12px 12px}
  .viz-root:not(#_) .el2-ch b{font-size:18px}
  .viz-root:not(#_) .el2-ch .el-spark{display:none}
  .viz-root:not(#_) .el-card .home-zone-num{white-space:nowrap}}
@media(min-width:760px){.viz-root:not(#_) .el-mapwrap{max-width:760px;margin-left:auto;margin-right:auto}}

/* ---- 全站收合 v2 ----
   卡片級（.sect）：見下方「區塊目錄」。
   卡內（各種 details）：整列＋上方細線，左邊標題（可帶灰色結論），右邊細箭頭；
   全部同一套，不再有 ▸ 前綴、「展開 ▾」字樣、？圓章、膠囊底色。 */
.viz-root:not(#_) .sect-tools{justify-content:flex-end;gap:0;margin:10px 0 0}
.viz-root:not(#_) .sect-tools button{border:0;background:none;padding:8px 10px;font-size:var(--fs-small);color:var(--muted);border-radius:6px}
.viz-root:not(#_) .sect-tools button+button{border-left:1px solid var(--grid);border-radius:0}
.viz-root:not(#_) .sect-tools button:hover{color:var(--text-primary)}
.viz-root:not(#_) :is(.f-more,details[data-m-collapse],.k-more,.l-more,.el-more,.hm-modx,.hm-new,.foot-fold,.teach,
  .full-detail,.focus-evidence,.home-brief-more,.el-how,.sig-rest,.hm-c2-more,.hm-more details){
  background:none;border-radius:0;border:0;border-top:1px solid var(--grid);margin-top:10px;padding:0;box-shadow:none}
.viz-root:not(#_) :is(.f-more,details[data-m-collapse],.k-more,.l-more,.el-more,.hm-modx,.hm-new,.foot-fold,.teach,
  .full-detail,.focus-evidence,.home-brief-more,.el-how,.sig-rest,.hm-c2-more,.hm-more details)>summary{
  display:flex;align-items:center;flex-wrap:nowrap;gap:10px;min-height:44px;box-sizing:border-box;padding:10px 2px 10px 0;margin:0;
  text-indent:0;list-style:none;font-size:var(--fs-small);font-weight:600;color:var(--text-secondary);line-height:1.55;
  background:none;border:0;border-radius:0}
.viz-root:not(#_) :is(.f-more,details[data-m-collapse],.k-more,.l-more,.el-more,.hm-modx,.hm-new,.foot-fold,.teach,
  .full-detail,.focus-evidence,.home-brief-more,.el-how,.sig-rest,.hm-c2-more,.hm-more details)>summary::before{content:none;display:none}
.viz-root:not(#_) :is(.f-more,details[data-m-collapse],.k-more,.l-more,.el-more,.hm-modx,.hm-new,.foot-fold,.teach,
  .full-detail,.focus-evidence,.home-brief-more,.el-how,.sig-rest,.hm-c2-more,.hm-more details)>summary::after{
  content:"";flex:none;margin-left:auto;width:7px;height:7px;border:solid currentColor;border-width:0 1.6px 1.6px 0;
  transform:translateY(-2px) rotate(45deg);transition:transform .2s ease;color:var(--muted)}
.viz-root:not(#_) :is(.f-more,details[data-m-collapse],.k-more,.l-more,.el-more,.hm-modx,.hm-new,.foot-fold,.teach,
  .full-detail,.focus-evidence,.home-brief-more,.el-how,.sig-rest,.hm-c2-more,.hm-more details)[open]>summary::after{
  content:"";transform:translateY(2px) rotate(-135deg)}
.viz-root:not(#_) :is(.f-more,details[data-m-collapse],.k-more,.l-more,.el-more,.hm-modx,.hm-new,.foot-fold,.teach,
  .full-detail,.focus-evidence,.home-brief-more,.el-how,.sig-rest,.hm-c2-more,.hm-more details)>summary:hover{color:var(--text-primary)}
.viz-root:not(#_) :is(.f-more,details[data-m-collapse],.k-more,.l-more,.el-more,.hm-modx,.hm-new,.foot-fold,.teach,
  .full-detail,.focus-evidence,.home-brief-more,.el-how,.sig-rest,.hm-c2-more,.hm-more details)[open]{padding-bottom:8px}
.viz-root:not(#_) details.hm-new.hm-new>summary{display:block}
.viz-root:not(#_) details.hm-new.hm-new>summary::after{display:inline-block;margin-left:10px;vertical-align:middle}
.viz-root:not(#_) details.hm-modx.hm-modx>summary{flex-wrap:wrap}
.hm-modx-k{white-space:nowrap}
.viz-root:not(#_) .el2-ch{align-content:start;align-items:start}
.viz-root:not(#_) .el2-k{display:flex;justify-content:space-between;align-items:baseline;gap:8px}
.el2-d1{font-style:normal;font-weight:500;font-size:var(--fs-micro);color:var(--muted);white-space:nowrap}

/* ---- 區塊目錄（收合 v2，方案 A）----
   連續收合的區塊併成一張「目錄」卡：細線分隔、左側橘色序號、右側 › 。
   點開的那一區自己獨立成完整卡片；序號以整頁順序計（開著的也算）。 */
.viz-root{counter-reset:sx}
.viz-root:not(#_) .sect>summary h2::before{counter-increment:sx;content:counter(sx,decimal-leading-zero);
  color:var(--brand-orange);font-size:12px;font-weight:700;letter-spacing:.08em;margin-right:10px;vertical-align:2px;
  font-variant-numeric:tabular-nums}
.viz-root:not(#_) .sect-sum{padding-left:30px}
.viz-root:not(#_) .grid>details.sect:not([open]){margin-top:0;box-shadow:none}
.viz-root:not(#_) .grid:has(>.sect:not([open]))+.grid:has(>.sect:not([open])){margin-top:0}
.viz-root:not(#_) .grid:has(>.sect:not([open]))+.grid:has(>.sect:not([open]))>.sect{border-top:1px solid var(--grid);
  border-top-left-radius:0;border-top-right-radius:0}
.viz-root:not(#_) .grid:has(>.sect:not([open])):has(+.grid>.sect:not([open]))>.sect{border-bottom:0;
  border-bottom-left-radius:0;border-bottom-right-radius:0}
.viz-root:not(#_) .sect:not([open])>summary{padding-top:14px;padding-bottom:14px;border-radius:0}
.viz-root:not(#_) .sect:not([open])>summary h2{font-size:15.5px}
.viz-root:not(#_) .sect>summary::after{content:"";width:20px;height:20px;border:0;border-radius:0;align-self:center;grid-row:1/span 2;background:var(--muted);-webkit-mask:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 12 12'%3E%3Cpath d='M3 4.5 6 7.5 9 4.5' fill='none' stroke='%23000' stroke-width='1.6' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E") center/14px no-repeat;mask:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 12 12'%3E%3Cpath d='M3 4.5 6 7.5 9 4.5' fill='none' stroke='%23000' stroke-width='1.6' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E") center/14px no-repeat;transform:rotate(-90deg);transition:transform .2s ease}
.viz-root:not(#_) .sect[open]>summary::after{content:"";transform:rotate(180deg)}
.viz-root:not(#_) .sect>summary:hover::after{border:0}
/* ---- 上一頁／下一頁：一條左右兩半的導覽列 ---- */
.viz-root:not(#_) .pagenav{display:grid;grid-template-columns:1fr 1fr;gap:0;margin-top:22px;
  border:1px solid var(--border);border-radius:13px;overflow:hidden;background:var(--surface-1)}
.viz-root:not(#_) .pagenav a{display:grid;grid-template-columns:auto 1fr;grid-template-areas:"ar k" "ar b";column-gap:12px;row-gap:2px;
  align-items:center;padding:14px 18px;border:0;border-radius:0;background:none;text-decoration:none;font-size:var(--fs-small);min-height:64px;box-sizing:border-box;
  max-width:none;min-width:0;width:100%}
.viz-root:not(#_) .pagenav .pn-next{grid-template-columns:1fr auto;grid-template-areas:"k ar" "b ar";text-align:right;
  border-left:1px solid var(--grid);margin:0;align-items:center}
.viz-root:not(#_) .pagenav .pn-nil+.pn-next{border-left:1px solid var(--grid)}
.viz-root:not(#_) .pagenav .pn-prev{border-right:1px solid var(--grid)}
.viz-root:not(#_) .pagenav .pn-prev+.pn-next{border-left:0}
.pagenav .pn-nil{display:none}
.viz-root:not(#_) .pagenav:has(.pn-nil) a{grid-column:1/-1;border:0}
.viz-root:not(#_) .pagenav a::before{content:"";grid-area:ar;width:18px;height:18px;background:var(--brand-ink);-webkit-mask:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 12 12'%3E%3Cpath d='M7.5 3 4.5 6 7.5 9' fill='none' stroke='%23000' stroke-width='1.6' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E") center/14px no-repeat;mask:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 12 12'%3E%3Cpath d='M7.5 3 4.5 6 7.5 9' fill='none' stroke='%23000' stroke-width='1.6' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E") center/14px no-repeat;transition:transform .15s ease}
.viz-root:not(#_) .pagenav .pn-next::before{transform:scaleX(-1)}
.viz-root:not(#_) .pagenav .pn-prev:hover::before{transform:translateX(-3px)}
.viz-root:not(#_) .pagenav .pn-next:hover::before{transform:scaleX(-1) translateX(-3px)}
.pagenav .pn-k{grid-area:k;color:var(--muted);font-size:var(--fs-micro)}
.viz-root:not(#_) .pagenav a b{grid-area:b;font-size:var(--fs-body);font-weight:700;color:var(--brand-ink)}
.pagenav a b em{font-style:normal;color:var(--brand-orange);font-size:12px;letter-spacing:.06em;margin-right:8px;font-variant-numeric:tabular-nums}
.viz-root:not(#_) .pagenav a:hover{background:var(--surface-2)}

/* ---- 失業原因 v2：比重較一年前的正負橫條 ---- */
.us2{margin-top:10px}
.us2-r{display:grid;grid-template-columns:minmax(0,1.3fr) 72px minmax(0,2fr) 48px;gap:12px;align-items:center;padding:10px 0;border-top:1px solid var(--grid)}
.us2-r:first-child{border-top:0}
.us2-h{padding:4px 0 6px;font-size:var(--fs-micro);color:var(--muted)}
.us2-h span:nth-child(2){text-align:right}.us2-hb{text-align:center}
.us2-n b{display:block;font-size:var(--fs-body);font-weight:600;color:var(--text-primary)}
.us2-n small{font-size:var(--fs-micro);color:var(--muted)}
.us2-s{text-align:right;font-size:var(--fs-body);font-variant-numeric:tabular-nums;color:var(--text-secondary)}
.us2-bar{position:relative;height:14px;border-radius:3px}
.us2-bar::after{content:"";position:absolute;left:50%;top:-3px;bottom:-3px;width:1px;background:var(--text-secondary)}
.us2-noise{position:absolute;top:0;bottom:0;background:var(--surface-2);border-radius:2px}
.us2-bar i{position:absolute;top:2px;bottom:2px;background:var(--muted-bar)}
.us2-bar i.bad{background:var(--serious)}.us2-bar i.good{background:var(--good)}
.us2-v{text-align:right;font-weight:700;font-size:var(--fs-body);font-variant-numeric:tabular-nums}
.us2-lg{display:flex;flex-wrap:wrap;gap:4px 16px;margin-top:8px;font-size:var(--fs-micro);color:var(--text-secondary)}
.us2-lg span{display:inline-flex;align-items:center;gap:6px}
.us2-lg i{width:10px;height:10px;border-radius:2px;background:var(--muted-bar)}
.us2-lg i.bad{background:var(--serious)}.us2-lg i.good{background:var(--good)}.us2-lg i.noise{background:var(--surface-2);border:1px solid var(--grid)}
@media(max-width:759px){.us2-r{grid-template-columns:minmax(0,1fr) 58px 44px;row-gap:6px}
  .us2-bar{grid-column:1/-1;grid-row:2}.us2-hb{display:none}}

/* ---- 科技巨頭：資料時效／近期發債／方法 v2 ---- */
.hs4-sec{padding:12px 0 4px;border-top:1px solid var(--grid)}
.hs4-sec:first-of-type{border-top:0;padding-top:4px}
.hs4-h{font-size:var(--fs-small);font-weight:700;color:var(--brand-ink);margin:0 0 8px}
.viz-root:not(#_) .hs4-lead{font-size:var(--fs-body);color:var(--text-primary);margin:0 0 8px;line-height:1.6}
.viz-root:not(#_) .hs4-n{font-size:var(--fs-micro);color:var(--muted);margin:6px 0 0;line-height:1.6}
.viz-root:not(#_) table.hs4-t{width:100%;border-collapse:collapse;font-size:var(--fs-small)}
.viz-root:not(#_) .hs4-t th{font-size:var(--fs-micro);font-weight:600;color:var(--muted);text-align:left;padding:6px 10px 6px 0;border-bottom:1px solid var(--grid);white-space:nowrap}
.viz-root:not(#_) .hs4-t td{text-align:left;padding:8px 10px 8px 0;border-bottom:1px solid var(--grid);color:var(--text-primary);vertical-align:top;white-space:nowrap}
.viz-root:not(#_) .hs4-t tr:last-child td{border-bottom:0}
.viz-root:not(#_) .hs4-t :is(td,th).num{text-align:right;font-variant-numeric:tabular-nums}
.hs4-t td.pend{color:var(--muted)}
.hs4-t td small{display:block;font-size:var(--fs-micro);color:var(--muted)}
.hs4-st{display:inline-flex;align-items:baseline;gap:6px;color:var(--text-secondary);white-space:normal}
.hs4-st i{flex:none;transform:translateY(-1px)}
.hs4-st small{display:block;font-size:var(--fs-micro);color:var(--muted)}
.hs4-t a{color:var(--series-1)}
.hs4-st i{width:7px;height:7px;border-radius:50%;background:var(--muted-bar)}
.hs4-st.ok i{background:var(--good)}.hs4-st.wait i{background:var(--brand-orange)}
.viz-root:not(#_) ul.hs4-m{margin:0;padding-left:18px;font-size:var(--fs-small);line-height:1.7;color:var(--text-secondary)}
.hs4-m>li{margin-bottom:6px}
.hs4-m ul{margin:4px 0 0;padding-left:16px}
.hs4 .src{margin-top:8px}

/* ---- 科技巨頭 v3：資料時效／近期發債的清單（桌機欄位、手機兩行） ---- */
.hs5{display:grid;max-width:760px}
.hs5-r{display:grid;align-items:baseline;column-gap:14px;padding:9px 0;border-top:1px solid var(--grid);font-size:var(--fs-small);color:var(--text-primary)}
.hs5-r:first-child{border-top:0}
.hs5-hd{font-size:var(--fs-micro);color:var(--muted);padding:2px 0 6px}
.hs5-n{font-weight:600;color:var(--text-primary);min-width:0}
.hs5-m{display:contents}
.hs5-m em{display:none;font-style:normal}
.hs5-f .hs5-r{grid-template-columns:minmax(120px,1fr) 80px 150px minmax(0,1.6fr)}
.hs5-f .hs5-m>span:nth-child(-n+2){text-align:right;font-variant-numeric:tabular-nums}
.hs5-o .hs5-r{grid-template-columns:56px minmax(120px,1fr) minmax(80px,.8fr) 72px minmax(110px,1fr)}
.hs5-hd .hs5-n{font-weight:400;color:var(--muted)}
.hs5-o .hs5-r>*,.hs5-o .hs5-m>span{order:2}
.hs5-o .hs5-m>span:first-child{order:0}.hs5-o .hs5-r>.hs5-n{order:1}
.hs5-a{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}
.hs5-a small{display:block;font-size:var(--fs-micro);color:var(--muted)}
.hs5-a.pend{color:var(--muted)}
.hs5 a{color:var(--series-1)}
.hs4-st small{display:inline;margin-left:6px}
@media(max-width:759px){
  .hs5-hd{display:none}
  .viz-root:not(#_) .hs5-r{grid-template-columns:minmax(0,1fr) auto;row-gap:2px;padding:10px 0}
  .hs5-m{display:flex;flex-wrap:wrap;gap:0 10px;grid-column:1/-1;grid-row:2;font-size:var(--fs-micro);color:var(--muted)}
  .hs5-m em{display:inline;margin-right:4px}
  .hs5-f .hs5-m>span:nth-child(-n+2){text-align:left}
  .hs5-o .hs5-r>*,.hs5-o .hs5-r .hs5-m>span,.hs5-o .hs5-r>.hs5-n,.hs5-o .hs5-m>span:first-child{order:0}
  .hs4-st{justify-self:end;text-align:right}
  .hs4-st small{display:block;margin:0}
}
/* 科技巨頭：手機精簡（使用者：手機上字太多） */
@media(max-width:759px){
  .hs3-q small,.hs3-last{display:none}
  .viz-root:not(#_) .hs3-r>summary{display:flex!important;flex-wrap:wrap;align-items:baseline;gap:4px 12px;padding:11px 12px!important}
  .hs3-r>summary .hs3-n{flex:1 1 auto;flex-direction:row;align-items:baseline;gap:8px}
  .hs3-r>summary .hs3-ratio{flex:0 0 auto;flex-wrap:nowrap}
  .hs3-r>summary .hs3-ratio em{display:none}
  .hs3-r>summary .hs3-v:not(.hs3-ratio){flex-direction:row;gap:4px;font-size:var(--fs-micro);font-weight:600;color:var(--text-secondary)}
  .hs3-r>summary .hs3-v:not(.hs3-ratio) em{display:inline;font-size:var(--fs-micro);color:var(--muted)}
  .hs3-r>summary .hs3-n{order:0}.hs3-r>summary .hs3-ratio{order:1}
  .hs3-r>summary .hs3-br{display:block;order:2;flex-basis:100%;height:0}
  .hs3-r>summary .hs3-v:not(.hs3-ratio){order:3}
}
.hs3-br{display:none}

/* 失業原因：手機單列（名稱｜橫條｜數字），人數藏起來 */
.us2-sm{display:none}
.viz-root:not(#_) p.us2-lt.us2-lt{font-size:var(--fs-micro);color:var(--muted);margin:6px 0 0}
@media(max-width:759px){
  .us2-h{display:none}
  .viz-root:not(#_) .us2-r{grid-template-columns:minmax(0,1fr) 40% 40px;row-gap:0;gap:10px;padding:9px 0}
  .us2-s{display:none}
  .viz-root:not(#_) .us2-bar{grid-column:auto;grid-row:auto}
  .us2-sm{display:inline}.us2-pp{display:none}
  .us2-n small{white-space:nowrap}
}

/* ===== 第三組：長端組成 v3、殖利率曲線 v2 ===== */
.le3-tr{border:1px solid var(--border);border-left:4px solid var(--brand-navy);border-radius:10px;padding:12px 14px;margin:2px 0 14px}
.le3-tr.noise{border-left-color:var(--muted-bar)}.le3-tr.turn{border-left-color:var(--brand-orange)}
.viz-root:not(#_) .le3-tr p{margin:0;font-size:var(--fs-body);line-height:1.65;color:var(--text-primary)}
.le3-trc{display:flex;flex-wrap:wrap;gap:6px 18px;margin-top:8px;font-size:var(--fs-small);color:var(--text-secondary)}
.le3-trc em{font-style:normal;color:var(--muted);margin-right:6px}
.viz-root:not(#_) .le3-how p{font-size:var(--fs-small);line-height:1.7;color:var(--text-secondary);margin:0 0 8px}
.le3-head{margin-bottom:12px}
.le3-st{border:1px solid var(--border);border-radius:12px;overflow:hidden}
.le3-sr{display:grid;grid-template-columns:minmax(0,1.3fr) 70px 64px minmax(0,1fr) 64px minmax(0,1fr);gap:10px;align-items:center;padding:11px 14px;border-top:1px solid var(--grid)}
.le3-sr:first-child{border-top:0}
.le3-sh{font-size:var(--fs-micro);color:var(--muted);padding:8px 14px}
.le3-sk b{display:block;font-size:var(--fs-body);color:var(--brand-ink)}
.le3-sk small{font-size:var(--fs-micro);color:var(--muted)}
.le3-sv{font-size:var(--fs-h3);font-weight:700;font-variant-numeric:tabular-nums;color:var(--text-primary)}
.le3-sv small{font-size:var(--fs-micro);font-weight:400;color:var(--muted);margin-left:2px}
.le3-sd{font-variant-numeric:tabular-nums;font-weight:600;color:var(--text-primary);text-align:right}
.le3-sd em{display:none;font-style:normal}
.le3-rg{display:inline-flex;flex-direction:column;font-size:var(--fs-small);font-weight:700}
.le3-rg small{font-size:var(--fs-micro);font-weight:400;color:var(--muted)}
.le3-rg.bear{color:var(--serious)}.le3-rg.bull{color:var(--series-1)}.le3-rg.tw{color:var(--brand-orange)}.le3-rg.fl{color:var(--muted)}
.le3-sms{display:grid;gap:14px;margin-top:16px}
@media(min-width:760px){.le3-sms{grid-template-columns:repeat(3,minmax(0,1fr))}}
.le3-smh{display:flex;justify-content:space-between;align-items:baseline;margin-bottom:4px}
.le3-smh b{font-size:var(--fs-small);color:var(--brand-ink)}.le3-smh span{font-size:var(--fs-micro);color:var(--muted)}
.cl-xm{position:relative;height:18px;margin-left:38px}
.cl-xm span{position:absolute;top:3px;transform:translateX(-50%);font-size:11px;color:var(--muted);white-space:nowrap}
.viz-root:not(#_) .le3-cap{font-size:var(--fs-micro);color:var(--muted);margin:8px 0 0;line-height:1.6}
.viz-root:not(#_) .le3-why{font-size:var(--fs-body);line-height:1.7;margin:0 0 6px;color:var(--text-primary)}
.le3-dt{margin-top:6px;max-width:520px}
.le3-dr{display:grid;grid-template-columns:minmax(0,1fr) 64px 64px;gap:8px;padding:6px 0;border-top:1px solid var(--grid);font-size:var(--fs-small);white-space:pre}
.le3-dr span:nth-child(n+2){text-align:right;font-variant-numeric:tabular-nums;font-weight:600}
.le3-dh{border-top:0;font-size:var(--fs-micro);color:var(--muted)}.le3-dh span{font-weight:400!important}
.le3-dg{font-size:var(--fs-micro);font-weight:700;color:var(--brand-ink);padding:8px 0 2px}
.le3-ft{display:grid;border:1px solid var(--border);border-radius:12px;overflow:hidden}
.le3-fr{display:grid;grid-template-columns:minmax(0,1.2fr) 70px minmax(0,1.3fr) minmax(0,.9fr);gap:10px;align-items:baseline;padding:10px 14px;border-top:1px solid var(--grid);font-size:var(--fs-small)}
.le3-fr:first-child{border-top:0}
.le3-fr b{font-size:var(--fs-body);font-variant-numeric:tabular-nums;text-align:right}
.le3-fg.up{color:var(--serious)}.le3-fg.dn{color:var(--series-1)}
.le3-fw{color:var(--muted);text-align:right}
.le3-mt{margin-top:10px;font-size:var(--fs-small)}
.le3-mt span{font-weight:700;color:var(--brand-ink)}
.viz-root:not(#_) .le3-mt p{margin:4px 0 0;line-height:1.7;color:var(--text-secondary)}
.viz-root:not(#_) ul.le3-ol{list-style:none;margin:0;padding:0}
.viz-root:not(#_) .le3-ol li{display:grid;grid-template-columns:44px 1fr;gap:10px;padding:8px 0;border-top:1px solid var(--grid);font-size:var(--fs-small);line-height:1.65;color:var(--text-secondary)}
.le3-ol li:first-child{border-top:0}
.le3-ol li b{color:var(--muted)}.le3-ol li.hot b{color:var(--brand-orange)}.le3-ol li.hot{color:var(--text-primary)}
@media(max-width:759px){
  .le3-sh{display:none}
  .viz-root:not(#_) .le3-sr{grid-template-columns:minmax(0,1fr) auto;grid-template-areas:"k v" "w wr" "m mr";row-gap:4px}
  .le3-sk{grid-area:k}.le3-sv{grid-area:v;text-align:right}
  .le3-sd:nth-of-type(3){grid-area:w}.le3-sd:nth-of-type(5){grid-area:m}
  .le3-sd{text-align:left;font-size:var(--fs-small)}.le3-sd em{display:inline;color:var(--muted);margin-right:6px;font-weight:400}
  .le3-rg{flex-direction:row;gap:6px;align-items:baseline;justify-self:end}
  .le3-sr>.le3-rg:nth-of-type(4){grid-area:wr}.le3-sr>.le3-rg:nth-of-type(6){grid-area:mr}
  .viz-root:not(#_) .le3-fr{grid-template-columns:minmax(0,1fr) auto;row-gap:2px}
  .le3-fg,.le3-fw{font-size:var(--fs-micro)}.le3-fw{text-align:right}
}

/* ---- 殖利率曲線：自選期間 ---- */
#cw-t1:checked~.tabp.p1,#cw-t2:checked~.tabp.p2{display:block}
.cw-tabs .tabp{margin-top:10px}
.cw-ctl{display:flex;flex-wrap:wrap;gap:6px}
.cw-btn{font:inherit;font-size:var(--fs-small);font-weight:600;padding:7px 12px;border-radius:999px;border:1px solid var(--border);
  background:var(--surface-1);color:var(--text-secondary);cursor:pointer;min-height:36px}
.cw-btn:hover{color:var(--text-primary);border-color:var(--text-secondary)}
.cw-btn.on{background:var(--brand-navy);border-color:var(--brand-ink);color:#fff}
.cw-cust{display:flex;flex-wrap:wrap;gap:8px 16px;margin-top:10px;font-size:var(--fs-small);color:var(--text-secondary)}
.cw-cust[hidden]{display:none}
.cw-cust input{font:inherit;font-size:var(--fs-small);padding:6px 8px;border:1px solid var(--border);border-radius:8px;background:var(--surface-1);color:var(--text-primary);margin-left:6px}
.viz-root:not(#_) .cw-text{margin:12px 0 4px}
.viz-root:not(#_) .cw-text p{margin:0 0 4px;font-size:var(--fs-body);line-height:1.7;font-weight:500}
.viz-root:not(#_) .cw-text p:first-child{font-weight:700}
.cw-blk{margin-top:14px}
.cw-h{font-size:var(--fs-small);font-weight:700;color:var(--muted);margin-bottom:6px}
.cw-dr{display:grid;grid-template-columns:48px minmax(0,1fr) 110px;gap:12px;align-items:center;padding:7px 0}
.cw-dk{font-size:var(--fs-small);font-weight:700;color:var(--brand-ink)}
.cw-dt{position:relative;height:16px}
.cw-dt::before{content:"";position:absolute;left:0;right:0;top:50%;border-top:1px solid var(--grid)}
.cw-dl{position:absolute;top:calc(50% - 1.5px);height:3px;background:var(--muted-bar)}
.cw-dl.up{background:var(--serious)}.cw-dl.dn{background:var(--series-1)}
.cw-da,.cw-dz{position:absolute;top:50%;width:11px;height:11px;border-radius:50%;transform:translate(-50%,-50%);box-shadow:0 0 0 2px var(--surface-1)}
.cw-da{background:var(--surface-1);border:2px solid var(--muted-bar);box-sizing:border-box}
.cw-dz.up{background:var(--serious)}.cw-dz.dn{background:var(--series-1)}
.cw-dv{text-align:right;font-weight:700;font-variant-numeric:tabular-nums;font-size:var(--fs-body)}
.cw-dv.up{color:var(--serious)}.cw-dv.dn{color:var(--series-1)}
.cw-dv small{display:block;font-size:var(--fs-micro);font-weight:400;color:var(--muted)}
.cw-st{border:1px solid var(--border);border-radius:12px;overflow:hidden;max-width:640px}
.cw-db{max-width:760px}
.cw-sr{display:grid;grid-template-columns:56px minmax(0,1fr) 56px minmax(0,1fr);gap:10px;align-items:center;padding:9px 14px;border-top:1px solid var(--grid)}
.cw-sr:first-child{border-top:0}
.cw-sk{font-weight:700;color:var(--brand-ink);font-size:var(--fs-body)}
.cw-sab{font-variant-numeric:tabular-nums;color:var(--text-secondary);font-size:var(--fs-small)}
.cw-sd{text-align:right;font-weight:700;font-variant-numeric:tabular-nums}
.cl-band{position:absolute;top:0;bottom:0;background:rgba(230,113,67,.12);border-left:1px solid rgba(230,113,67,.5);border-right:1px solid rgba(230,113,67,.5);pointer-events:none}
@media(max-width:759px){
  .cw-dr{grid-template-columns:40px minmax(0,1fr) 92px;gap:8px}
  .cw-sr{grid-template-columns:48px minmax(0,1fr) 44px auto;padding:9px 10px;gap:8px}
  .cw-sr .le3-rg{flex-direction:column;align-items:flex-end;text-align:right}
}


/* Shared chart selection: persistent readout below the chart on every device. */
.chart-inspector{position:absolute;inset:0;z-index:3;touch-action:pan-y;cursor:crosshair}
.chart-inspector:focus-visible{outline:2px solid var(--brand-orange);outline-offset:3px}
.chart-cursor{position:absolute;top:0;bottom:0;border-left:1px solid var(--text-secondary);pointer-events:none;z-index:4}
.chart-selected-dot{position:absolute;width:9px;height:9px;border-radius:50%;transform:translate(-50%,-50%);box-shadow:0 0 0 2px var(--surface-1);pointer-events:none;z-index:4}
.chart-readout{margin-top:10px;padding:10px 12px;border:1px solid var(--border);border-radius:10px;background:var(--surface-2);font-size:var(--fs-small);line-height:1.6;min-height:40px;box-sizing:border-box;color:var(--text-secondary)}
.chart-readout strong{display:block;color:var(--text-primary);font-size:var(--fs-small)}
.chart-readout-values{display:flex;flex-wrap:wrap;gap:4px 18px}
.chart-readout-values span{display:inline-flex;align-items:center;gap:5px;font-variant-numeric:tabular-nums}
.chart-readout-values i{width:8px;height:8px;border-radius:50%;flex:none}
.chart-readout-values b{color:var(--text-primary);font-weight:700}
[data-chart-selected]{outline:1px solid var(--brand-orange);outline-offset:-1px}
@media(max-width:759px){.chart-readout-values{display:grid;grid-template-columns:1fr;gap:3px}.chart-readout-values span{justify-content:space-between}.chart-readout-values i{margin-right:0}}


/* Curve summary: explicit values before explanations. */
.fwd-date{grid-column:1/-1;color:var(--muted);font-size:var(--fs-micro);line-height:1.6}
/* 所選期間的利率用三列比較，手機與桌機使用相同表格。 */
.cw-db{display:block;max-width:none}
.viz-root:not(#_) .cw-compact{width:100%;table-layout:fixed;border-collapse:collapse;margin:0;font-variant-numeric:tabular-nums;font-size:var(--fs-body)}
.viz-root:not(#_) .cw-compact th,.viz-root:not(#_) .cw-compact td{padding:9px 12px;line-height:1.6;text-align:right;border:0;background:transparent;white-space:nowrap}
.viz-root:not(#_) .cw-compact thead th{font-size:var(--fs-small);font-weight:500;color:var(--muted);background:var(--surface-2)}
.viz-root:not(#_) .cw-compact th:first-child{ text-align:left }
.viz-root:not(#_) .cw-compact tbody th,.viz-root:not(#_) .cw-compact tbody td{font-weight:600;color:var(--text-primary)}
.viz-root:not(#_) .cw-compact tbody tr+tr>*{border-top:1px solid var(--grid)}
.viz-root:not(#_) .cw-compact td.up{color:var(--serious)}
.viz-root:not(#_) .cw-compact td.dn{color:var(--series-1)}
.viz-root:not(#_) .cw-compact td.flat{color:var(--muted)}
.viz-root:not(#_) .cw-text{margin-top:16px}
.viz-root:not(#_) .cw-headline{padding:0;background:transparent;border-radius:0;font-weight:700;line-height:1.7;margin:20px 0 12px}
.cw-panels{display:grid;gap:12px;margin-top:12px}
@media(min-width:1000px){.cw-panels{grid-template-columns:repeat(3,minmax(0,1fr));align-items:start}}
.cw-panel,.future-policy,.future-bonds{border:1px solid var(--border);border-radius:12px;padding:16px;background:var(--surface-1)}
.viz-root:not(#_) .cw-panel h3,.viz-root:not(#_) .future-policy h3,.viz-root:not(#_) .future-bonds h3{margin:0 0 8px;font-size:var(--fs-body);color:var(--text-primary)}
.viz-root:not(#_) .cw-panel p,.viz-root:not(#_) .future-policy p,.viz-root:not(#_) .future-bonds p{font-size:var(--fs-small);font-weight:400;line-height:1.7;margin:6px 0 10px}
.cw-metrics{margin:10px 0}
.cw-metrics>div{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:8px 14px;padding:9px 0;border-top:1px solid var(--grid);align-items:baseline}
.cw-metrics dt{font-size:var(--fs-small);color:var(--text-secondary)}
.cw-metrics dd{margin:0;text-align:right;font-variant-numeric:tabular-nums;font-size:var(--fs-body)}
.cw-metrics dd small{display:block;font-size:var(--fs-micro);color:var(--muted);font-weight:400;line-height:1.5;overflow-wrap:anywhere}
.cw-panel-note{display:block;color:var(--muted);font-size:var(--fs-micro);line-height:1.7}
.future-policy,.future-bonds{margin-top:12px}
.viz-root:not(#_) .future-bonds .future-headline{font-weight:700;font-size:var(--fs-body)}
.viz-root:not(#_) .fwd-reading{grid-column:1/-1;margin:4px 0 0;font-size:var(--fs-small);color:var(--text-secondary);line-height:1.65}
@media(max-width:759px){.viz-root:not(#_) .cw-compact{font-size:14px}.viz-root:not(#_) .cw-compact th,.viz-root:not(#_) .cw-compact td{padding:8px 4px}.viz-root:not(#_) .cw-compact thead th{font-size:12px}.cw-panel,.future-policy,.future-bonds{padding:14px}.cw-metrics>div{grid-template-columns:minmax(0,1.1fr) minmax(0,1fr)}}

/* ---- 頁尾：資料來源與方法（2026-10 統一） ---- */
.pf{border-top:1px solid var(--border);padding-top:14px}
.pf-top{display:flex;flex-wrap:wrap;gap:4px 16px;font-size:var(--fs-small);color:var(--muted);line-height:1.7}
.pf-top b{color:var(--text-secondary);font-weight:600}
.pf-top a{color:var(--text-secondary)}
.pf-t{display:grid;margin-top:4px}
.pf-r{display:grid;grid-template-columns:minmax(0,1.1fr) minmax(0,1.3fr) minmax(0,.9fr);gap:12px;padding:8px 0;border-top:1px solid var(--grid);font-size:var(--fs-small);color:var(--text-primary);line-height:1.6}
.pf-r:first-child{border-top:0}
.pf-h{font-size:var(--fs-micro);color:var(--muted);padding-bottom:4px}
.pf-r span:last-child{color:var(--text-secondary)}
.viz-root:not(#_) ul.pf-n{margin:10px 0 4px;padding-left:18px;font-size:var(--fs-small);line-height:1.7;color:var(--text-secondary)}
.pf-n li{margin-bottom:4px}
@media(max-width:759px){.pf-h{display:none}
  .pf-r{grid-template-columns:1fr auto;row-gap:0}.pf-r span:first-child{font-weight:600}
  .pf-r span:nth-child(2){grid-column:1/-1;grid-row:2;color:var(--muted);font-size:var(--fs-micro)}
  .pf-r span:nth-child(3){grid-column:2;grid-row:1;font-size:var(--fs-micro);text-align:right}}

/* ===== 夜間模式（2026-10）=====
   預設跟著系統；頁首的切換鈕把選擇存在 localStorage（mgg-theme），
   <html data-theme="dark|light"> 優先於系統設定。
   顏色全部走變數；少數寫死的淺色底在下方逐一改寫。 */
.logo-dk{display:none!important}
.theme-btn{position:relative;width:36px;height:36px;border-radius:50%;border:1px solid var(--border);background:var(--surface-1);
  cursor:pointer;flex:none;margin-left:8px;align-self:center;color:var(--text-secondary)}
.theme-btn i{position:absolute;inset:0;margin:auto;width:16px;height:16px;border-radius:50%;
  box-shadow:inset -5px -2px 0 0 currentColor}
.theme-btn:hover{color:var(--text-primary);border-color:var(--text-secondary)}
@media(prefers-color-scheme:dark){
  :root:not([data-theme="light"]),:root:not([data-theme="light"]) .viz-root{color-scheme:dark;
  --page:#0d1219; --bg:#0d1219; --surface-1:#141b25; --surface-2:#1c2532;
  --text-primary:#e9ecf1; --text-secondary:#b8bfca; --muted:#929baa; --faint:#737c8a;
  --grid:#283242; --baseline:#3d4859; --border:rgba(255,255,255,.12);
  --series-1:#86b6f2; --series-2:#f2a07a; --line-1:#64a7f4; --line-2:#f28c5c;
  --pos:#64a7f4; --neg:#f2706f; --muted-bar:#5e6878;
  --good:#5ccb78; --warning:#e3b552; --serious:#f29a72; --critical:#f47b7b;
  --tint-dov:rgba(100,167,244,.15); --tint-haw:rgba(242,154,114,.16);
  --shadow:none; --brand-ink:#c3d3ec; --brand-navy:#2b4470;
  --y2:#5d6b82; --y10:#8fa3c4; --y30:#dde6f5;}
  :root:not([data-theme="light"]) .theme-btn i{box-shadow:none;background:currentColor;width:12px;height:12px}
}
:root[data-theme="dark"],:root[data-theme="dark"] .viz-root{color-scheme:dark;
  --page:#0d1219; --bg:#0d1219; --surface-1:#141b25; --surface-2:#1c2532;
  --text-primary:#e9ecf1; --text-secondary:#b8bfca; --muted:#929baa; --faint:#737c8a;
  --grid:#283242; --baseline:#3d4859; --border:rgba(255,255,255,.12);
  --series-1:#86b6f2; --series-2:#f2a07a; --line-1:#64a7f4; --line-2:#f28c5c;
  --pos:#64a7f4; --neg:#f2706f; --muted-bar:#5e6878;
  --good:#5ccb78; --warning:#e3b552; --serious:#f29a72; --critical:#f47b7b;
  --tint-dov:rgba(100,167,244,.15); --tint-haw:rgba(242,154,114,.16);
  --shadow:none; --brand-ink:#c3d3ec; --brand-navy:#2b4470;
  --y2:#5d6b82; --y10:#8fa3c4; --y30:#dde6f5;}
:root[data-theme="dark"] .theme-btn i{box-shadow:none;background:currentColor;width:12px;height:12px}
@media(prefers-color-scheme:dark){
:root:not([data-theme="light"]) .brandwrap{border-bottom-color:var(--grid)}
:root:not([data-theme="light"]) .bnav{border-bottom-color:var(--grid)}
:root:not([data-theme="light"]) .upd-c i,.upd-d{color:var(--muted)}
:root:not([data-theme="light"]) .impact.dovish,.m-dir.dovish{color:#9cc4f5}.impact.hawkish,.m-dir.hawkish{color:#f5b394}
:root:not([data-theme="light"]) .k-surp.beat .ks-verdict,.sbadge2.beat{color:#6fd68a}.k-surp.miss .ks-verdict,.sbadge2.miss{color:#f58c8c}
:root:not([data-theme="light"]) .le-chg.up,.sc-chip.haw{background:rgba(244,123,123,.14)}.le-chg.dn{background:rgba(100,167,244,.15)}
:root:not([data-theme="light"]) .ot-n[aria-pressed="true"],.od-b{background:rgba(100,167,244,.16)}
:root:not([data-theme="light"]) [style*="#e6eef8"]{background:rgba(100,167,244,.16)!important}
:root:not([data-theme="light"]) .hs3-b{background:#4a5a74}.hs3-b.over{background:#9a5a40}
:root:not([data-theme="light"]) .c-off{--f:#2a3240}.c-na{--f:#1c232e}.c-toss{--f:#8a7a45}
:root:not([data-theme="light"]) .logo-full:not(.logo-dk),
:root:not([data-theme="light"]) .logo-compact:not(.logo-dk){display:none!important}
:root:not([data-theme="light"]) .logo-full.logo-dk{display:block!important}
:root:not([data-theme="light"]) .el-tab[aria-selected="true"]{background:var(--brand-navy);border-color:var(--brand-navy);color:#fff}
:root:not([data-theme="light"]) .el-svg .st{stroke:var(--surface-1)}
:root:not([data-theme="light"]) .el-svg .lb:not(.lb-w){fill:#eef1f5;stroke:#0d1219;stroke-width:2.6px;paint-order:stroke;stroke-linejoin:round}
:root:not([data-theme="light"]) img,svg{color-scheme:dark}
}
:root[data-theme="dark"] .brandwrap{border-bottom-color:var(--grid)}
:root[data-theme="dark"] .bnav{border-bottom-color:var(--grid)}
:root[data-theme="dark"] .upd-c i,.upd-d{color:var(--muted)}
:root[data-theme="dark"] .impact.dovish,.m-dir.dovish{color:#9cc4f5}.impact.hawkish,.m-dir.hawkish{color:#f5b394}
:root[data-theme="dark"] .k-surp.beat .ks-verdict,.sbadge2.beat{color:#6fd68a}.k-surp.miss .ks-verdict,.sbadge2.miss{color:#f58c8c}
:root[data-theme="dark"] .le-chg.up,.sc-chip.haw{background:rgba(244,123,123,.14)}.le-chg.dn{background:rgba(100,167,244,.15)}
:root[data-theme="dark"] .ot-n[aria-pressed="true"],.od-b{background:rgba(100,167,244,.16)}
:root[data-theme="dark"] [style*="#e6eef8"]{background:rgba(100,167,244,.16)!important}
:root[data-theme="dark"] .hs3-b{background:#4a5a74}.hs3-b.over{background:#9a5a40}
:root[data-theme="dark"] .c-off{--f:#2a3240}.c-na{--f:#1c232e}.c-toss{--f:#8a7a45}
:root[data-theme="dark"] .logo-full:not(.logo-dk),
:root[data-theme="dark"] .logo-compact:not(.logo-dk){display:none!important}
:root[data-theme="dark"] .logo-full.logo-dk{display:block!important}
:root[data-theme="dark"] .el-tab[aria-selected="true"]{background:var(--brand-navy);border-color:var(--brand-navy);color:#fff}
:root[data-theme="dark"] .el-svg .st{stroke:var(--surface-1)}
:root[data-theme="dark"] .el-svg .lb:not(.lb-w){fill:#eef1f5;stroke:#0d1219;stroke-width:2.6px;paint-order:stroke;stroke-linejoin:round}
:root[data-theme="dark"] img,svg{color-scheme:dark}
@media(max-width:759px){
  :root[data-theme="dark"] .logo-full.logo-dk{display:none!important}
  :root[data-theme="dark"] .logo-compact.logo-dk{display:block!important}}
@media(max-width:759px) and (prefers-color-scheme:dark){
  :root:not([data-theme="light"]) .logo-full.logo-dk{display:none!important}
  :root:not([data-theme="light"]) .logo-compact.logo-dk{display:block!important}}
/* 本期關鍵訊號：淡底與留白定義每則範圍，不添加數據欄位。 */
.viz-root:not(#_) .flag,.viz-root:not(#_) .flag:first-of-type,.viz-root:not(#_) .flag:last-child{
  display:block;min-width:0;padding:18px 20px;margin:0 0 14px;border:0;border-radius:10px;background:var(--surface-2)}
.viz-root:not(#_) .flag .f-head{display:flex;align-items:flex-start;gap:12px;margin:0;line-height:1.6}
.viz-root:not(#_) .flag .f-title{flex:1;min-width:0;overflow-wrap:anywhere}
.viz-root:not(#_) .flag .f-tag{flex:none;display:inline-block;margin:2px 0 0;padding:3px 8px;border:0;border-radius:5px;background:var(--grid);color:var(--text-secondary);font-size:var(--fs-micro);font-weight:600;line-height:1.5;white-space:nowrap}
.viz-root:not(#_) .flag.alert .f-tag{background:var(--tint-haw);color:var(--serious)}
.viz-root:not(#_) .flag.watch .f-tag{color:var(--warning)}
.viz-root:not(#_) .flag .f-impact{display:flex;align-items:flex-start;gap:9px;margin-top:10px;font-size:var(--fs-body);line-height:1.7;color:var(--text-secondary)}
.viz-root:not(#_) .flag .f-impact>span:last-child{flex:1;min-width:0;overflow-wrap:anywhere}
.viz-root:not(#_) .flag .f-lean{flex:none;padding:3px 7px;border-radius:5px;margin-top:1px;font-size:var(--fs-micro);font-weight:600;line-height:1.5;white-space:nowrap;background:var(--grid);color:var(--text-secondary)}
.viz-root:not(#_) .flag .f-lean.dovish{background:var(--tint-dov);color:var(--series-1)}
.viz-root:not(#_) .flag .f-lean.hawkish{background:var(--tint-haw);color:var(--series-2)}
.viz-root:not(#_) .flag .f-more,.viz-root:not(#_) .flag .f-more[open]{border:0;padding:0;margin:8px 0 0;background:none}
.viz-root:not(#_) .flag .f-more>summary{display:inline-flex;gap:8px;min-height:44px;padding:0;border:0}
.viz-root:not(#_) .flag .f-more>summary::after{margin-left:0}
.viz-root:not(#_) .flag .f-detail{max-width:80ch;margin:0;padding:0 0 4px;line-height:1.85}
.viz-root:not(#_) .flag .f-detail p{margin:0 0 12px;font-size:var(--fs-body);line-height:1.85;color:var(--text-secondary)}
.viz-root:not(#_) .flag .f-detail p:last-child{margin-bottom:0}
.viz-root:not(#_) .sig-rest{border-top:0}
@media(max-width:759px){
  .viz-root:not(#_) .flag,.viz-root:not(#_) .flag:first-of-type,.viz-root:not(#_) .flag:last-child{padding:15px 14px;margin-bottom:12px}
  .viz-root:not(#_) .flag .f-head{gap:8px}
  .viz-root:not(#_) .flag .f-tag{padding:3px 6px}}


/* Curve explanations remain one compact row when folded on both platforms. */
.viz-root:not(#_) .cw-panels{grid-template-columns:minmax(0,1fr);gap:10px}
.viz-root:not(#_) details.cw-fold{padding:0;background:transparent;border:0;border-radius:0}
.viz-root:not(#_) .cw-fold>summary{display:flex;align-items:flex-start;gap:12px;padding:18px 0;list-style:none;min-height:44px;text-indent:0}
.cw-fold>summary::-webkit-details-marker{display:none}
.viz-root:not(#_) .cw-fold>summary::before{content:none;display:none}
.cw-fold-number{font-size:var(--fs-micro);color:var(--muted);padding-top:3px}
.cw-fold-title{display:grid;gap:5px;min-width:0;flex:1}
.cw-fold-title b{font-size:var(--fs-body);color:var(--text-primary)}
.cw-fold-reading{font-size:var(--fs-small);line-height:1.65;color:var(--text-secondary)}
.cw-fold>summary::after{content:"";width:7px;height:7px;border:solid var(--muted);border-width:0 1.6px 1.6px 0;transform:rotate(45deg);margin:5px 2px 0 8px;flex:none}
.cw-fold[open]>summary::after{transform:rotate(-135deg);margin-top:9px}
.cw-panel-content{padding:0 0 20px 30px}
.cw-weekly{padding:0 0 24px 30px;margin-top:8px}
.ww-heading{display:flex;gap:8px;justify-content:space-between;align-items:center;flex-wrap:wrap}
.viz-root:not(#_) .ww-heading h3{font-size:var(--fs-body);margin:0}
.ww-heading>span,.ww-legend,.ww-period{font-size:var(--fs-small);color:var(--muted)}
.ww-controls{display:flex;gap:8px;flex-wrap:wrap;margin:12px 0}
.ww-controls button,.ww-apply{font:inherit;font-size:var(--fs-small);padding:8px 12px;border:1px solid var(--border);border-radius:6px;background:var(--surface-1);color:var(--text-primary);min-height:44px;cursor:pointer}
.ww-controls button[aria-pressed="true"]{background:var(--series-1);color:var(--surface-1);border-color:var(--series-1)}
.ww-custom{display:flex;gap:10px;align-items:flex-end;flex-wrap:wrap}
.ww-custom[hidden]{display:none}
.ww-custom label{display:grid;gap:5px;flex:1;min-width:125px;font-size:var(--fs-small);color:var(--text-secondary)}
.ww-custom input{width:100%;min-width:0;box-sizing:border-box;font:inherit;padding:8px;border:1px solid var(--border);border-radius:6px;color:var(--text-primary);background:var(--surface-1);min-height:44px}
.ww-legend{display:flex;gap:14px;flex-wrap:wrap;margin-bottom:18px}
.ww-legend span{display:flex;align-items:center;gap:6px}
.ww-legend i{display:inline-block;width:7px;height:7px;border-radius:2px}
.ww-legend .up,.ww-mark.up{background:var(--series-2)}
.ww-legend .dn,.ww-mark.dn{background:var(--series-1)}
.ww-chart{display:grid;grid-template-columns:38px minmax(0,1fr);height:225px;margin:24px 0 38px}
.ww-y{position:relative;margin-right:8px}
.ww-y span{position:absolute;right:0;transform:translateY(-50%);font-size:var(--fs-micro);color:var(--muted);font-variant-numeric:tabular-nums}
.ww-plot{display:grid;grid-template-columns:repeat(var(--ww-n),minmax(0,1fr));position:relative;border-top:1px solid var(--grid);border-bottom:1px solid var(--grid);touch-action:pan-y}
.ww-grid{position:absolute;left:0;right:0;border-top:1px solid var(--grid);pointer-events:none}
.ww-grid.zero{border-color:var(--baseline)}
.ww-bar{position:relative;display:block;height:100%;width:100%;border:0;background:transparent;padding:0;font:inherit;color:var(--text-primary);cursor:pointer;min-width:0;touch-action:pan-y}
.ww-mark{position:absolute;left:22%;width:56%;max-width:48px;border-radius:2px;opacity:.8}
.ww-bar[aria-pressed="true"] .ww-mark{opacity:1;filter:brightness(.85)}
.ww-value{position:absolute;left:50%;white-space:nowrap;translate:-50% 0;font-size:var(--fs-micro);font-variant-numeric:tabular-nums}
.ww-date{position:absolute;left:50%;bottom:-26px;transform:translateX(-50%);white-space:nowrap;font-size:var(--fs-micro);color:var(--muted)}
.ww-readout{background:transparent;padding:12px 0;border-radius:0;font-size:var(--fs-small);line-height:1.7}
.ww-readout>span{color:var(--muted);font-size:var(--fs-micro)}
.ww-readout>div{display:flex;justify-content:space-between;gap:6px 14px;flex-wrap:wrap}
.viz-root:not(#_) .ww-note{font-size:var(--fs-micro);line-height:1.7;color:var(--muted);margin:10px 0 0}
.ww-error{color:var(--series-2)}
@media(max-width:759px){.cw-panel-content,.cw-weekly{padding-left:24px;padding-right:0}.viz-root:not(#_) .cw-fold>summary{padding:16px 0;gap:9px}.ww-custom input{font-size:16px}.ww-chart{height:205px}}
.viz-root:not(#_) details.future-section{margin-top:18px;border-top:1px solid var(--grid);padding-top:8px}
.viz-root:not(#_) .future-section .future-policy,.viz-root:not(#_) .future-section .future-bonds{border:0;border-radius:0;background:transparent;padding:0 0 16px 30px}
.viz-root:not(#_) .cw-fold>summary:focus-visible{outline:2px solid var(--brand-orange);outline-offset:3px}
@media(max-width:759px){.viz-root:not(#_) .future-section .future-policy,.viz-root:not(#_) .future-section .future-bonds{padding-left:24px}}


/* ---------- 殖利率曲線 v3（2026-10）：30−2 週報、2Y/10Y/30Y 總表、累積變動圖 ---------- */
#cw-t3:checked~.tabp.p3{display:block}
.cwb{margin:4px 0 18px;padding:14px 16px 12px;border:1px solid var(--border);border-left:4px solid var(--brand-orange,#E67143);
  border-radius:0 8px 8px 0;background:var(--surface-1)}
.cwb-h{display:flex;flex-wrap:wrap;gap:4px 12px;align-items:baseline;margin-bottom:6px}
.cwb-h b{font-size:var(--fs-small);color:var(--brand-orange,#E67143);letter-spacing:.04em}
.cwb-h span{font-size:var(--fs-micro);color:var(--muted)}
.viz-root:not(#_) .cwb p{margin:0 0 4px;font-size:var(--fs-body);line-height:1.75;color:var(--text-primary)}
.viz-root:not(#_) .cwb .cwb-lead{font-size:17px;font-weight:800;color:var(--brand-ink,var(--text-primary));margin-bottom:6px}
.viz-root:not(#_) .cwb .cwb-read{margin-top:6px;padding-top:6px;border-top:1px dashed var(--grid);font-weight:600}
.cwm{display:grid;gap:14px;margin:14px 0 6px}
@media(min-width:900px){.cwm{grid-template-columns:minmax(0,1fr) minmax(0,1fr)}}
.viz-root:not(#_) .cwm-t{width:100%;table-layout:fixed;border-collapse:collapse;margin:0;font-variant-numeric:tabular-nums}
.viz-root:not(#_) .cwm-t th,.viz-root:not(#_) .cwm-t td{padding:8px 8px;text-align:right;border:0;background:transparent;
  font-size:var(--fs-body);font-weight:600;color:var(--text-primary);line-height:1.35;white-space:nowrap;vertical-align:top}
.viz-root:not(#_) .cwm-t thead th{font-size:var(--fs-small);font-weight:700;color:var(--muted);background:var(--surface-2)}
.viz-root:not(#_) .cwm-t th:first-child{text-align:left;width:34%}
.viz-root:not(#_) .cwm-t tbody th{font-weight:600;color:var(--text-secondary);font-size:var(--fs-small)}
.viz-root:not(#_) .cwm-t tbody tr+tr>*{border-top:1px solid var(--grid)}
.viz-root:not(#_) .cwm-t small{display:block;font-size:var(--fs-micro);font-weight:500;color:var(--muted);margin-top:2px;white-space:normal}
.viz-root:not(#_) .cwm-t td.up{color:var(--series-2)}.viz-root:not(#_) .cwm-t td.dn{color:var(--series-1)}
.viz-root:not(#_) .cwm-t td.flat{color:var(--text-secondary)}
.viz-root:not(#_) .cwm-t td small.up{color:var(--series-2)}.viz-root:not(#_) .cwm-t td small.dn{color:var(--series-1)}
.viz-root:not(#_) .cwm-t td small.le3-rg{display:inline-block;margin-top:4px}
.viz-root:not(#_) .cwm-t tr.cwm-sel>*{background:var(--surface-2)}
.viz-root:not(#_) .cwm-t tr.cwm-fwd td{font-weight:500}
.viz-root:not(#_) .cwm-note{font-size:var(--fs-micro);line-height:1.7;color:var(--muted);margin:6px 0 0}
.cwc-modes{margin:4px 0 6px}
.cwc-plot svg{display:block;width:100%;height:auto;touch-action:pan-y}
.cwc-grid{stroke:var(--grid);stroke-width:1}.cwc-zero{stroke:var(--baseline,var(--muted));stroke-width:1.2}
.cwc-cross{stroke:var(--muted);stroke-width:1;stroke-dasharray:3 3}
.cwc-ax{font-size:11px;fill:var(--muted);font-variant-numeric:tabular-nums}
.cwc-lab{font-size:11.5px;font-weight:700;font-variant-numeric:tabular-nums}
.viz-root:not(#_) .cwc-read{font-size:var(--fs-small);line-height:1.7;margin:4px 0 0;font-variant-numeric:tabular-nums;min-height:1.7em}
.viz-root:not(#_) .cwc-read small{color:var(--muted)}
.cw-weekly{margin-top:22px;padding-top:16px;border-top:1px solid var(--grid)}
.ww-controls{align-items:center;justify-content:space-between}
.viz-root:not(#_) .ww-controls .cw-btn{min-height:40px;border-radius:999px;padding:7px 12px;background:var(--surface-1);color:var(--text-secondary);border-color:var(--border)}
.viz-root:not(#_) .ww-controls .cw-btn[aria-pressed="true"]{background:var(--brand-navy);border-color:var(--brand-ink);color:#fff}
.viz-root:not(#_) .cw-fold>summary{padding-top:12px;padding-bottom:12px}
.viz-root:not(#_) .cw-panels{margin-top:4px}
@media(max-width:759px){
  .cwb{padding:12px 12px 10px}
  .viz-root:not(#_) .cwb .cwb-lead{font-size:16px}
  .viz-root:not(#_) .cwm-t th,.viz-root:not(#_) .cwm-t td{padding:7px 4px;font-size:14px}
  .viz-root:not(#_) .cwm-t th:first-child{width:30%}
  .cw-weekly{padding-left:0!important}
  .cwc-lab{font-size:13px}.cwc-ax{font-size:12.5px}}

/* ---------- 殖利率曲線 v4（2026-10）：白話週報＋監控表 ---------- */
.cwb-h{position:relative;padding-right:64px}
.cwb-copy{position:absolute;right:0;top:-4px;font:inherit;font-size:var(--fs-micro);font-weight:600;padding:5px 12px;min-height:32px;
  border:1px solid var(--border);border-radius:999px;background:var(--surface-1);color:var(--text-secondary);cursor:pointer}
.cwb-copy:hover{color:var(--text-primary);border-color:var(--text-secondary)}
.viz-root:not(#_) .cwb .cwb-prose{font-size:16px;line-height:1.9;font-weight:500;margin:4px 0 8px;color:var(--text-primary)}
.cwb-more>summary{cursor:pointer;font-size:var(--fs-small);color:var(--muted);list-style:none;padding:4px 0;min-height:32px;display:flex;align-items:center}
.cwb-more>summary::-webkit-details-marker{display:none}
.cwb-more>summary::before{content:"▸";margin-right:6px}.cwb-more[open]>summary::before{content:"▾"}
.viz-root:not(#_) .cwb-more ul{margin:4px 0 2px;padding-left:18px}
.viz-root:not(#_) .cwb-more li{font-size:var(--fs-small);line-height:1.8;color:var(--text-secondary);margin:0}
.viz-root:not(#_) .cwm{display:block;margin:14px 0 6px}
.cwm-tog{display:none;margin-bottom:8px}
.cwm-wrap{overflow-x:auto}
.viz-root:not(#_) .cwm-t{width:100%;min-width:640px;table-layout:fixed;border-collapse:collapse;font-variant-numeric:tabular-nums}
.viz-root:not(#_) .cwm-t th,.viz-root:not(#_) .cwm-t td{padding:10px 10px;text-align:right;vertical-align:middle;border:0;background:transparent;white-space:nowrap;line-height:1.3}
.viz-root:not(#_) .cwm-t thead th{font-size:var(--fs-small);font-weight:700;color:var(--text-secondary);background:transparent;border-bottom:1px solid var(--border);vertical-align:bottom}
.viz-root:not(#_) .cwm-t thead th small{display:block;font-weight:500;color:var(--muted);font-size:var(--fs-micro);margin-top:2px}
.viz-root:not(#_) .cwm-t th:first-child{text-align:left;width:64px}
.viz-root:not(#_) .cwm-t tbody th{font-size:var(--fs-body);font-weight:800;color:var(--text-primary)}
.viz-root:not(#_) .cwm-t tbody td{font-size:var(--fs-body);font-weight:600;color:var(--text-primary)}
.viz-root:not(#_) .cwm-t tbody tr+tr>*{border-top:1px solid var(--grid)}
.viz-root:not(#_) .cwm-t tr.cwm-g>th{font-size:var(--fs-micro);font-weight:700;color:var(--muted);letter-spacing:.04em;padding:14px 10px 4px;text-align:left;border-top:0}
.viz-root:not(#_) .cwm-t tr.cwm-g+tr>*{border-top:0}
.viz-root:not(#_) .cwm-t td small{display:block;font-size:var(--fs-micro);font-weight:500;color:var(--muted);margin-top:2px}
.viz-root:not(#_) .cwm-t td span.up{color:var(--series-2)}.viz-root:not(#_) .cwm-t td span.dn{color:var(--series-1)}
.viz-root:not(#_) .cwm-t td span.flat{color:var(--text-secondary)}
.viz-root:not(#_) .cwm-t td.cwm-c{background:transparent}
.viz-root:not(#_) .cwm-t td small.le3-rg{display:inline-block;margin:4px 0 0}
.cwm-bar{display:block;position:relative;height:4px;margin:6px 0 0 auto;width:72px;background:var(--grid);border-radius:2px}
.cwm-bar::after{content:"";position:absolute;left:50%;top:-2px;bottom:-2px;width:1px;background:var(--muted)}
.cwm-bar b{position:absolute;top:0;bottom:0;border-radius:2px}
.cwm-bar b.r{left:50%}.cwm-bar b.l{right:50%}
.cwm-bar b.up{background:var(--series-2)}.cwm-bar b.dn{background:var(--series-1)}.cwm-bar b.flat{background:var(--muted)}
.cwm-rng{display:block;position:relative;height:4px;margin:7px 0 0 auto;width:72px;background:var(--grid);border-radius:2px}
.cwm-rng b{position:absolute;top:50%;width:8px;height:8px;margin:-4px 0 0 -4px;border-radius:50%;background:var(--brand-ink,var(--text-primary))}
.cwm-spark{display:block;width:56px;height:16px;margin:4px 0 0 auto;color:var(--muted)}
.viz-root:not(#_) .cwm-t td.cwm-f span{font-weight:600}
.cwc-ev{stroke:var(--muted);stroke-width:1;stroke-dasharray:2 3;opacity:.7}
.viz-root:not(#_) .cwc-read em.cwc-evn{font-style:normal;font-size:var(--fs-micro);color:var(--brand-orange,#E67143);margin-left:6px;font-weight:700}
/* 收合區之間不要大段空白（2026-10）；03 的編號跟 01、02 一樣靠上 */
.viz-root:not(#_) .cw-panels{gap:0;margin-top:18px;border-top:1px solid var(--grid)}
.viz-root:not(#_) .cw-panels>.cw-fold{margin:0!important;border-bottom:1px solid var(--grid)}
.viz-root:not(#_) .cw-panels>.cw-fold>summary{padding:12px 0}
.viz-root:not(#_) details.future-section>summary{align-items:flex-start!important}
.viz-root:not(#_) .cw-panels+details,.viz-root:not(#_) .cw+details.future-section{margin-top:0;border-top:0}
@media(max-width:759px){
  .cwm-tog{display:flex}
  .viz-root:not(#_) .cwm-t{min-width:0;table-layout:auto}
  .cwm[data-v="ch"] .cwm-f,.cwm[data-v="fw"] .cwm-c{display:none}
  .viz-root:not(#_) .cwm-t th,.viz-root:not(#_) .cwm-t td{padding:9px 6px}
  .viz-root:not(#_) .cwm-t th:first-child{width:52px}
  .cwm-bar,.cwm-rng{width:52px}
  .viz-root:not(#_) .cwb .cwb-prose{font-size:15.5px}}

/* ---------- 殖利率曲線 v5（2026-10）：膠囊改成分段控制、說明文字收合 ---------- */
.viz-root:not(#_) .cw .cw-ctl,.viz-root:not(#_) .cw-weekly .cw-ctl{display:inline-flex;flex-wrap:nowrap;gap:0;padding:3px;
  border:1px solid var(--border);border-radius:9px;background:var(--surface-2);max-width:100%;overflow-x:auto}
.viz-root:not(#_) .cw .cw-ctl .cw-btn,.viz-root:not(#_) .cw-weekly .cw-ctl .cw-btn{border:0;border-radius:6px;background:transparent;
  color:var(--text-secondary);padding:6px 12px;min-height:34px;font-size:var(--fs-small);font-weight:600;white-space:nowrap;box-shadow:none}
.viz-root:not(#_) .cw .cw-ctl .cw-btn.on,.viz-root:not(#_) .cw-weekly .cw-ctl .cw-btn.on,
.viz-root:not(#_) .cw-weekly .cw-ctl .cw-btn[aria-pressed="true"]{background:var(--surface-1);color:var(--text-primary);
  box-shadow:0 1px 2px rgba(0,0,0,.14),0 0 0 1px var(--border)}
.viz-root:not(#_) .cw>.cw-ctl{margin-bottom:4px}
.viz-root:not(#_) .cw .cwm-tog{display:none;margin:0 0 8px}
@media(max-width:759px){.viz-root:not(#_) .cw .cwm-tog{display:inline-flex}}
.cwm-top{display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap}
/* 圖表分頁：底線式（不再是一排膠囊） */
.viz-root:not(#_) .cw-tabs{margin-top:18px}
.viz-root:not(#_) .cw-tabs>label{border:0;border-bottom:2px solid transparent;border-radius:0;background:transparent;
  color:var(--muted);padding:6px 2px;margin:0 18px 0 0;font-size:var(--fs-body);font-weight:700}
.viz-root:not(#_) .cw-tabs>input:checked+label{background:transparent;color:var(--text-primary);border-bottom-color:var(--brand-orange,#E67143)}
.viz-root:not(#_) .cw-tabs .tabp{border-top:1px solid var(--grid);padding-top:12px;margin-top:-1px}
.viz-root:not(#_) .cwc-modes{margin:0 0 6px}
/* 說明文字收合 */
.cw-note>summary{cursor:pointer;list-style:none;font-size:var(--fs-micro);color:var(--muted);padding:4px 0;min-height:28px;display:inline-flex;align-items:center}
.cw-note>summary::-webkit-details-marker{display:none}
.cw-note>summary::before{content:"ⓘ";margin-right:5px;font-size:12px}
.viz-root:not(#_) .cw-note .cwm-note,.viz-root:not(#_) .cw-note .ww-note{margin:2px 0 6px}
.ww-legend{margin-bottom:10px}
@media(max-width:759px){
  .viz-root:not(#_) .cw .cw-ctl .cw-btn,.viz-root:not(#_) .cw-weekly .cw-ctl .cw-btn{padding:6px 9px;font-size:13px}
  .viz-root:not(#_) .cw-tabs>label{margin-right:14px;font-size:15px}}
"""

JS = """
(function(){var b=document.querySelector('.theme-btn');if(!b)return;
 b.addEventListener('click',function(){var r=document.documentElement,cur=r.getAttribute('data-theme');
  var dark=cur?cur==='dark':window.matchMedia('(prefers-color-scheme: dark)').matches;var nx=dark?'light':'dark';
  r.setAttribute('data-theme',nx);try{localStorage.setItem('mgg-theme',nx);}catch(e){}});})();
(function(){
  // ---- 翻譯代理上的返回鈕 ----
  // 在 translate.goog（Google 翻譯代理）上瀏覽時，右上角的 EN 鈕
  // 改成「中」、連回原站同一頁——Google 自帶的「顯示原文」列不一定
  // 出現（手機常沒有），沒有這顆就回不來（使用者實際回報過）。
  var lb = document.querySelector('.lang-btn');
  if (lb && location.hostname.indexOf('translate.goog') >= 0) {
    lb.textContent = '中';
    lb.setAttribute('title', '切回中文原文');
    lb.href = 'https://%%HOST%%' + location.pathname;
  }

  // 手機只常駐主卡結論；下方主題全部先收合，避免進頁就落入長內容。
  if(window.innerWidth < %%BP%%){
    document.querySelectorAll('details[data-m-collapse], details.card.sect').forEach(function(d){
      d.removeAttribute('open');
    });
  }

  // ---- 可收合卡區 ----
  // 錨點跳轉時要把目標展開。不做的話，點頁內導覽跳過去只會看到
  // 一條收合的標題列，讀者會以為那一區是空的。
  // 目標可能是 <h2 id> 本身（在 summary 裡），所以往上找最近的 details。
  function openTarget(){
    var id = location.hash.slice(1);
    if(!id) return;
    var el = document.getElementById(id);
    if(!el) return;
    var d = el.closest('details');
    while(d){ d.open = true; d = d.parentElement && d.parentElement.closest('details'); }
    // 展開會改變版面高度，捲動位置要重算
    el.scrollIntoView({block:'start'});
  }
  window.addEventListener('hashchange', openTarget);
  if(location.hash) setTimeout(openTarget, 0);

  function setAll(open){
    document.querySelectorAll('details.sect').forEach(function(d){ d.open = open; });
  }
  document.querySelectorAll('.sect-tools button').forEach(function(b){
    b.addEventListener('click', function(){ setAll(b.dataset.all === 'open'); });
  });

  // 列印／存成 PDF 前全部展開。CSS 那邊也寫了 @media print，但新版 Chrome
  // 用 content-visibility 實作收合，作者樣式不一定壓得過，所以這裡再保險一次。
  window.addEventListener('beforeprint', function(){
    document.querySelectorAll('details').forEach(function(d){
      if(!d.open){ d.dataset.wasClosed = '1'; d.open = true; }
    });
  });
  window.addEventListener('afterprint', function(){
    document.querySelectorAll('details[data-was-closed]').forEach(function(d){
      d.open = false; delete d.dataset.wasClosed;
    });
  });

  // 預載後備：不支援 Speculation Rules 的瀏覽器（Firefox／舊 Safari）
  // 改用「滑過（或手指按下）站內連結就 prefetch」——點下去時 HTML
  // 已經在快取裡。同一頁只抓一次。
  if(!HTMLScriptElement.supports || !HTMLScriptElement.supports('speculationrules')){
    var _pf = {};
    function prefetch(href){
      if(!href || _pf[href]) return;
      _pf[href] = 1;
      var l = document.createElement('link');
      l.rel = 'prefetch'; l.href = href;
      document.head.appendChild(l);
    }
    document.querySelectorAll('a[href^="/"]').forEach(function(a){
      var h = a.getAttribute('href').split('#')[0];
      if(!h || h === location.pathname) return;
      a.addEventListener('mouseenter', function(){ prefetch(h); }, {once:true});
      a.addEventListener('touchstart', function(){ prefetch(h); },
                         {once:true, passive:true});
    });
  }

  // 並排卡同步：同一列 g2 裡的兩張卡，一張開合、另一張跟著——
  // **只在桌機**。手機上 g2 是上下堆疊、不存在高度落差，同步反而變成
  // 「點左卡卻把並排的右卡也拉開」的怪行為（使用者實際回報過）。
  // 用「狀態不同才改」當終止條件，避免 toggle 事件互相觸發成迴圈。
  document.querySelectorAll('.grid.g2').forEach(function(g){
    var ds = g.querySelectorAll(':scope > details.sect');
    if(ds.length < 2) return;
    ds.forEach(function(d){
      d.addEventListener('toggle', function(){
        if(window.innerWidth < %%BP%%) return;
        ds.forEach(function(o){
          if(o !== d && o.open !== d.open) o.open = d.open;
        });
      });
    });
  });
  // 橫捲列兩側的漸層。外框掛 .fl/.fr，內層負責捲動。
  // 沒有這個提示的話橫捲列就是硬切一刀，讀者會以為「只有這幾項」——
  // 主選單在 360px 下有 32% 在視窗外，那 32% 裡包含「總覽」。
  function edgeFades(wrap, box){
    function upd(){
      var max=box.scrollWidth-box.clientWidth;
      wrap.classList.toggle('fl', box.scrollLeft>4);
      wrap.classList.toggle('fr', box.scrollLeft<max-4);
    }
    box.addEventListener('scroll',upd,{passive:true});
    window.addEventListener('resize',upd);
    return upd;
  }

  // ---- 主選單（置頂細條）----
  // ① 太陽放到目前分頁正下方；換頁時從上一頁的分頁滑過來
  //   （上一頁記在 sessionStorage，沒有就直接出現在定點）。
  // ② 窄螢幕橫捲：目前分頁若在可視範圍外，**最小移動**捲進來——不置中，
  //   置中會把「總覽」推出左邊，讀者以為回不了首頁。
  // ③ 頁首捲走後加 .stuck：陰影＋左側淡入 GG 標記。
  (function(){
    var bar=document.querySelector('.bnav'); if(!bar)return;
    var tabs=bar.querySelector('.bnav-tabs'), track=bar.querySelector('.bnav-track');
    var sun=bar.querySelector('.bnav-sun'), glow=bar.querySelector('.bnav-glow');
    var on=track.querySelector('a.on');
    function place(a){ if(!a)return; var x=a.offsetLeft+a.offsetWidth/2;
      sun.style.left=x+'px'; glow.style.left=x+'px'; }
    var prev=null; try{prev=sessionStorage.getItem('gg-sun');}catch(e){}
    var old=prev&&track.querySelector('a[href="'+prev+'"]');
    if(on&&old&&old!==on&&!matchMedia('(prefers-reduced-motion: reduce)').matches){
      sun.style.transition=glow.style.transition='none'; place(old);
      requestAnimationFrame(function(){ requestAnimationFrame(function(){
        sun.style.transition=glow.style.transition=''; place(on); }); });
    } else place(on);
    try{ if(on)sessionStorage.setItem('gg-sun',on.getAttribute('href')); }catch(e){}
    if(on&&tabs.scrollWidth>tabs.clientWidth){
      var right=on.offsetLeft+on.offsetWidth+8-tabs.clientWidth;
      if(right>0)tabs.scrollLeft=right;
    }
    var upd=edgeFades(bar,tabs); upd();
    // 字型（Montserrat）晚一步載入時分頁寬度會變，太陽要跟著重放
    if(document.fonts&&document.fonts.ready)document.fonts.ready.then(function(){place(on);upd();});
    window.addEventListener('resize',function(){place(on);});
    var head=document.querySelector('.brandwrap');
    if(head&&'IntersectionObserver' in window){
      new IntersectionObserver(function(es){
        bar.classList.toggle('stuck',!es[0].isIntersecting);
        setTimeout(upd,240);
      },{threshold:0}).observe(head);
    }
  })();

  // 橫捲表格（.tscroll／熱力圖）掛上同一套邊緣漸層。
  // 表格大多藏在收合層裡，收著的時候量不到寬度——所以任何 details
  // 開合時全部重算一次（toggle 不冒泡，用捕獲階段在 document 上接）。
  var tupds=[];
  document.querySelectorAll('.tscroll, .heatwrap').forEach(function(box){
    var wrap=document.createElement('div');
    wrap.className='twrap';
    box.parentNode.insertBefore(wrap,box);
    wrap.appendChild(box);
    tupds.push(edgeFades(wrap,box));
  });
  tupds.forEach(function(u){u();});
  if(tupds.length){
    document.addEventListener('toggle', function(){
      tupds.forEach(function(u){u();});
    }, true);
  }

  // ---- 頁內錨點導覽 ----
  // 三件事：什麼時候出現、兩側的漸層、現在在哪一段。
  (function(){
    var wrap=document.querySelector('.anav'); if(!wrap)return;
    var nav=wrap.querySelector('nav.anchors'); if(!nav)return;
    var shown=false;

    var _upd=edgeFades(wrap,nav);
    function fades(){ if(shown)_upd(); }

    // 出現的門檻＝展開三個卡區。那是「頁面開始變長」的分界：
    // 收合狀態整頁只有兩三千 px，用捲的就到了；按下「展開全部」之後
    // 會漲到一萬多 px，那時候才需要導覽。
    // 出現之後不再收回——導覽列忽隱忽現比一直在還煩。
    function check(){
      if(shown)return;
      if(document.querySelectorAll('details.sect[open]').length<3)return;
      // 導覽列排在內文上方，出現時整頁會往下推一個列高。
      // 讀者剛剛點開的那張卡會跟著跳走——要把捲動位置補回來。
      // Chrome／Firefox 的 scroll anchoring 會自己補，重複補就變成跳兩倍；
      // Safari 不支援，完全不補。所以先看瀏覽器動了沒，沒動才自己補。
      //
      // y0 一定要在改 class **之前**讀：讀 scrollY 會強制 reflow，
      // 而 reflow 正是瀏覽器補償的時機。改完才讀的話讀到的已經是補過的值，
      // 判斷會變成「瀏覽器沒動」，於是又補一次 → 剛好跳兩倍。
      var y0=window.scrollY;
      shown=true; wrap.classList.add('on');
      var h=wrap.getBoundingClientRect().height;
      requestAnimationFrame(function(){
        if(y0>0&&h&&Math.abs(window.scrollY-y0)<1)window.scrollBy(0,h);
        fades(); if(cur)center(cur);
      });
    }
    // toggle 事件不冒泡，要用捕獲階段接
    document.addEventListener('toggle',function(e){
      if(e.target.classList&&e.target.classList.contains('sect'))check();
    },true);
    document.querySelectorAll('.sect-tools button').forEach(function(b){
      b.addEventListener('click',function(){setTimeout(check,0);});
    });
    // 從別頁帶錨點跳進來時 openTarget() 會展開目標，這時也要重算
    window.addEventListener('hashchange',function(){setTimeout(check,0);});
    check();

    // ---- 現在在哪一段 ----
    var heads=[],cur=null;
    [].forEach.call(nav.querySelectorAll('a'),function(a){
      var el=document.getElementById(a.getAttribute('href').slice(1));
      if(el)heads.push({el:el,a:a});
    });
    function center(a){
      // 手機上這一列是橫捲的：高亮若落在可視範圍外就等於沒有高亮
      if(nav.scrollWidth<=nav.clientWidth)return;
      var want=a.offsetLeft-(nav.clientWidth-a.offsetWidth)/2;
      nav.scrollTo({left:Math.max(0,want),behavior:'smooth'});
    }
    function mark(a){
      if(!a||a===cur)return;
      if(cur)cur.classList.remove('on');
      cur=a; a.classList.add('on');
      if(shown)center(a);
    }
    // 判定方式是「越過導覽列那條線的最後一個標題」，不是「哪個標題在畫面上」。
    // 差別在於讀者多數時間是停在某一段的**中間**，畫面上一個標題都沒有——
    // 只看可見標題的話那段時間會沒有高亮，或是亂跳。
    var tick=false;
    function spy(){
      tick=false;
      if(!heads.length)return;
      var line=(shown?wrap.getBoundingClientRect().bottom:0)+10;
      var best=heads[0];
      for(var i=0;i<heads.length;i++){
        if(heads[i].el.getBoundingClientRect().top<=line)best=heads[i];
      }
      mark(best.a);
    }
    function queue(){
      if(tick)return; tick=true; requestAnimationFrame(spy);
    }
    window.addEventListener('scroll',queue,{passive:true});
    window.addEventListener('resize',queue);
    // 展開／收合會整個改變版面高度，位置要重算
    document.addEventListener('toggle',function(e){
      if(e.target.classList&&e.target.classList.contains('sect'))queue();
    },true);
    queue();

    // 點了就立刻標記，不必等捲動結束
    nav.addEventListener('click',function(e){
      var a=e.target.closest('a'); if(a)mark(a);
    });
  })();
  // 近 N 期數值列在窄卡片裡會超出可視範圍。捲到最右邊，
  // 讓「最新一期」那一格（.mcell.last）一定看得到——
  // 停在最左邊等於把整列裡最重要的那個數字藏起來。
  document.querySelectorAll('.mseries').forEach(function(m){
    if(m.scrollWidth>m.clientWidth)m.scrollLeft=m.scrollWidth;
  });
  var t=document.getElementById('tip');

  /* 聯準會官員樹：點人物 → 下方面板換人 */
  document.querySelectorAll('[data-ot]').forEach(function(ot){
    ot.addEventListener('click',function(e){
      var b=e.target.closest('.ot-n'); if(!b)return;
      var id=b.getAttribute('data-p');
      ot.querySelectorAll('.ot-n').forEach(function(x){x.setAttribute('aria-pressed',x===b?'true':'false');});
      ot.querySelectorAll('.od').forEach(function(d){d.hidden=d.getAttribute('data-p')!==id;});
      var pn=ot.querySelector('.ot-panel');
      if(pn){var r=pn.getBoundingClientRect();
        if(r.top>window.innerHeight-120||r.bottom<0){pn.scrollIntoView({behavior:'smooth',block:'start'});}}
    });
  });


  // Full chart data are shared by mouse, touch, pen and keyboard.
  var CHARTS='.cl,.lwrap,.kh,.gc,.wf,.br,.sg,.nl,.dbars,.sstrip,.heatwrap,.hs3';
  function readout(host){
    var r=host.querySelector(':scope > .chart-readout');
    if(!r){r=document.createElement('div');r.className='chart-readout';r.setAttribute('role','status');r.setAttribute('aria-live','polite');host.appendChild(r);}
    return r;
  }
  function points(el){if(!el._chartPoints)el._chartPoints=JSON.parse(el.dataset.points);return el._chartPoints;}
  function choose(el,index){
    var data=points(el);if(!data.length)return;
    index=Math.max(0,Math.min(data.length-1,index));el._index=index;
    var p=data[index],plot=el.parentElement,host=el.closest(CHARTS)||plot.parentElement;
    el.setAttribute('aria-valuenow',index);el.setAttribute('aria-valuetext',p.date+' '+p.values.map(function(v){return v.label+' '+v.text;}).join('，'));
    var line=plot.querySelector('.chart-cursor');if(!line){line=document.createElement('span');line.className='chart-cursor';plot.appendChild(line);}line.style.left=p.x+'%';
    plot.querySelectorAll('.chart-selected-dot').forEach(function(d){d.remove();});
    var r=readout(host);r.replaceChildren();var date=document.createElement('strong');date.textContent=p.date;r.appendChild(date);
    var vals=document.createElement('div');vals.className='chart-readout-values';r.appendChild(vals);
    p.values.forEach(function(v){
      var row=document.createElement('span'),label=document.createElement('span'),dot=document.createElement('i'),value=document.createElement('b');
      dot.style.background=v.color;label.appendChild(dot);label.appendChild(document.createTextNode(v.label));value.textContent=v.text;row.appendChild(label);row.appendChild(value);vals.appendChild(row);
      if(v.y!==undefined&&v.y!==null){var d=document.createElement('span');d.className='chart-selected-dot';d.style.cssText='left:'+p.x+'%;top:'+v.y+'%;background:'+v.color;plot.appendChild(d);}
    });
    if(t)t.style.opacity=0;
  }
  function atX(el,x){var box=el.getBoundingClientRect(),xp=(x-box.left)/box.width*100,data=points(el),best=0,dist=Infinity;data.forEach(function(p,i){var d=Math.abs(p.x-xp);if(d<dist){best=i;dist=d;}});choose(el,best);}
  document.querySelectorAll('.chart-inspector').forEach(function(el){
    var host=el.closest(CHARTS)||el.parentElement.parentElement;
    readout(host).textContent='點選圖表查看數值；可左右拖動或使用方向鍵。';
  });
  var drag=null;
  document.addEventListener('pointerdown',function(e){
    var el=e.target.closest('.chart-inspector');
    if(el){atX(el,e.clientX);drag={el:el,id:e.pointerId,x:e.clientX,y:e.clientY};if(e.pointerType==='touch')el.setPointerCapture(e.pointerId);return;}
    var tip=e.target.closest('[data-tip]');if(!tip){if(t)t.style.opacity=0;return;}
    var host=tip.closest(CHARTS);
    if(host){host.querySelectorAll('[data-chart-selected]').forEach(function(x){x.removeAttribute('data-chart-selected');});tip.setAttribute('data-chart-selected','');var r=readout(host);r.replaceChildren();tip.dataset.tip.split('｜').forEach(function(part,i){var p=document.createElement(i===0?'strong':'div');p.textContent=part;r.appendChild(p);});if(t)t.style.opacity=0;}
    else{showTip(tip,e);}
  });
  document.addEventListener('pointermove',function(e){
    var el=e.target.closest('.chart-inspector');
    if(drag&&drag.id===e.pointerId&&e.pointerType==='touch'){
      if(Math.abs(e.clientY-drag.y)>Math.abs(e.clientX-drag.x)+8){drag=null;return;}
      if(Math.abs(e.clientX-drag.x)>8)atX(drag.el,e.clientX);return;
    }
    if(el&&e.pointerType!=='touch'){atX(el,e.clientX);return;}
    if(e.pointerType==='touch')return;var tip=e.target.closest('[data-tip]');if(tip)showTip(tip,e);else if(t)t.style.opacity=0;
  });
  document.addEventListener('pointerup',function(){drag=null;});
  document.addEventListener('pointercancel',function(){drag=null;});
  document.addEventListener('keydown',function(e){
    var el=e.target.closest('.chart-inspector');if(!el)return;var i=el._index===undefined?0:el._index;
    if(e.key==='ArrowLeft')i--;else if(e.key==='ArrowRight')i++;else if(e.key==='Home')i=0;else if(e.key==='End')i=points(el).length-1;else return;
    e.preventDefault();choose(el,i);
  });
  function showTip(el,e){
    if(!t)return;t.textContent=el.dataset.tip;t.style.opacity=1;
    var x=Math.min(Math.max(8,e.clientX+14),Math.max(8,window.innerWidth-t.offsetWidth-8));
    var y=e.clientY-34;if(y<8)y=e.clientY+22;y=Math.min(Math.max(8,y),Math.max(8,window.innerHeight-t.offsetHeight-8));
    t.style.left=x+'px';t.style.top=y+'px';
  }
  document.addEventListener('pointerout',function(e){if(e.pointerType!=='touch'&&t&&e.target.closest('[data-tip]'))t.style.opacity=0;});
  window.addEventListener('scroll',function(){if(t)t.style.opacity=0;},{passive:true});

})();
""".replace("%%BP%%", str(MOBILE_BREAKPOINT)).replace("%%HOST%%", SITE_HOST)


def _nav(active: str) -> str:
    """置頂主選單：GG 標記（捲動後淡入）＋分頁＋地平線上的太陽。"""
    out = []
    for path, name, done in NAV:
        cls = []
        if path == active:
            cls.append("on")
        if not done:
            cls.append("soon")
        c = f' class="{" ".join(cls)}"' if cls else ""
        cur = ' aria-current="page"' if path == active else ""
        out.append(f'<a href="{path}"{c}{cur}>{esc(name)}</a>')
    return ('<nav class="bnav" aria-label="主選單"><div class="bnav-in">'
            '<a class="bnav-mark" href="/" aria-label="回首頁" tabindex="-1">'
            '<img src="/brand/logo-mark.svg" alt="" width="48" height="24"></a>'
            f'<div class="bnav-tabs"><div class="bnav-track">{"".join(out)}'
            '<span class="bnav-glow"></span><span class="bnav-sun"></span></div></div>'
            '<span class="bnav-fade l"></span><span class="bnav-fade r"></span>'
            '</div></nav>')


def _brand_header(active: str) -> str:
    """
    白底品牌頁首：LOGO（完整版／手機精簡版）＋三地最後更新時間＋EN。
    時間取「產出這一頁的時刻」——同一次執行的每一頁都一樣。
    """
    times = clock.world_times()
    cells = "".join(f'<div class="upd-c"><span>{c}</span><b>{hm}</b><i>{md}</i></div>'
                    for c, hm, md in times)
    return (f'<div class="brandwrap"><header class="brandbar">'
            f'<a class="brand" href="/" aria-label="{SITE_NAME} 首頁">'
            f'<img class="logo-full" src="/brand/logo-full.svg" width="333" height="62" '
            f'alt="{SITE_NAME} {TAGLINE}">'
            f'<img class="logo-full logo-dk" src="/brand/logo-full-dark.svg" width="333" height="62" alt="">'
            f'<img class="logo-compact" src="/brand/logo-compact.svg" width="157" height="30" '
            f'alt="{SITE_NAME}">'
            f'<img class="logo-compact logo-dk" src="/brand/logo-compact-dark.svg" width="157" height="30" alt=""></a>'
            f'<div class="upd"><span class="upd-k">最後更新<span class="upd-d">{times[0][2]}</span>'
            f'</span>{cells}</div>'
            f'<button type="button" class="theme-btn" aria-label="切換深色／淺色模式" title="切換深色／淺色模式">'
            f'<i aria-hidden="true"></i></button>'
            f'{_lang_btn(active)}</header></div>')


# 附錄類的卡區：翻到底自然會看到，不會有人特地跳過去。
# 列在導覽上只是佔一格，還把手機的橫捲距離拉長。
_ANCHOR_SKIP = ("名詞解釋", "判讀說明")


def _anchor_nav(body: str) -> str:
    """
    從內文的 <h2 id="..."> 自動產生頁內導覽。

    只在頁面**真的變長**時才由 JS 顯示出來（見 CSS 的說明）——
    收合狀態下卡區標題列本身就是目錄，這條是重複的。
    """
    items = [(i, re.sub(r"<[^>]+>", "", t).strip())
             for i, t in re.findall(r'<h2 id="([^"]+)"[^>]*>(.*?)</h2>', body, re.S)]
    items = [(i, t) for i, t in items if not t.startswith(_ANCHOR_SKIP)]
    if len(items) < 3:
        return ""
    links = "".join(f'<a href="#{i}">{t}</a>' for i, t in items)
    return f'<div class="anav"><nav class="anchors">{links}</nav></div>'


# 「數字 ＋ 單位」與「標籤 ＋ 數字」之間的普通空白換成不斷行空白。
# 收合摘要是拿來**掃視**的，掃視時眼睛要在一行內抓到完整的一組
#「這是什麼、是多少」。斷成「時薪年增 ⏎ 3.2%」「已卡至少 64 ⏎ 個月」
# 之後，讀者得往下跳一行才確認得了數字——那正是收合設計要省掉的動作。
# 只黏這兩種接縫，欄位之間的「　·　」照樣可以斷，長摘要仍然換得了行。
_CJK = r"\u4e00-\u9fff"
_GLUE = [
    re.compile(rf"(?<=[\d%）)])[ ](?=[{_CJK}])"),      # 64 個月、3.2% 的
    re.compile(rf"(?<=[{_CJK}：])[ ](?=[+\-\d])"),     # 時薪年增 3.2%
]


def _glue(s: str) -> str:
    for rx in _GLUE:
        s = rx.sub("\u00a0", s)
    return s


_SECT_OPEN = re.compile(r'<div class="card">\s*<h2 (id="[^"]+"[^>]*)>(.*?)</h2>', re.S)
_DIV_TOKEN = re.compile(r'<div\b[^>]*>|</div>')
_ATTR = re.compile(r'(\w[\w-]*)="([^"]*)"')


def _close_of(s: str, start: int) -> int | None:
    """
    從 start（開標籤之後）往後找對應的 </div>，回傳它的起始位置。

    卡片裡面有很多層 div，不能用「下一個 </div>」——必須數層。
    分頁的卡片實測沒有巢狀（`.card` 不會包 `.card`），所以只需要
    在單一卡片內平衡即可。
    """
    depth = 1
    for t in _DIV_TOKEN.finditer(s, start):
        if t.group(0) == "</div>":
            depth -= 1
            if depth == 0:
                return t.start()
        else:
            depth += 1
    return None


def _collapse_sections(body: str) -> str:
    """
    把每一個「卡片 ＋ 標題」轉成可收合的 <details>。

    為什麼在這裡做而不是各分頁自己寫
    --------------------------------
    五個分頁一共 38 個卡區，每個都手動包一次 <details> 有兩個問題：
    改版時容易漏掉某一頁，而且 <details>/<summary> 的巢狀縮排會把
    本來就很長的 f-string 再撐大一圈。卡片的結構是固定的
    （`<div class="card">` 緊接 `<h2 id=...>`，而且卡片不巢狀），
    所以在這裡做一次機械式轉換最省、也不可能有哪一頁忘了改。

    兩個由 <h2> 的屬性控制的行為：
        data-open="1"  這一區預設展開（每頁只給緊接結論卡的那一張）
        data-sum="…"   收合時標題列右邊顯示的一句結論

    data-sum 很重要：只寫標題的收合卡，讀者得逐一點開才知道哪張有事，
    那比不收合還糟。帶上一句結論之後，收合狀態仍然可以一眼掃完整頁。

    KPI 卡（`class="card kpi"`）沒有 <h2>，不會被這裡動到——
    它們由分頁自己包進「關鍵數字」那一區。
    """
    out, pos = [], 0
    for m in _SECT_OPEN.finditer(body):
        end = _close_of(body, m.end())
        if end is None:                     # 結構不如預期就整段原樣保留
            continue
        attrs = dict(_ATTR.findall(m.group(1)))
        sid = attrs.get("id", "")
        title = m.group(2)
        summ = _glue(attrs.get("data-sum", ""))
        is_open = attrs.get("data-open") == "1"
        inner = body[m.end():end]

        head = (f'<h2 id="{sid}">{title}</h2>'
                + (f'<span class="sect-sum">{summ}</span>' if summ else ""))
        out.append(body[pos:m.start()])
        out.append(
            f'<details class="card sect"{" open" if is_open else ""}>'
            f'<summary>{head}</summary>'
            f'<div class="sect-body">{inner}</div>'
            f'</details>')
        pos = end + len("</div>")
    out.append(body[pos:])
    return "".join(out)


_TOOLS = ('<div class="sect-tools">'
          '<button type="button" data-all="open">展開全部</button>'
          '<button type="button" data-all="close">收合全部</button>'
          '</div>')


def _insert_tools(body: str) -> str:
    """
    把「展開全部／收合全部」插在第一個卡區**之前**、結論卡之後。

    放在整頁最上面看起來會像「這一頁的主要動作是展開東西」——
    但這一頁的主角是結論。工具列該出現在讀者已經讀完結論、
    開始決定要看哪幾區的位置。

    收合狀態下瀏覽器的 Ctrl+F 找不到內文（hidden-until-found 支援度
    還不齊），所以這一列不只是方便，是必要的補償。
    """
    i = body.find('<details class="card sect"')
    if i < 0:
        return body
    # 往前退到這張卡外層 <div class="grid"> 的開頭，工具列才不會擠進網格裡
    j = body.rfind('<div class="grid', 0, i)
    at = j if j >= 0 else i
    return body[:at] + _TOOLS + "\n" + body[at:]


def _page_prevnext(active: str) -> str:
    """
    頁尾的上一頁／下一頁：照 NAV 的閱讀順序接前後頁。
    讀完一頁的人在頁面底部，要換頁得捲回頂端——這兩顆連結
    讓「逐頁讀完」的動線自然接下去。
    """
    paths = [(p, label) for p, label, on in NAV if on]
    idx = next((i for i, (p, _) in enumerate(paths) if p == active), None)
    if idx is None:
        return ""
    # 2026-10 改版：一條分成左右兩半的導覽列，頁名前帶橘色序號（跟區塊目錄的編號同一套）
    prev_html = next_html = '<span class="pn-nil"></span>'
    if idx > 0:
        p, label = paths[idx - 1]
        prev_html = (f'<a class="pn-prev" href="{esc(p)}"><span class="pn-k">上一頁</span>'
                     f'<b><em>{idx:02d}</em>{esc(label)}</b></a>')
    if idx < len(paths) - 1:
        p, label = paths[idx + 1]
        next_html = (f'<a class="pn-next" href="{esc(p)}"><span class="pn-k">下一頁</span>'
                     f'<b><em>{idx + 2:02d}</em>{esc(label)}</b></a>')
    if idx == 0 and len(paths) < 2:
        return ""
    return f'<nav class="pagenav" aria-label="前後頁">{prev_html}{next_html}</nav>'


# 換頁預渲染（Speculation Rules）：滑鼠移到站內連結（手機為按下瞬間）
# 就在背景把那一頁抓好、渲染好，點下去幾乎零延遲。宣告式 JSON，
# Chrome／Edge 原生支援，其他瀏覽器安全忽略。
_SPECULATION = """<script type="speculationrules">
{"prerender":[{"where":{"href_matches":"/*"},"eagerness":"moderate"}]}
</script>"""


# 連結預覽（LINE／FB／Threads／Discord）的描述。沒列到的頁面用站的總描述。
PAGE_DESC = {
    "/": "美國總經儀表板：就業、通膨、聯準會、長端利率，每天自動更新，一頁看懂利率往哪走。",
    "/labor/": "美國就業報告拆解：非農、失業率、薪資與勞動參與，判斷就業是轉強還是轉弱。",
    "/inflation/": "美國通膨拆解：CPI、PCE、PPI 與超級核心服務，看通膨是升溫、黏著還是降溫。",
    "/fomc/": "聯準會：最新決議、投票、點陣圖、市場定價、會議紀要與官員發言。",
    "/rates/": "長端利率與債務：殖利率曲線、期限溢酬、財政與科技巨頭發債。",
    "/scenario/": "情境合成：就業 × 通膨的九宮格，判斷聯準會下一步。",
    "/archive/": "每個資料月份第一次產出時的完整頁面存檔。",
}
# 網址帶版本號：Threads／FB 會快取縮圖，圖換了但網址沒變，舊快取（或「沒有縮圖」
# 的快取）會一直留著。換圖時把版本號往上加，爬蟲就會當成新圖重抓。
OG_VERSION = "20261006"
OG_IMAGE = f"https://{SITE_HOST}/brand/og.jpg?v={OG_VERSION}"
BRAND_NAVY = "#12233B"


def _head_meta(doc_title: str, active: str) -> str:
    desc = PAGE_DESC.get(active, PAGE_DESC["/"])
    url = f"https://{SITE_HOST}{active}"
    return f"""<meta name="description" content="{esc(desc)}">
<meta property="og:type" content="website">
<meta property="og:site_name" content="{SITE_NAME}">
<meta property="og:locale" content="zh_TW">
<meta property="og:title" content="{esc(doc_title)}">
<meta property="og:description" content="{esc(desc)}">
<meta property="og:url" content="{url}">
<meta property="og:image" content="{OG_IMAGE}">
<meta property="og:image:secure_url" content="{OG_IMAGE}">
<meta property="og:image:type" content="image/jpeg">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta property="og:image:alt" content="{SITE_NAME} {TAGLINE}">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="{esc(doc_title)}">
<meta name="twitter:description" content="{esc(desc)}">
<meta name="twitter:image" content="{OG_IMAGE}">
<link rel="icon" href="/favicon.ico" sizes="any">
<link rel="icon" href="/brand/favicon.svg" type="image/svg+xml">
<link rel="apple-touch-icon" href="/apple-touch-icon.png">
<link rel="manifest" href="/site.webmanifest">
<meta name="theme-color" content="#ffffff">
<meta name="apple-mobile-web-app-title" content="{SITE_NAME}">
<meta name="application-name" content="{SITE_NAME}">
<link rel="preload" href="/brand/montserrat-latin.woff2" as="font" type="font/woff2" crossorigin>"""


def page(title: str, active: str, body: str, subtitle: str = "",
         footer: str = "", banner: str = "") -> str:
    """組出一個完整的自足 HTML 頁面。"""
    # 錨點導覽要在轉換**前**產生：轉換後 <h2> 會被包進 <summary>，
    # 屬性順序也可能改變，用轉換前的原文抓最穩。
    anchors = _anchor_nav(body)
    body = _insert_tools(_collapse_sections(body))
    # <title>：分頁是「頁名｜站名」；首頁不要「MACRO GG｜MACRO GG」，
    # 用標語當後綴。
    doc_title = (f"{SITE_NAME}｜{TAGLINE}" if title == SITE_NAME
                 else f"{title}｜{SITE_NAME}")
    # 頁名與資料期別：首頁由 LOGO 擔任標題（h1 只給螢幕閱讀器）；
    # 內頁的頁名放在導覽列下方。最後更新時間統一在頁首，不在這裡重複。
    if active == "/":
        pagehead = f'<h1 class="sr-only">{SITE_NAME}｜{TAGLINE}</h1>'
        if subtitle:
            pagehead += f'<div class="sub home-sub">{subtitle}</div>'
    else:
        pagehead = (f'<div class="pagehead"><h1>{esc(title)}</h1>'
                    + (f'<div class="sub">{subtitle}</div>' if subtitle else "")
                    + '</div>')
    return f"""<!DOCTYPE html>
<html lang="zh-Hant">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="robots" content="noindex, nofollow, noarchive">
<meta name="color-scheme" content="light">
<title>{esc(doc_title)}</title>
{_head_meta(doc_title, active)}
<script>try{{var _t=localStorage.getItem("mgg-theme");if(_t==="dark"||_t==="light")document.documentElement.setAttribute("data-theme",_t)}}catch(e){{}}</script>
<style>{CSS}</style>
{_SPECULATION}
</head>
<body>
<!-- 更新於 {clock.stamp()} -->
{_brand_header(active)}
{_nav(active)}
<div class="viz-root">
{pagehead}
{banner}
{anchors}
{body}

{_page_prevnext(active)}
<footer>{footer}</footer>

</div>
<div id="tip"></div>
<script>{JS}</script>
</body>
</html>"""


def source_footer(rows, notes=(), *, head: str = "", cols=("資料", "來源", "更新"),
                  disclaimer: str = "本頁僅為數據整理，不構成投資建議。", links: str = "") -> str:
    """
    各頁頁尾（2026-10 統一）：一行摘要＋「資料來源與方法」收合表。
      rows   [(資料, 來源, 更新)]——第三欄可空
      notes  方法重點（每條一句）；可含 HTML
    """
    trs = "".join(
        '<div class="pf-r">' + "".join(f'<span>{c}</span>' for c in r) + '</div>' for r in rows)
    hd = '<div class="pf-r pf-h">' + "".join(f'<span>{esc(c)}</span>' for c in cols) + '</div>'
    nl = "".join(f"<li>{n}</li>" for n in notes)
    return (f'<div class="pf">'
            f'<div class="pf-top">{head}<span>{esc(disclaimer)}</span>{links}</div>'
            f'<details class="f-more pf-d"><summary>資料來源與方法</summary>'
            f'<div class="pf-t">{hd}{trs}</div>'
            + (f'<ul class="pf-n">{nl}</ul>' if nl else "")
            + '</details></div>')


def soon_page(title: str, active: str, what: str, when: str) -> str:
    body = f"""<div class="soonbox">
  <h3>{esc(title)} — 即將推出</h3>
  <p>{esc(what)}</p>
  <p style="margin-top:14px;color:var(--muted)">預計推出：{esc(when)}</p>
</div>"""
    return page(title, active, body, subtitle="即將推出")


def next_cpi_release(after: dt.date | None = None) -> dt.date:
    """
    估算下一次 CPI 發布日。

    BLS 的慣例是次月的第 10–15 天之間，實務上多落在第二週的週二至週四。
    這裡取「次月第 12 天，遇週末往後推到週一」——跟就業報告的
    「第一個週五」一樣是慣例推估，不是官方行事曆，畫面上會標明是預估。
    """
    after = after or clock.today()

    def nth(y: int, m: int) -> dt.date:
        d = dt.date(y, m, 12)
        while d.weekday() >= 5:              # 週末往後推
            d += dt.timedelta(days=1)
        return d

    d = nth(after.year, after.month)
    if d <= after:
        y, m = ((after.year + 1, 1) if after.month == 12
                else (after.year, after.month + 1))
        d = nth(y, m)
    return d


def next_first_friday(after: dt.date | None = None) -> dt.date:
    """
    估算下一次就業報告發布日（慣例為每月第一個週五）。

    注意要先看**本月**的第一個週五：月初執行時（1 號到第一個週五之間），
    下一份報告就在幾天後，不能直接跳到下個月——否則每個月初都會
    顯示「約 31 天後」的錯誤推估。

    這是慣例推估，不是官方行事曆；遇假日或 BLS 調整會有偏差，
    畫面上一律標示為「預估」。
    """
    after = after or clock.today()

    def first_friday(y: int, m: int) -> dt.date:
        d = dt.date(y, m, 1)
        while d.weekday() != 4:
            d += dt.timedelta(days=1)
        return d

    d = first_friday(after.year, after.month)
    if d <= after:                       # 本月的已過 → 下個月
        y, m = ((after.year + 1, 1) if after.month == 12
                else (after.year, after.month + 1))
        d = first_friday(y, m)
    return d
